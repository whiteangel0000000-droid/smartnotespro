import {
  ChecklistItem,
  DEFAULT_NOTE_FONT_SIZE,
  Note,
  NoteAttachment,
  NoteBackgroundId,
  NotePriority,
  sanitizeBackground,
  sanitizeColor,
  sanitizeCustomBackgroundUrl,
  sanitizeFontSize,
  sanitizeLabels,
  sanitizePriority,
  sanitizeReminderAt,
  sanitizeStickyCurve,
  sanitizeStickyType,
  StickyCurveStyle,
  StickyNoteType,
} from '../../domain/model/note';

const CODEC_VERSION = 1;

export interface EncodedNotesPayload {
  version: number;
  exportedAt: number;
  notes: Array<{
    title: string;
    content: string;
    richContent?: string;
    fontSize?: number;
    totalCalculation: number;
    colorTag: number;
    backgroundId?: NoteBackgroundId;
    customBackgroundUrl?: string;
    labels?: string[];
    isPinned: boolean;
    isArchived?: boolean;
    isChecklist?: boolean;
    checklistItems?: ChecklistItem[];
    attachments?: NoteAttachment[];
    createdAt: number;
    updatedAt: number;
    reminderAt?: number;
    isStickyWidget?: boolean;
    stickyCurve?: StickyCurveStyle;
    stickyType?: StickyNoteType;
    priority?: NotePriority;
  }>;
}

export function encodeNotesJson(notes: readonly Note[], exportedAt = Date.now()): string {
  const payload: EncodedNotesPayload = {
    version: CODEC_VERSION,
    exportedAt,
    notes: notes.map((note) => {
      const item: EncodedNotesPayload['notes'][number] = {
        title: note.title,
        content: note.content,
        totalCalculation: note.totalCalculation,
        colorTag: sanitizeColor(note.colorTag),
        isPinned: note.isPinned,
        createdAt: note.createdAt,
        updatedAt: note.updatedAt,
      };
      if (note.richContent) {
        item.richContent = note.richContent;
      }
      if (note.fontSize && note.fontSize !== DEFAULT_NOTE_FONT_SIZE) {
        item.fontSize = sanitizeFontSize(note.fontSize);
      }
      if (note.backgroundId && note.backgroundId !== 'none') {
        item.backgroundId = note.backgroundId;
      }
      if (note.customBackgroundUrl) {
        item.customBackgroundUrl = note.customBackgroundUrl;
      }
      if (note.labels && note.labels.length > 0) {
        item.labels = note.labels;
      }
      if (note.isArchived) item.isArchived = true;
      if (note.isChecklist) item.isChecklist = true;
      if (note.checklistItems && note.checklistItems.length > 0) {
        item.checklistItems = note.checklistItems;
      }
      if (note.attachments && note.attachments.length > 0) {
        item.attachments = note.attachments;
      }
      if (note.reminderAt !== null) {
        item.reminderAt = note.reminderAt;
      }
      if (note.isStickyWidget) {
        item.isStickyWidget = true;
        if (note.stickyCurve) item.stickyCurve = note.stickyCurve;
        if (note.stickyType) item.stickyType = note.stickyType;
      }
      if (note.priority && note.priority !== 'normal') {
        item.priority = note.priority;
      }
      return item;
    }),
  };
  return JSON.stringify(payload, null, 2);
}

export function decodeNotesJson(json: string): Note[] | null {
  try {
    const parsed: unknown = JSON.parse(json);
    if (!parsed || typeof parsed !== 'object') return null;
    const record = parsed as Record<string, unknown>;
    if (typeof record.version === 'number' && record.version > CODEC_VERSION) {
      return null;
    }
    if (!Array.isArray(record.notes)) return null;

    const notes: Note[] = [];
    for (const raw of record.notes) {
      if (!raw || typeof raw !== 'object') continue;
      const item = raw as Record<string, unknown>;
      const title = typeof item.title === 'string' ? item.title : '';
      const content = typeof item.content === 'string' ? item.content : '';
      const totalCalculation =
        typeof item.totalCalculation === 'number' && Number.isFinite(item.totalCalculation)
          ? item.totalCalculation
          : 0;
      const colorTag =
        typeof item.colorTag === 'number' ? sanitizeColor(item.colorTag) : 0;
      const backgroundId = sanitizeBackground(item.backgroundId);
      const customBackgroundUrl = sanitizeCustomBackgroundUrl(item.customBackgroundUrl);
      const isPinned = typeof item.isPinned === 'boolean' ? item.isPinned : false;
      const isArchived = typeof item.isArchived === 'boolean' ? item.isArchived : false;
      const isChecklist = typeof item.isChecklist === 'boolean' ? item.isChecklist : false;
      const checklistItems: ChecklistItem[] = Array.isArray(item.checklistItems)
        ? item.checklistItems
            .filter((c): c is ChecklistItem => Boolean(c && typeof c === 'object'))
            .map((c, idx) => ({
              id: typeof c.id === 'string' ? c.id : `item-${idx}`,
              text: typeof c.text === 'string' ? c.text : '',
              checked: Boolean(c.checked),
            }))
        : [];
      const attachments: NoteAttachment[] = Array.isArray(item.attachments)
        ? item.attachments.filter(
            (a): a is NoteAttachment =>
              Boolean(
                a &&
                  typeof a === 'object' &&
                  typeof (a as NoteAttachment).dataUrl === 'string' &&
                  ((a as NoteAttachment).type === 'image' ||
                    (a as NoteAttachment).type === 'drawing' ||
                    (a as NoteAttachment).type === 'audio')
              )
          )
        : [];
      const createdAt =
        typeof item.createdAt === 'number' && Number.isFinite(item.createdAt)
          ? item.createdAt
          : 0;
      const updatedAt =
        typeof item.updatedAt === 'number' && Number.isFinite(item.updatedAt)
          ? item.updatedAt
          : 0;
      const labels = sanitizeLabels(item.labels);
      const reminderAt = sanitizeReminderAt(item.reminderAt);

      const richContent =
        typeof item.richContent === 'string' ? item.richContent : undefined;
      const fontSize =
        typeof item.fontSize === 'number'
          ? sanitizeFontSize(item.fontSize)
          : DEFAULT_NOTE_FONT_SIZE;

      const isStickyWidget =
        typeof item.isStickyWidget === 'boolean' ? item.isStickyWidget : false;
      const stickyCurve = sanitizeStickyCurve(item.stickyCurve);
      const stickyType = sanitizeStickyType(item.stickyType);
      const priority = sanitizePriority(item.priority);

      notes.push({
        id: 0,
        title,
        content,
        richContent,
        fontSize,
        totalCalculation,
        colorTag,
        backgroundId,
        customBackgroundUrl,
        labels,
        isPinned,
        isArchived,
        isChecklist,
        checklistItems,
        attachments,
        createdAt,
        updatedAt,
        reminderAt,
        isStickyWidget,
        stickyCurve,
        stickyType,
        priority,
        isDeleted: false,
        deletedAt: null,
      });
    }
    return notes;
  } catch {
    return null;
  }
}
