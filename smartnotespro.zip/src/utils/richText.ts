import { sanitizeFontSize } from '../domain/model/note';

export interface TextSegment {
  node: Text;
  start: number;
  end: number;
}

const BLOCK_TAGS = new Set(['DIV', 'P', 'H1', 'H2', 'H3', 'LI', 'BLOCKQUOTE']);
const INLINE_FORMAT_TAGS = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'DEL', 'SPAN']);

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatMarkdownLineToHtml(line: string): string {
  let prefixTagStart = '';
  let prefixTagEnd = '';
  let body = line;

  if (line.startsWith('## ')) {
    body = line.slice(3);
    prefixTagStart = '<span style="font-size: 20px"><b>';
    prefixTagEnd = '</b></span>';
  } else if (line.startsWith('# ')) {
    body = line.slice(2);
    prefixTagStart = '<span style="font-size: 24px"><b>';
    prefixTagEnd = '</b></span>';
  }

  let escaped = escapeHtml(body);
  escaped = escaped
    .replace(/\*\*(?=\S)(.+?)(?<=\S)\*\*/g, '<b>$1</b>')
    .replace(/__(?=\S)(.+?)(?<=\S)__/g, '<u>$1</u>')
    .replace(/~~(?=\S)(.+?)(?<=\S)~~/g, '<s>$1</s>')
    .replace(/(?<![*\w])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![*\w])/g, '<i>$1</i>');

  if (!escaped && !prefixTagStart) {
    return '<br>';
  }
  return `${prefixTagStart}${escaped}${prefixTagEnd}`;
}

export function plainTextToRichHtml(text: string): string {
  if (!text) return '';
  const lines = text.split('\n');
  return lines.map((line) => `<div>${formatMarkdownLineToHtml(line)}</div>`).join('');
}

export function sanitizeRichHtml(rawHtml: string): string {
  if (!rawHtml) return '';
  if (typeof document === 'undefined') {
    return rawHtml
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<style[\s\S]*?<\/style>/gi, '');
  }

  const source = document.createElement('div');
  source.innerHTML = rawHtml;
  const target = document.createElement('div');

  const cloneClean = (node: Node, destParent: HTMLElement) => {
    if (node.nodeType === Node.TEXT_NODE) {
      destParent.appendChild(document.createTextNode(node.nodeValue ?? ''));
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    const tag = el.tagName.toUpperCase();

    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'IFRAME' || tag === 'OBJECT') {
      return;
    }

    if (tag === 'BR') {
      destParent.appendChild(document.createElement('br'));
      return;
    }

    if (tag === 'H1' || tag === 'H2') {
      const div = document.createElement('div');
      const span = document.createElement('span');
      span.style.fontSize = tag === 'H1' ? '24px' : '20px';
      const b = document.createElement('b');
      Array.from(el.childNodes).forEach((child) => cloneClean(child, b));
      span.appendChild(b);
      div.appendChild(span);
      destParent.appendChild(div);
      return;
    }

    if (BLOCK_TAGS.has(tag)) {
      const div = document.createElement('div');
      const fontSizeMatch = el.style.fontSize?.match(/^(\d+(?:\.\d+)?)px$/i);
      if (fontSizeMatch) {
        div.style.fontSize = `${sanitizeFontSize(Number(fontSizeMatch[1]))}px`;
      }
      Array.from(el.childNodes).forEach((child) => cloneClean(child, div));
      destParent.appendChild(div);
      return;
    }

    if (tag === 'B' || tag === 'STRONG') {
      const b = document.createElement('b');
      Array.from(el.childNodes).forEach((child) => cloneClean(child, b));
      destParent.appendChild(b);
      return;
    }

    if (tag === 'I' || tag === 'EM') {
      const i = document.createElement('i');
      Array.from(el.childNodes).forEach((child) => cloneClean(child, i));
      destParent.appendChild(i);
      return;
    }

    if (tag === 'U') {
      const u = document.createElement('u');
      Array.from(el.childNodes).forEach((child) => cloneClean(child, u));
      destParent.appendChild(u);
      return;
    }

    if (tag === 'S' || tag === 'STRIKE' || tag === 'DEL') {
      const s = document.createElement('s');
      Array.from(el.childNodes).forEach((child) => cloneClean(child, s));
      destParent.appendChild(s);
      return;
    }

    if (tag === 'SPAN') {
      let leafParent: HTMLElement = destParent;
      const fontSizeMatch = el.style.fontSize?.match(/^(\d+(?:\.\d+)?)px$/i);
      if (fontSizeMatch) {
        const span = document.createElement('span');
        span.style.fontSize = `${sanitizeFontSize(Number(fontSizeMatch[1]))}px`;
        leafParent.appendChild(span);
        leafParent = span;
      }
      const td = `${el.style.textDecoration || ''} ${el.style.textDecorationLine || ''}`;
      if (td.includes('underline')) {
        const u = document.createElement('u');
        leafParent.appendChild(u);
        leafParent = u;
      }
      if (td.includes('line-through')) {
        const s = document.createElement('s');
        leafParent.appendChild(s);
        leafParent = s;
      }
      if (el.style.fontStyle === 'italic') {
        const i = document.createElement('i');
        leafParent.appendChild(i);
        leafParent = i;
      }
      const fw = el.style.fontWeight;
      if (fw === 'bold' || (Number(fw) >= 600 && Number.isFinite(Number(fw)))) {
        const b = document.createElement('b');
        leafParent.appendChild(b);
        leafParent = b;
      }
      Array.from(el.childNodes).forEach((child) => cloneClean(child, leafParent));
      return;
    }

    // Any other tag: unwrap children cleanly
    Array.from(el.childNodes).forEach((child) => cloneClean(child, destParent));
  };

  Array.from(source.childNodes).forEach((child) => cloneClean(child, target));
  normalizeDecorationNesting(target);
  return target.innerHTML;
}

const DECORATION_TAGS = new Set(['S', 'STRIKE', 'DEL', 'U']);

function isFontSizeSpan(node: Node): node is HTMLSpanElement {
  return (
    node.nodeType === Node.ELEMENT_NODE &&
    (node as HTMLElement).tagName.toUpperCase() === 'SPAN' &&
    Boolean((node as HTMLElement).style?.fontSize)
  );
}

/**
 * Ensures <span style="font-size: ..."> always wraps OUTSIDE <s> / <u> decoration tags
 * so CSS text-decoration draws at the inner text's exact font metrics instead of an outer 16px height.
 */
export function normalizeDecorationNesting(root: HTMLElement): void {
  for (let pass = 0; pass < 6; pass++) {
    let changed = false;
    const decs = Array.from(root.querySelectorAll('s, strike, del, u')) as HTMLElement[];

    for (const dec of decs) {
      if (!dec.isConnected) continue;
      if (!dec.querySelector('span[style*="font-size"]')) continue;

      const decTag = dec.tagName.toUpperCase() === 'U' ? 'u' : 's';
      const frag = document.createDocumentFragment();

      const processChild = (child: ChildNode) => {
        if (isFontSizeSpan(child)) {
          const outerSpan = document.createElement('span');
          outerSpan.style.fontSize = child.style.fontSize;
          const innerDec = document.createElement(decTag);
          while (child.firstChild) {
            innerDec.appendChild(child.firstChild);
          }
          outerSpan.appendChild(innerDec);
          frag.appendChild(outerSpan);
        } else if (
          child.nodeType === Node.ELEMENT_NODE &&
          (child as HTMLElement).querySelector('span[style*="font-size"]')
        ) {
          // e.g. <s><b><span style="font-size:28px">x</span></b></s>
          const el = child as HTMLElement;
          const elTag = el.tagName.toLowerCase();
          Array.from(el.childNodes).forEach((grandChild) => {
            if (isFontSizeSpan(grandChild)) {
              const outerSpan = document.createElement('span');
              outerSpan.style.fontSize = grandChild.style.fontSize;
              const innerDec = document.createElement(decTag);
              const innerWrapper = document.createElement(elTag);
              while (grandChild.firstChild) {
                innerWrapper.appendChild(grandChild.firstChild);
              }
              innerDec.appendChild(innerWrapper);
              outerSpan.appendChild(innerDec);
              frag.appendChild(outerSpan);
            } else {
              const decClone = document.createElement(decTag);
              const wrapperClone = document.createElement(elTag);
              wrapperClone.appendChild(grandChild);
              decClone.appendChild(wrapperClone);
              frag.appendChild(decClone);
            }
          });
        } else {
          const decClone = document.createElement(decTag);
          decClone.appendChild(child);
          frag.appendChild(decClone);
        }
      };

      Array.from(dec.childNodes).forEach(processChild);
      dec.parentNode?.replaceChild(frag, dec);
      changed = true;
    }

    if (!changed) break;
  }

  // Remove empty inline tags left behind
  Array.from(root.querySelectorAll('s, strike, del, u, b, strong, i, em, span')).forEach(
    (el) => {
      if (!el.textContent && !el.querySelector('br')) {
        el.parentNode?.removeChild(el);
      }
    }
  );
  void DECORATION_TAGS;
}

export function extractPlainTextAndSegments(root: HTMLElement): {
  text: string;
  segments: TextSegment[];
} {
  let text = '';
  const segments: TextSegment[] = [];
  let hasVisitedBlock = false;

  const walk = (node: Node, insideBlock: boolean) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const raw = (node.nodeValue ?? '').replace(/\u00A0/g, ' ');
      if (raw.length > 0) {
        const start = text.length;
        text += raw;
        segments.push({ node: node as Text, start, end: text.length });
      }
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;

    const el = node as HTMLElement;
    const tag = el.tagName.toUpperCase();

    if (tag === 'BR') {
      // Ignore the browser's placeholder <br> when it's the last child of a block element
      const isTrailingInBlock = insideBlock && !el.nextSibling;
      const isSoleRootBr = !insideBlock && !el.previousSibling && !el.nextSibling;
      if (!isTrailingInBlock && !isSoleRootBr) {
        text += '\n';
      }
      return;
    }

    if (BLOCK_TAGS.has(tag)) {
      if (hasVisitedBlock || text.length > 0) {
        text += '\n';
      }
      hasVisitedBlock = true;
      Array.from(el.childNodes).forEach((child) => walk(child, true));
      return;
    }

    Array.from(el.childNodes).forEach((child) => walk(child, insideBlock));
  };

  Array.from(root.childNodes).forEach((child) => walk(child, false));
  return { text, segments };
}

export function extractPlainTextFromHtml(html: string): string {
  if (!html) return '';
  if (typeof document === 'undefined') {
    return html.replace(/<[^>]+>/g, '');
  }
  const temp = document.createElement('div');
  temp.innerHTML = html;
  return extractPlainTextAndSegments(temp).text;
}

export function replacePlainTextRangeInElement(
  root: HTMLElement,
  startIndex: number,
  endIndexInclusive: number,
  replacement: string
): boolean {
  const endExclusive = endIndexInclusive + 1;
  const { segments } = extractPlainTextAndSegments(root);
  const overlapping = segments.filter(
    (seg) => seg.end > startIndex && seg.start < endExclusive
  );
  if (overlapping.length === 0) return false;

  const first = overlapping[0];
  const last = overlapping[overlapping.length - 1];

  const firstVal = (first.node.nodeValue ?? '').replace(/\u00A0/g, ' ');
  const localStart = Math.max(0, startIndex - first.start);

  if (overlapping.length === 1) {
    const localEnd = Math.min(firstVal.length, endExclusive - first.start);
    first.node.nodeValue =
      firstVal.slice(0, localStart) + replacement + firstVal.slice(localEnd);
    return true;
  }

  const lastVal = (last.node.nodeValue ?? '').replace(/\u00A0/g, ' ');
  const lastLocalEnd = Math.min(lastVal.length, endExclusive - last.start);

  first.node.nodeValue = firstVal.slice(0, localStart) + replacement;
  for (let i = 1; i < overlapping.length - 1; i++) {
    overlapping[i].node.nodeValue = '';
  }
  last.node.nodeValue = lastVal.slice(lastLocalEnd);
  return true;
}

function stripFontSizesInFragment(fragment: DocumentFragment): void {
  const walk = (parent: ParentNode) => {
    const children = Array.from(parent.childNodes);
    for (const child of children) {
      if (child.nodeType === Node.ELEMENT_NODE) {
        const el = child as HTMLElement;
        walk(el);
        if (el.style?.fontSize) {
          el.style.removeProperty('font-size');
        }
        if (
          el.tagName.toUpperCase() === 'SPAN' &&
          !el.getAttribute('style')?.trim()
        ) {
          const frag = document.createDocumentFragment();
          while (el.firstChild) frag.appendChild(el.firstChild);
          el.parentNode?.replaceChild(frag, el);
        }
      }
    }
  };
  walk(fragment);
}

function hasMeaningfulContent(fragment: DocumentFragment): boolean {
  if (fragment.textContent && fragment.textContent.length > 0) return true;
  return Boolean(fragment.querySelector('br'));
}

function splitInlineAncestorsAroundRange(root: HTMLElement, range: Range): Range {
  let current = range.cloneRange();

  while (true) {
    let ancestor: Node | null = current.commonAncestorContainer;
    if (ancestor.nodeType === Node.TEXT_NODE) {
      ancestor = ancestor.parentNode;
    }
    if (!ancestor || ancestor === root || ancestor.nodeType !== Node.ELEMENT_NODE) {
      break;
    }
    const el = ancestor as HTMLElement;
    const tag = el.tagName.toUpperCase();
    if (BLOCK_TAGS.has(tag) || !INLINE_FORMAT_TAGS.has(tag)) {
      break;
    }
    const parent = el.parentNode;
    if (!parent) break;

    const beforeRange = document.createRange();
    beforeRange.setStart(el, 0);
    beforeRange.setEnd(current.startContainer, current.startOffset);
    const beforeFrag = beforeRange.extractContents();

    const afterRange = document.createRange();
    afterRange.setStart(current.endContainer, current.endOffset);
    afterRange.setEnd(el, el.childNodes.length);
    const afterFrag = afterRange.extractContents();

    if (hasMeaningfulContent(beforeFrag)) {
      const beforeClone = el.cloneNode(false) as HTMLElement;
      beforeClone.appendChild(beforeFrag);
      parent.insertBefore(beforeClone, el);
    }

    if (hasMeaningfulContent(afterFrag)) {
      const afterClone = el.cloneNode(false) as HTMLElement;
      afterClone.appendChild(afterFrag);
      parent.insertBefore(afterClone, el.nextSibling);
    }

    // Wrap the remaining middle element directly so next iteration splits its parent if needed
    const nextRange = document.createRange();
    nextRange.selectNode(el);
    current = nextRange;
  }

  return current;
}

export function prepareFontSizeTargetSpan(
  root: HTMLElement,
  range: Range,
  initialSizePx: number
): { span: HTMLSpanElement; range: Range } | null {
  if (range.collapsed || !root.contains(range.commonAncestorContainer)) {
    return null;
  }

  const clamped = sanitizeFontSize(initialSizePx);

  // Fast path: selection already covers the exact contents of an outermost font-size <span>
  let ancestor: Node | null = range.commonAncestorContainer;
  if (ancestor.nodeType === Node.TEXT_NODE) {
    ancestor = ancestor.parentNode;
  }
  while (ancestor && ancestor !== root && ancestor.nodeType === Node.ELEMENT_NODE) {
    const el = ancestor as HTMLElement;
    if (el.tagName.toUpperCase() === 'SPAN' && el.style?.fontSize) {
      const hasOuterDecoration = Boolean(el.closest('s, strike, del, u'));
      if (!hasOuterDecoration && range.toString() === el.textContent) {
        const nextRange = document.createRange();
        nextRange.selectNodeContents(el);
        return { span: el as HTMLSpanElement, range: nextRange };
      }
      break;
    }
    ancestor = ancestor.parentNode;
  }

  // Split any enclosing inline tags (<s>, <u>, <b>, <i>, outer <span>) so the new
  // font-size <span> sits OUTSIDE <s> / <u> and decorations render at the new font size!
  const splitRange = splitInlineAncestorsAroundRange(root, range);
  const fragment = splitRange.extractContents();
  stripFontSizesInFragment(fragment);

  const span = document.createElement('span');
  span.style.fontSize = `${clamped}px`;
  span.appendChild(fragment);
  splitRange.insertNode(span);
  normalizeDecorationNesting(root);

  const nextRange = document.createRange();
  nextRange.selectNodeContents(span);
  return { span, range: nextRange };
}

export function getPlainTextSelectionOffsets(
  root: HTMLElement,
  range: Range
): { start: number; end: number } | null {
  if (!root.contains(range.commonAncestorContainer)) return null;
  const { text, segments } = extractPlainTextAndSegments(root);

  const resolvePoint = (container: Node, offset: number): number => {
    if (container.nodeType === Node.TEXT_NODE) {
      const seg = segments.find((s) => s.node === container);
      if (seg) return seg.start + Math.min(offset, seg.end - seg.start);
    }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const targetNode =
      container.nodeType === Node.ELEMENT_NODE && offset < container.childNodes.length
        ? container.childNodes[offset]
        : container;
    let node: Node | null;
    while ((node = walker.nextNode())) {
      const pos = targetNode.compareDocumentPosition(node);
      if (
        node === targetNode ||
        (pos & Node.DOCUMENT_POSITION_FOLLOWING) !== 0 ||
        (pos & Node.DOCUMENT_POSITION_CONTAINED_BY) !== 0
      ) {
        const seg = segments.find((s) => s.node === node);
        if (seg) return seg.start;
      }
    }
    return text.length;
  };

  return {
    start: resolvePoint(range.startContainer, range.startOffset),
    end: resolvePoint(range.endContainer, range.endOffset),
  };
}

export function restoreSelectionByPlainTextOffsets(
  root: HTMLElement,
  start: number,
  end: number
): Range | null {
  const { segments } = extractPlainTextAndSegments(root);
  if (segments.length === 0) return null;

  const findDomPoint = (targetOffset: number): { node: Text; offset: number } => {
    for (const seg of segments) {
      if (targetOffset <= seg.end) {
        return {
          node: seg.node,
          offset: Math.max(0, Math.min(targetOffset - seg.start, seg.end - seg.start)),
        };
      }
    }
    const last = segments[segments.length - 1];
    return { node: last.node, offset: last.end - last.start };
  };

  const p1 = findDomPoint(start);
  const p2 = findDomPoint(end);
  const range = document.createRange();
  range.setStart(p1.node, p1.offset);
  range.setEnd(p2.node, p2.offset);
  return range;
}

export function applyFontSizeToSelection(
  range: Range,
  fontSizePx: number
): Range | null {
  if (range.collapsed) return null;
  const clamped = sanitizeFontSize(fontSizePx);
  const fragment = range.extractContents();
  stripFontSizesInFragment(fragment);

  const span = document.createElement('span');
  span.style.fontSize = `${clamped}px`;
  span.appendChild(fragment);
  range.insertNode(span);

  const nextRange = document.createRange();
  nextRange.selectNodeContents(span);
  return nextRange;
}

export function clearFontSizeInSelection(range: Range): Range | null {
  if (range.collapsed) return null;
  const fragment = range.extractContents();
  stripFontSizesInFragment(fragment);

  const wrapper = document.createElement('span');
  wrapper.appendChild(fragment);
  range.insertNode(wrapper);

  const nextRange = document.createRange();
  nextRange.selectNodeContents(wrapper);

  // Unwrap temporary marker span cleanly
  const parent = wrapper.parentNode;
  if (parent) {
    const first = wrapper.firstChild;
    const last = wrapper.lastChild;
    while (wrapper.firstChild) {
      parent.insertBefore(wrapper.firstChild, wrapper);
    }
    parent.removeChild(wrapper);
    if (first && last) {
      const cleanRange = document.createRange();
      cleanRange.setStartBefore(first);
      cleanRange.setEndAfter(last);
      return cleanRange;
    }
  }
  return nextRange;
}

function unwrapFormattingTagsInContainer(container: Node): void {
  const children = Array.from(container.childNodes);
  for (const child of children) {
    if (child.nodeType !== Node.ELEMENT_NODE) continue;
    const el = child as HTMLElement;
    unwrapFormattingTagsInContainer(el);
    const tag = el.tagName.toUpperCase();
    if (INLINE_FORMAT_TAGS.has(tag)) {
      const frag = document.createDocumentFragment();
      while (el.firstChild) frag.appendChild(el.firstChild);
      el.parentNode?.replaceChild(frag, el);
    } else if (el.hasAttribute('style')) {
      el.removeAttribute('style');
    }
  }
}

export function clearAllFormattingInSelection(
  root: HTMLElement,
  range: Range
): Range | null {
  if (!range.collapsed) {
    const splitRange = splitInlineAncestorsAroundRange(root, range);
    const fragment = splitRange.extractContents();
    unwrapFormattingTagsInContainer(fragment);
    const marker = document.createElement('span');
    marker.appendChild(fragment);
    splitRange.insertNode(marker);

    const parent = marker.parentNode;
    if (parent) {
      const first = marker.firstChild;
      const last = marker.lastChild;
      while (marker.firstChild) {
        parent.insertBefore(marker.firstChild, marker);
      }
      parent.removeChild(marker);
      if (first && last) {
        const cleanRange = document.createRange();
        cleanRange.setStartBefore(first);
        cleanRange.setEndAfter(last);
        return cleanRange;
      }
    }
    return null;
  }

  // Collapsed caret: find closest block child of root and clear formatting on that line
  let node: Node | null = range.startContainer;
  let targetBlock: HTMLElement | null = null;
  while (node && node !== root) {
    if (
      node.nodeType === Node.ELEMENT_NODE &&
      BLOCK_TAGS.has((node as HTMLElement).tagName.toUpperCase())
    ) {
      targetBlock = node as HTMLElement;
      break;
    }
    node = node.parentNode;
  }

  if (targetBlock) {
    unwrapFormattingTagsInContainer(targetBlock);
    if (targetBlock.hasAttribute('style')) {
      targetBlock.removeAttribute('style');
    }
    const nextRange = document.createRange();
    nextRange.selectNodeContents(targetBlock);
    nextRange.collapse(false);
    return nextRange;
  }

  // Fallback: unwrap formatting elements directly inside root around caret
  unwrapFormattingTagsInContainer(root);
  const endRange = document.createRange();
  endRange.selectNodeContents(root);
  endRange.collapse(false);
  return endRange;
}

export function getFontSizeAtNode(
  node: Node | null,
  root: HTMLElement,
  fallbackSize: number
): number {
  let curr: Node | null = node;
  while (curr && curr !== root) {
    if (curr.nodeType === Node.ELEMENT_NODE) {
      const fs = (curr as HTMLElement).style?.fontSize;
      const match = fs?.match(/^(\d+(?:\.\d+)?)px$/i);
      if (match) {
        return sanitizeFontSize(Number(match[1]));
      }
    }
    curr = curr.parentNode;
  }
  return sanitizeFontSize(fallbackSize);
}
