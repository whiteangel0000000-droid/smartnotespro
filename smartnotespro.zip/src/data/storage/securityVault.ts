import {
  checkNativeBiometricAvailable,
  isNativeApp,
  promptNativeBiometric,
} from '../../utils/androidBridge';

export type AutoLockDelay = 'immediate' | '60' | '300' | 'manual';

export interface SecurityVaultState {
  enabled: boolean;
  isLocked: boolean;
  pinLength: 4 | 6;
  pinHash: string;
  pinSalt: string;
  biometricEnabled: boolean;
  biometricCredentialId: string | null;
  autoLock: AutoLockDelay;
  failedAttempts: number;
  lockoutUntil: number | null;
}

const VAULT_STORAGE_KEY = 'smartnotespro.security_vault.v1';
const LAST_ACTIVE_KEY = 'smartnotespro.vault_last_active.v1';
const PBKDF2_ITERATIONS = 100_000;

const DEFAULT_VAULT_STATE: SecurityVaultState = {
  enabled: false,
  isLocked: false,
  pinLength: 4,
  pinHash: '',
  pinSalt: '',
  biometricEnabled: false,
  biometricCredentialId: null,
  autoLock: 'immediate',
  failedAttempts: 0,
  lockoutUntil: null,
};

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.length % 2 === 0 ? hex : `0${hex}`;
  const out = new Uint8Array(clean.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16) || 0;
  }
  return out;
}

function bufferToBase64Url(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBuffer(value: string): ArrayBuffer {
  const padded =
    value.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((value.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

function constantTimeEqualHex(a: string, b: string): boolean {
  if (!a || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

async function derivePinHash(pin: string, saltHex: string): Promise<string> {
  const enc = new TextEncoder();
  const pinBytes = enc.encode(pin);
  const saltBytes = hexToBytes(saltHex);

  if (typeof crypto !== 'undefined' && crypto.subtle) {
    try {
      const keyMaterial = await crypto.subtle.importKey(
        'raw',
        pinBytes,
        'PBKDF2',
        false,
        ['deriveBits']
      );
      const bits = await crypto.subtle.deriveBits(
        {
          name: 'PBKDF2',
          salt: saltBytes.buffer as ArrayBuffer,
          iterations: PBKDF2_ITERATIONS,
          hash: 'SHA-256',
        },
        keyMaterial,
        256
      );
      return bytesToHex(new Uint8Array(bits));
    } catch {
      const combined = new Uint8Array(saltBytes.length + pinBytes.length);
      combined.set(saltBytes, 0);
      combined.set(pinBytes, saltBytes.length);
      const digest = await crypto.subtle.digest('SHA-256', combined);
      return bytesToHex(new Uint8Array(digest));
    }
  }

  let h1 = 0x811c9dc5;
  const input = `${saltHex}:${pin}:smartnotes-vault`;
  for (let i = 0; i < input.length; i++) {
    h1 ^= input.charCodeAt(i);
    h1 = Math.imul(h1, 0x01000193);
  }
  return (h1 >>> 0).toString(16).padStart(8, '0');
}

function generateSaltHex(): string {
  const bytes = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  return bytesToHex(bytes);
}

export function loadVaultState(): SecurityVaultState {
  try {
    const raw = localStorage.getItem(VAULT_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_VAULT_STATE };
    const parsed = JSON.parse(raw) as Partial<SecurityVaultState>;
    const enabled = Boolean(parsed.enabled && parsed.pinHash && parsed.pinSalt);
    return {
      enabled,
      isLocked: enabled ? Boolean(parsed.isLocked) : false,
      pinLength: parsed.pinLength === 6 ? 6 : 4,
      pinHash: typeof parsed.pinHash === 'string' ? parsed.pinHash : '',
      pinSalt: typeof parsed.pinSalt === 'string' ? parsed.pinSalt : '',
      biometricEnabled: Boolean(parsed.biometricEnabled && enabled),
      biometricCredentialId:
        typeof parsed.biometricCredentialId === 'string'
          ? parsed.biometricCredentialId
          : null,
      autoLock:
        parsed.autoLock === '60' ||
        parsed.autoLock === '300' ||
        parsed.autoLock === 'manual'
          ? parsed.autoLock
          : 'immediate',
      failedAttempts:
        typeof parsed.failedAttempts === 'number' && parsed.failedAttempts >= 0
          ? parsed.failedAttempts
          : 0,
      lockoutUntil:
        typeof parsed.lockoutUntil === 'number' && parsed.lockoutUntil > Date.now()
          ? parsed.lockoutUntil
          : null,
    };
  } catch {
    return { ...DEFAULT_VAULT_STATE };
  }
}

export function saveVaultState(state: SecurityVaultState): void {
  try {
    localStorage.setItem(VAULT_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage failures
  }
}

export function getLastVaultActivity(): number {
  try {
    const val = Number(localStorage.getItem(LAST_ACTIVE_KEY) || '0');
    return Number.isFinite(val) ? val : 0;
  } catch {
    return 0;
  }
}

export function touchVaultActivity(): void {
  try {
    localStorage.setItem(LAST_ACTIVE_KEY, String(Date.now()));
  } catch {
    // Ignore
  }
}

export function shouldLockInitially(state: SecurityVaultState): boolean {
  if (!state.enabled) return false;
  if (state.isLocked) return true;
  if (state.autoLock === 'manual') return false;
  if (state.autoLock === 'immediate') return true;
  const last = getLastVaultActivity();
  if (last <= 0) return true;
  const limitMs = Number(state.autoLock) * 1000;
  return Date.now() - last > limitMs;
}

export function shouldAutoLockOnReturn(state: SecurityVaultState): boolean {
  return shouldLockInitially(state);
}

export function setVaultLockedState(locked: boolean): SecurityVaultState {
  const current = loadVaultState();
  if (!current.enabled) {
    return { ...current, isLocked: false };
  }
  const next: SecurityVaultState = { ...current, isLocked: locked };
  saveVaultState(next);
  if (!locked) {
    touchVaultActivity();
  }
  return next;
}

export async function configureVaultPin(
  pin: string,
  autoLock?: AutoLockDelay
): Promise<SecurityVaultState> {
  const clean = pin.replace(/\D/g, '');
  if (clean.length !== 4 && clean.length !== 6) {
    throw new Error('PIN must be 4 or 6 digits.');
  }
  const existing = loadVaultState();
  const pinSalt = generateSaltHex();
  const pinHash = await derivePinHash(clean, pinSalt);
  const next: SecurityVaultState = {
    ...existing,
    enabled: true,
    isLocked: false,
    pinLength: clean.length as 4 | 6,
    pinHash,
    pinSalt,
    autoLock: autoLock ?? existing.autoLock,
    failedAttempts: 0,
    lockoutUntil: null,
  };
  saveVaultState(next);
  touchVaultActivity();
  return next;
}

export async function verifyVaultPin(
  pin: string
): Promise<{ ok: boolean; state: SecurityVaultState; error?: string }> {
  const state = loadVaultState();
  if (!state.enabled) {
    return { ok: true, state };
  }
  const now = Date.now();
  if (state.lockoutUntil && state.lockoutUntil > now) {
    const secs = Math.ceil((state.lockoutUntil - now) / 1000);
    return {
      ok: false,
      state,
      error: `Too many attempts. Try again in ${secs}s.`,
    };
  }

  const clean = pin.replace(/\D/g, '');
  const candidateHash = await derivePinHash(clean, state.pinSalt);
  if (constantTimeEqualHex(candidateHash, state.pinHash)) {
    const cleared: SecurityVaultState = {
      ...state,
      isLocked: false,
      failedAttempts: 0,
      lockoutUntil: null,
    };
    saveVaultState(cleared);
    touchVaultActivity();
    return { ok: true, state: cleared };
  }

  const nextFailed = state.failedAttempts + 1;
  const lockoutMs = nextFailed >= 8 ? 60_000 : nextFailed >= 5 ? 30_000 : 0;
  const nextState: SecurityVaultState = {
    ...state,
    failedAttempts: nextFailed,
    lockoutUntil: lockoutMs > 0 ? now + lockoutMs : null,
  };
  saveVaultState(nextState);

  return {
    ok: false,
    state: nextState,
    error:
      lockoutMs > 0
        ? `Incorrect PIN. Vault locked for ${Math.round(lockoutMs / 1000)}s.`
        : `Incorrect PIN (${5 - Math.min(nextFailed, 5)} attempts left before cooldown).`,
  };
}

export async function disableVaultPin(
  currentPin: string
): Promise<{ ok: boolean; state: SecurityVaultState; error?: string }> {
  const check = await verifyVaultPin(currentPin);
  if (!check.ok) return check;
  const reset: SecurityVaultState = { ...DEFAULT_VAULT_STATE };
  saveVaultState(reset);
  return { ok: true, state: reset };
}

export function updateVaultAutoLock(autoLock: AutoLockDelay): SecurityVaultState {
  const current = loadVaultState();
  const next: SecurityVaultState = {
    ...current,
    autoLock,
    isLocked: false,
  };
  saveVaultState(next);
  touchVaultActivity();
  return next;
}

function isInIframe(): boolean {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
}

export async function isBiometricHardwareAvailable(): Promise<boolean> {
  if (isNativeApp()) {
    return await checkNativeBiometricAvailable();
  }
  if (
    typeof window === 'undefined' ||
    typeof window.PublicKeyCredential === 'undefined' ||
    !window.isSecureContext
  ) {
    return false;
  }
  try {
    if (
      typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable ===
      'function'
    ) {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
    return Boolean(navigator.credentials?.create);
  } catch {
    return Boolean(navigator.credentials?.create);
  }
}

export async function enrollVaultBiometric(
  currentPin: string
): Promise<{ ok: boolean; state: SecurityVaultState; message: string }> {
  const check = await verifyVaultPin(currentPin);
  if (!check.ok) {
    return {
      ok: false,
      state: check.state,
      message: check.error || 'PIN verification required.',
    };
  }

  if (isNativeApp()) {
    const nativeAvailable = await checkNativeBiometricAvailable();
    if (!nativeAvailable) {
      return {
        ok: false,
        state: check.state,
        message:
          'No fingerprint or biometric lock is enrolled in Android device settings.',
      };
    }
    const promptRes = await promptNativeBiometric(
      'Enable Fingerprint Unlock',
      'Verify your fingerprint to secure SmartNotesPro'
    );
    if (!promptRes.verified) {
      return {
        ok: false,
        state: check.state,
        message: promptRes.error || 'Fingerprint enrollment was cancelled.',
      };
    }
    const next: SecurityVaultState = {
      ...check.state,
      biometricEnabled: true,
      biometricCredentialId: 'android-native-biometric',
    };
    saveVaultState(next);
    return {
      ok: true,
      state: next,
      message: 'Fingerprint / biometric unlock enabled.',
    };
  }

  if (
    typeof window === 'undefined' ||
    typeof window.PublicKeyCredential === 'undefined' ||
    !window.isSecureContext ||
    !navigator.credentials?.create
  ) {
    return {
      ok: false,
      state: check.state,
      message:
        'Fingerprint / device biometrics require a secure HTTPS browser context with WebAuthn support.',
    };
  }

  const attemptCreate = async (
    authenticatorSelection: AuthenticatorSelectionCriteria
  ): Promise<PublicKeyCredential | null> => {
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    const userId = new Uint8Array(16);
    crypto.getRandomValues(userId);

    return (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: {
          name: 'SmartNotesPro Vault',
        },
        user: {
          id: userId,
          name: 'smartnotes-owner',
          displayName: 'SmartNotesPro Owner',
        },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },
          { type: 'public-key', alg: -257 },
        ],
        authenticatorSelection,
        timeout: 60_000,
      },
    })) as PublicKeyCredential | null;
  };

  try {
    let credential: PublicKeyCredential | null = null;
    try {
      credential = await attemptCreate({
        authenticatorAttachment: 'platform',
        userVerification: 'required',
        residentKey: 'preferred',
      });
    } catch (firstErr) {
      const errName = firstErr instanceof DOMException ? firstErr.name : '';
      if (errName === 'NotSupportedError' || errName === 'ConstraintError') {
        credential = await attemptCreate({
          userVerification: 'preferred',
        });
      } else {
        throw firstErr;
      }
    }

    if (!credential) {
      return {
        ok: false,
        state: check.state,
        message: 'Fingerprint enrollment was cancelled.',
      };
    }

    const credId = bufferToBase64Url(credential.rawId);
    const next: SecurityVaultState = {
      ...check.state,
      biometricEnabled: true,
      biometricCredentialId: credId,
    };
    saveVaultState(next);
    return {
      ok: true,
      state: next,
      message: 'Fingerprint / biometric unlock enabled.',
    };
  } catch (err) {
    const domName = err instanceof DOMException ? err.name : '';
    const domMsg = err instanceof Error ? err.message : '';
    if (
      isInIframe() &&
      (domName === 'NotAllowedError' ||
        domName === 'SecurityError' ||
        domMsg.toLowerCase().includes('publickey-credentials'))
    ) {
      return {
        ok: false,
        state: check.state,
        message:
          'This embedded preview frame restricts browser biometrics. Open the Shared/Dev App URL directly in Chrome or your phone browser to enroll Fingerprint.',
      };
    }
    if (domName === 'NotAllowedError') {
      return {
        ok: false,
        state: check.state,
        message: 'Fingerprint enrollment was cancelled or timed out. Please try again.',
      };
    }
    return {
      ok: false,
      state: check.state,
      message:
        'Could not verify device fingerprint hardware in this browser (PIN lock remains active).',
    };
  }
}

export function disableVaultBiometric(): SecurityVaultState {
  const current = loadVaultState();
  const next: SecurityVaultState = {
    ...current,
    biometricEnabled: false,
    biometricCredentialId: null,
  };
  saveVaultState(next);
  return next;
}

export async function authenticateWithVaultBiometric(): Promise<{
  ok: boolean;
  state?: SecurityVaultState;
  error?: string;
}> {
  const state = loadVaultState();
  if (!state.enabled || !state.biometricEnabled || !state.biometricCredentialId) {
    return { ok: false, error: 'Biometric unlock is not configured.' };
  }

  if (isNativeApp()) {
    const promptRes = await promptNativeBiometric(
      'Unlock SmartNotesPro',
      'Use your fingerprint to unlock your vault'
    );
    if (!promptRes.verified) {
      return {
        ok: false,
        error: promptRes.error || 'Fingerprint verification cancelled. Enter PIN.',
      };
    }
    const cleared: SecurityVaultState = {
      ...state,
      isLocked: false,
      failedAttempts: 0,
      lockoutUntil: null,
    };
    saveVaultState(cleared);
    touchVaultActivity();
    return { ok: true, state: cleared };
  }

  if (!navigator.credentials?.get || !window.isSecureContext) {
    return {
      ok: false,
      error: 'Biometric prompt unavailable here. Please enter your PIN.',
    };
  }

  try {
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    const credIdBuffer = base64UrlToBuffer(state.biometricCredentialId);
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        allowCredentials: [
          {
            type: 'public-key',
            id: credIdBuffer,
          },
        ],
        userVerification: 'preferred',
        timeout: 60_000,
      },
    });
    if (!assertion) {
      return { ok: false, error: 'Fingerprint verification cancelled. Enter PIN.' };
    }
    const cleared: SecurityVaultState = {
      ...state,
      isLocked: false,
      failedAttempts: 0,
      lockoutUntil: null,
    };
    saveVaultState(cleared);
    touchVaultActivity();
    return { ok: true, state: cleared };
  } catch (err) {
    const domName = err instanceof DOMException ? err.name : '';
    const domMsg = err instanceof Error ? err.message : '';
    if (
      isInIframe() &&
      (domName === 'NotAllowedError' ||
        domName === 'SecurityError' ||
        domMsg.toLowerCase().includes('publickey-credentials'))
    ) {
      return {
        ok: false,
        error:
          'Embedded preview frame blocks biometrics. Open the app URL directly in your browser or enter PIN.',
      };
    }
    return {
      ok: false,
      error: 'Fingerprint not recognized or cancelled. Use your PIN to unlock.',
    };
  }
}
