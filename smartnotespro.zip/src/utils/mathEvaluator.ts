/**
 * Safe recursive-descent math evaluator & inline expression detector.
 * No eval, no Function constructor.
 *
 * Grammar (lowest to highest precedence):
 *   expression := term (('+' | '-') term)*
 *   term       := unary (('*' | '/' | '%') unary)*     // '%' here = modulo
 *   unary      := ('-' | '+') unary | power
 *   power      := postfix ('^' unary)?                  // right-associative
 *   postfix    := primary ('%')*                        // '%' here = percent
 *   primary    := number | '(' expression ')'
 *
 * '%' disambiguation: a '%' followed by an operand start (digit, '.', '(') is
 * modulo ("10%3"); otherwise it is percent ("50%", "10%+5").
 */

const MAX_INPUT_LENGTH = 500;
const MAX_NESTING_DEPTH = 100;
const ROUNDING_LIMIT = 1e15;
const MAX_MATCHES = 200;

const PERCENT_OF_PATTERN = /^([0-9.,]+)\s*%\s*of\s+(.+)$/i;
const MULTIPLY_X_PATTERN = /(?<=[\d)%])[xX](?=[\d.(+-])/g;
const WHITESPACE_OR_COMMA = /[\s,]+/g;
const ALLOWED_CHARS = /^[0-9.+\-*/%^()]+$/;

const OPERATOR_CHARS = new Set([...'+\-*/^%xX×÷−']);
const NUMBER_PATTERN = /\d+(?:\.\d+)?|\.\d+/g;
const LETTER_PATTERN = /\p{L}/u;

const IDENTIFIER_PATTERNS: RegExp[] = [
  /^\d{3}-\d{4}$/,                 // 555-1234
  /^\d{2,4}-\d{3,4}-\d{4,7}$/,     // 555-123-4567, 92-300-1234567
  /^0\d+-\d+$/,                    // 0300-1234567
  /^\d{4}-\d{1,2}-\d{1,2}$/,       // 2026-11-21
  /^\d{1,2}-\d{1,2}-\d{2,4}$/,     // 21-11-2026
  /^\d{4}\/\d{1,2}\/\d{1,2}$/,     // 2026/11/21
  /^\d{1,2}\/\d{1,2}\/\d{2,4}$/,   // 21/11/2026
];

const PRINTED_RESULT_SUFFIX =
  /^[ \t]*=[ \t]*(-?(?:\d+(?:,\d{3})*(?:\.\d+)?|\.\d+))(?![ \t]*[+\-*/^%xX×÷−\d.])/;

interface Operand {
  value: number;
  isPercent: boolean;
}

export interface PercentAdjustment {
  operator: '+' | '-';
  percent: number;
  amount: number;
}

export interface ExpressionMatch {
  expression: string;
  startIndex: number;
  endIndexInclusive: number;
  result: number;
  percentDelta?: number;
  percentAdjustments?: PercentAdjustment[];
  isApplied?: boolean;
  printedEndIndexInclusive?: number;
}

export function normalizeExpression(input: string): string {
  const unified = input
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/−/g, '-');
  const compact = unified.replace(WHITESPACE_OR_COMMA, '');
  return compact.replace(MULTIPLY_X_PATTERN, '*');
}

function finish(value: number): number | null {
  if (!Number.isFinite(value)) return null;
  if (Math.abs(value) >= ROUNDING_LIMIT) return value;
  const rounded = Number(value.toFixed(10));
  return Object.is(rounded, -0) ? 0 : rounded;
}

class RecursiveDescentParser {
  private pos = 0;
  private depth = 0;
  readonly percentAdjustments: PercentAdjustment[] = [];

  constructor(private readonly source: string) {}

  parse(): number {
    const result = this.parseExpression();
    if (this.pos !== this.source.length) {
      throw new Error(`Unexpected '${this.source[this.pos]}' at ${this.pos}`);
    }
    return result.value;
  }

  private parseExpression(): Operand {
    return this.nested(() => {
      let left = this.parseTerm();
      let op = this.peek();
      while (op === '+' || op === '-') {
        this.pos++;
        const right = this.parseTerm();
        const delta = right.isPercent ? left.value * right.value : right.value;
        if (right.isPercent) {
          const amount = finish(delta);
          const pct = finish(right.value * 100);
          if (amount !== null && pct !== null) {
            this.percentAdjustments.push({
              operator: op,
              percent: pct,
              amount,
            });
          }
        }
        left = {
          value: op === '+' ? left.value + delta : left.value - delta,
          isPercent: false,
        };
        op = this.peek();
      }
      return left;
    });
  }

  private parseTerm(): Operand {
    let left = this.parseUnary();
    let op = this.peek();
    while (op === '*' || op === '/' || op === '%') {
      this.pos++;
      const right = this.parseUnary().value;
      if (op === '*') {
        left = { value: left.value * right, isPercent: false };
      } else if (op === '/') {
        if (right === 0) throw new Error('Division by zero');
        left = { value: left.value / right, isPercent: false };
      } else {
        if (right === 0) throw new Error('Modulo by zero');
        left = { value: left.value % right, isPercent: false };
      }
      op = this.peek();
    }
    return left;
  }

  private parseUnary(): Operand {
    return this.nested(() => {
      const c = this.peek();
      if (c === '-') {
        this.pos++;
        const inner = this.parseUnary();
        return { value: -inner.value, isPercent: inner.isPercent };
      }
      if (c === '+') {
        this.pos++;
        return this.parseUnary();
      }
      return this.parsePower();
    });
  }

  private parsePower(): Operand {
    const base = this.parsePostfix();
    if (this.peek() !== '^') return base;
    this.pos++;
    const exponent = this.parseUnary();
    const value = Math.pow(base.value, exponent.value);
    if (Number.isNaN(value)) throw new Error('Undefined power');
    return { value, isPercent: false };
  }

  private parsePostfix(): Operand {
    let operand = this.parsePrimary();
    while (this.peek() === '%' && !this.isOperandStart(this.charAt(this.pos + 1))) {
      this.pos++;
      operand = { value: operand.value / 100, isPercent: true };
    }
    return operand;
  }

  private parsePrimary(): Operand {
    const c = this.peek();
    if (c === null) throw new Error('Unexpected end of expression');
    if (c === '(') {
      this.pos++;
      const inner = this.nested(() => this.parseExpression());
      if (this.peek() !== ')') throw new Error('Missing closing parenthesis');
      this.pos++;
      return { value: inner.value, isPercent: false };
    }
    return this.parseNumber();
  }

  private parseNumber(): Operand {
    const start = this.pos;
    while (
      this.pos < this.source.length &&
      (this.isAsciiDigit(this.source[this.pos]) || this.source[this.pos] === '.')
    ) {
      this.pos++;
    }
    if (start === this.pos) throw new Error(`Number expected at ${this.pos}`);
    const slice = this.source.slice(start, this.pos);
    if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(slice)) {
      throw new Error(`Bad number: ${slice}`);
    }
    const value = Number(slice);
    if (!Number.isFinite(value)) throw new Error(`Bad number: ${slice}`);
    return { value, isPercent: false };
  }

  private peek(): string | null {
    return this.charAt(this.pos);
  }

  private charAt(index: number): string | null {
    return index >= 0 && index < this.source.length ? this.source[index] : null;
  }

  private isOperandStart(c: string | null): boolean {
    return c !== null && (this.isAsciiDigit(c) || c === '.' || c === '(');
  }

  private isAsciiDigit(c: string): boolean {
    return c >= '0' && c <= '9';
  }

  private nested<T>(block: () => T): T {
    if (++this.depth > MAX_NESTING_DEPTH) {
      throw new Error('Expression nested too deeply');
    }
    try {
      return block();
    } finally {
      this.depth--;
    }
  }
}

function evaluateInternalWithDetails(input: string): {
  result: number;
  percentDelta?: number;
  percentAdjustments?: PercentAdjustment[];
} | null {
  const trimmed = input.trim();
  if (!trimmed || trimmed.length > MAX_INPUT_LENGTH) return null;

  const percentOf = PERCENT_OF_PATTERN.exec(trimmed);
  if (percentOf) {
    const percent = evaluateInternal(percentOf[1]);
    const base = evaluateInternal(percentOf[2]);
    if (percent === null || base === null) return null;
    const result = finish((percent / 100) * base);
    return result === null ? null : { result };
  }

  const normalized = normalizeExpression(trimmed);
  if (!ALLOWED_CHARS.test(normalized)) return null;

  const parser = new RecursiveDescentParser(normalized);
  const result = finish(parser.parse());
  if (result === null) return null;

  if (parser.percentAdjustments.length > 0) {
    let netDelta = 0;
    for (const adj of parser.percentAdjustments) {
      netDelta += adj.operator === '+' ? adj.amount : -adj.amount;
    }
    const cleanDelta = finish(netDelta);
    return {
      result,
      percentDelta: cleanDelta !== null && cleanDelta !== 0 ? cleanDelta : undefined,
      percentAdjustments: parser.percentAdjustments,
    };
  }

  return { result };
}

function evaluateInternal(input: string): number | null {
  return evaluateInternalWithDetails(input)?.result ?? null;
}

export function evaluateMath(input: string): number | null {
  try {
    return evaluateInternal(input);
  } catch {
    return null;
  }
}

function evaluateMathWithDetails(input: string) {
  try {
    return evaluateInternalWithDetails(input);
  } catch {
    return null;
  }
}

// ───────────────────────── Expression Detection ─────────────────────────

function isLetter(c: string | undefined): boolean {
  return c !== undefined && LETTER_PATTERN.test(c);
}

function isInlineSpace(c: string): boolean {
  return c === ' ' || c === '\t' || c === '\u00A0';
}

function isAsciiDigit(c: string): boolean {
  return c >= '0' && c <= '9';
}

function isOperandStart(c: string): boolean {
  return isAsciiDigit(c) || c === '(' || c === '.';
}

function isOperandEnd(c: string): boolean {
  return isAsciiDigit(c) || c === ')' || c === '%' || c === '.';
}

function previousNonSpace(text: string, index: number): string | null {
  let i = index - 1;
  while (i >= 0 && isInlineSpace(text[i])) i--;
  return i >= 0 ? text[i] : null;
}

function nextNonSpace(text: string, index: number): string | null {
  let i = index + 1;
  while (i < text.length && isInlineSpace(text[i])) i++;
  return i < text.length ? text[i] : null;
}

function isMultiplyX(text: string, index: number): boolean {
  const prev = previousNonSpace(text, index);
  const next = nextNonSpace(text, index);
  if (!prev || !next) return false;
  const prevOk = isAsciiDigit(prev) || prev === ')' || prev === '%';
  const nextOk = isAsciiDigit(next) || next === '(' || next === '.';
  return prevOk && nextOk;
}

function isMathChar(text: string, index: number): boolean {
  const c = text[index];
  if (isAsciiDigit(c)) return true;
  if ('+-*/%^().×÷−'.includes(c)) return true;
  if (c === ',') {
    return (
      index > 0 &&
      index + 1 < text.length &&
      isAsciiDigit(text[index - 1]) &&
      isAsciiDigit(text[index + 1])
    );
  }
  if (c === 'x' || c === 'X') return isMultiplyX(text, index);
  return false;
}

function scanRun(text: string, start: number): number {
  const n = text.length;
  let lastIncluded = start;
  let lastChar = text[start];
  let j = start + 1;

  while (j < n) {
    const c = text[j];
    if (isInlineSpace(c)) {
      let k = j;
      while (k < n && isInlineSpace(text[k])) k++;
      if (k >= n || !isMathChar(text, k)) break;
      if (isOperandEnd(lastChar) && isOperandStart(text[k])) break;
      j = k;
    } else if (isMathChar(text, j)) {
      lastIncluded = j;
      lastChar = c;
      j++;
    } else {
      break;
    }
  }
  return lastIncluded;
}

function isValidStart(text: string, index: number): boolean {
  const c = text[index];
  const next = index + 1 < text.length ? text[index + 1] : null;
  if (isAsciiDigit(c) || c === '(') return true;
  if (c === '.') return next !== null && isAsciiDigit(next);
  if (c === '-' || c === '−') {
    return next !== null && (isAsciiDigit(next) || next === '(' || next === '.');
  }
  return false;
}

function isTrailingJunk(c: string): boolean {
  return isInlineSpace(c) || '+-*/^xX×÷−.,'.includes(c);
}

function countChar(text: string, from: number, to: number, target: string): number {
  let count = 0;
  for (let i = from; i <= to; i++) {
    if (text[i] === target) count++;
  }
  return count;
}

function isWorthEvaluating(expression: string): boolean {
  const compact = expression.replace(/,/g, '');
  const numbers = compact.match(NUMBER_PATTERN);
  const numberCount = numbers ? numbers.length : 0;
  let hasOperator = false;
  for (const ch of compact) {
    if (OPERATOR_CHARS.has(ch)) {
      hasOperator = true;
      break;
    }
  }
  return numberCount >= 2 && hasOperator;
}

function looksLikeIdentifier(expression: string): boolean {
  return IDENTIFIER_PATTERNS.some((pattern) => pattern.test(expression));
}

function inspectPrintedSuffix(
  text: string,
  endIndexInclusive: number,
  result: number
): { isApplied: boolean; printedEndIndexInclusive?: number } {
  const tail = text.slice(endIndexInclusive + 1);
  const suffixMatch = PRINTED_RESULT_SUFFIX.exec(tail);
  if (!suffixMatch) {
    return { isApplied: false };
  }
  const printedEndIndexInclusive = endIndexInclusive + suffixMatch[0].length;
  const existingNumber = suffixMatch[1].replace(/,/g, '');
  const expectedNumber = formatResult(result);
  return {
    isApplied: existingNumber === expectedNumber,
    printedEndIndexInclusive,
  };
}

function buildMatch(text: string, runStart: number, runEnd: number): ExpressionMatch | null {
  if (runStart > 0 && isLetter(text[runStart - 1])) return null;

  let l = runStart;
  let r = runEnd;
  while (l <= r) {
    if (!isValidStart(text, l)) {
      l++;
      continue;
    }
    if (isTrailingJunk(text[r])) {
      r--;
      continue;
    }
    const opens = countChar(text, l, r, '(');
    const closes = countChar(text, l, r, ')');
    if (closes > opens && text[r] === ')') {
      r--;
      continue;
    }
    if (opens > closes && text[l] === '(') {
      l++;
      continue;
    }
    break;
  }
  if (l > r) return null;

  if (r + 1 < text.length && isLetter(text[r + 1])) return null;

  const expression = text.slice(l, r + 1);
  if (!isWorthEvaluating(expression)) return null;
  if (looksLikeIdentifier(expression)) return null;

  const evaluated = evaluateMathWithDetails(expression);
  if (!evaluated || !Number.isFinite(evaluated.result)) return null;

  const { isApplied, printedEndIndexInclusive } = inspectPrintedSuffix(
    text,
    r,
    evaluated.result
  );

  return {
    expression,
    startIndex: l,
    endIndexInclusive: r,
    result: evaluated.result,
    percentDelta: evaluated.percentDelta,
    percentAdjustments: evaluated.percentAdjustments,
    isApplied,
    printedEndIndexInclusive,
  };
}

function roundNoise(value: number): number {
  if (!Number.isFinite(value) || Math.abs(value) >= 1e15) return value;
  const rounded = Number(value.toFixed(10));
  return Object.is(rounded, -0) ? 0 : rounded;
}

export function findExpressions(text: string): ExpressionMatch[] {
  if (!text) return [];
  const matches: ExpressionMatch[] = [];
  let i = 0;
  while (i < text.length && matches.length < MAX_MATCHES) {
    if (!isMathChar(text, i)) {
      i++;
      continue;
    }
    const runEnd = scanRun(text, i);
    const match = buildMatch(text, i, runEnd);
    if (match) matches.push(match);
    i = runEnd + 1;
  }
  return matches;
}

export function totalOfText(text: string): number {
  return totalOfMatches(findExpressions(text));
}

export function totalOfMatches(matches: readonly ExpressionMatch[]): number {
  let total = 0;
  for (const match of matches) total += match.result;
  return roundNoise(total);
}

export function formatResult(value: number): string {
  if (!Number.isFinite(value)) return String(value);
  if (Math.abs(value) >= 1e15) return String(value);
  const rounded = Number(value.toFixed(10));
  if (Object.is(rounded, -0) || rounded === 0) return '0';
  return rounded.toFixed(10).replace(/\.?0+$/, '');
}

export function formatEquation(match: Pick<ExpressionMatch, 'expression' | 'result'>): string {
  return `${match.expression} = ${formatResult(match.result)}`;
}

export function formatPercentDelta(
  match: Pick<ExpressionMatch, 'percentDelta'>
): string | null {
  if (match.percentDelta === undefined || match.percentDelta === 0) return null;
  if (match.percentDelta > 0) return `+${formatResult(match.percentDelta)}`;
  return `-${formatResult(Math.abs(match.percentDelta))}`;
}

export function replaceWithResult(text: string, match: ExpressionMatch): string {
  const { startIndex, endIndexInclusive, expression, printedEndIndexInclusive } = match;
  if (startIndex < 0 || endIndexInclusive >= text.length || startIndex > endIndexInclusive) {
    return text;
  }
  if (text.slice(startIndex, endIndexInclusive + 1) !== expression) {
    return text;
  }
  if (match.isApplied) {
    return text;
  }
  const replaceEnd =
    printedEndIndexInclusive !== undefined && printedEndIndexInclusive > endIndexInclusive
      ? printedEndIndexInclusive
      : endIndexInclusive;
  return text.slice(0, startIndex) + formatEquation(match) + text.slice(replaceEnd + 1);
}

export function getMatchKeys(
  matches: readonly ExpressionMatch[],
  itemIds?: readonly string[]
): string[] {
  const counts = new Map<string, number>();
  return matches.map((m, idx) => {
    const scope = itemIds && itemIds[idx] ? `chk:${itemIds[idx]}:` : '';
    const base = `${scope}${normalizeExpression(m.expression)}`;
    const occ = counts.get(base) ?? 0;
    counts.set(base, occ + 1);
    return `${base}#${occ}`;
  });
}

export function isCaretInPrintedSuffix(
  match: ExpressionMatch,
  caretStart: number | null,
  caretEnd: number | null
): boolean {
  if (match.printedEndIndexInclusive === undefined) return false;
  const suffixStart = match.endIndexInclusive + 2;
  const suffixEnd = match.printedEndIndexInclusive + 1;
  const inRange = (pos: number | null) =>
    pos !== null && pos >= suffixStart && pos <= suffixEnd;
  return inRange(caretStart) || inRange(caretEnd);
}

export function autoUpdatePrintedResultsInText(
  text: string,
  caretStart: number | null = null,
  caretEnd: number | null = null
): { text: string; changed: boolean } {
  const matches = findExpressions(text);
  let nextText = text;
  let changed = false;

  for (let i = matches.length - 1; i >= 0; i--) {
    const m = matches[i];
    if (m.printedEndIndexInclusive === undefined || m.isApplied) continue;
    if (isCaretInPrintedSuffix(m, caretStart, caretEnd)) continue;

    const nextSuffix = ` = ${formatResult(m.result)}`;
    nextText =
      nextText.slice(0, m.endIndexInclusive + 1) +
      nextSuffix +
      nextText.slice(m.printedEndIndexInclusive + 1);
    changed = true;
  }

  return { text: nextText, changed };
}
