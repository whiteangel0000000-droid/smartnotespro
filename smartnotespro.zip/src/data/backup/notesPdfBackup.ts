import {
  DEFAULT_NOTE_FONT_SIZE,
  getNoteColorOption,
  Note,
} from '../../domain/model/note';
import { formatResult } from '../../utils/mathEvaluator';
import { saveAndShareBinaryFile } from '../../utils/androidBridge';
import {
  formatBackupDateTime,
  getAttachmentsSummary,
  getNotePlainDetails,
  getNoteTypeLabel,
  sortNotesForOrganizedBackup,
} from './notesCsvBackup';
import { decodeNotesJson, encodeNotesJson } from './notesJsonCodec';

const PDF_PAGE_PX_W = 1240;
const PDF_PAGE_PX_H = 1754;
const PDF_PT_W = 595;
const PDF_PT_H = 842;
const MARGIN_X = 64;
const CONTENT_W = PDF_PAGE_PX_W - MARGIN_X * 2;
const FOOTER_H = 66;
const SAFE_BOTTOM_Y = PDF_PAGE_PX_H - FOOTER_H - 18;

const BACKUP_START_MARKER = '%SNPRO_BACKUP_V1%';
const BACKUP_END_MARKER = '%SNPRO_BACKUP_END%';

interface RenderedPdfPage {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
}

function createA4Page(): RenderedPdfPage {
  const canvas = document.createElement('canvas');
  canvas.width = PDF_PAGE_PX_W;
  canvas.height = PDF_PAGE_PX_H;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, PDF_PAGE_PX_W, PDF_PAGE_PX_H);
  return { canvas, ctx };
}

function wrapParagraphLines(
  ctx: CanvasRenderingContext2D,
  paragraph: string,
  maxWidth: number
): string[] {
  if (!paragraph) return [''];
  const words = paragraph.split(/(\s+)/);
  const lines: string[] = [];
  let current = '';

  for (const token of words) {
    const candidate = current + token;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      if (current.trimEnd()) lines.push(current.trimEnd());
      const trimmedToken = token.trimStart();
      if (!trimmedToken) {
        current = '';
        continue;
      }
      if (ctx.measureText(trimmedToken).width <= maxWidth) {
        current = trimmedToken;
      } else {
        let slice = '';
        for (const ch of trimmedToken) {
          if (ctx.measureText(slice + ch).width > maxWidth && slice) {
            lines.push(slice);
            slice = ch;
          } else {
            slice += ch;
          }
        }
        current = slice;
      }
    }
  }
  if (current.trimEnd() || lines.length === 0) {
    lines.push(current.trimEnd());
  }
  return lines;
}

function wrapMultilineText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  if (!text) return [];
  const rawParagraphs = text.split(/\r?\n/);
  const out: string[] = [];
  for (const para of rawParagraphs) {
    const wrapped = wrapParagraphLines(ctx, para, maxWidth);
    out.push(...wrapped);
  }
  return out;
}

function loadImageWithTimeout(src: string, timeoutMs = 1500): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    if (!src) {
      resolve(null);
      return;
    }
    const img = new Image();
    let settled = false;
    const timer = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(null);
      }
    }, timeoutMs);

    img.onload = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(img);
      }
    };
    img.onerror = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(null);
      }
    };
    img.src = src;
  });
}

function drawCheckboxGlyph(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  checked: boolean
): void {
  const size = 18;
  ctx.save();
  ctx.lineWidth = 2;
  if (checked) {
    ctx.fillStyle = '#4F46E5';
    ctx.strokeStyle = '#4F46E5';
    ctx.beginPath();
    ctx.roundRect(x, y - size + 3, size, size, 4);
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(x + 4, y - size / 2 + 3);
    ctx.lineTo(x + 8, y - size / 2 + 7);
    ctx.lineTo(x + 14, y - size / 2 - 2);
    ctx.stroke();
  } else {
    ctx.strokeStyle = '#94A3B8';
    ctx.beginPath();
    ctx.roundRect(x, y - size + 3, size, size, 4);
    ctx.stroke();
  }
  ctx.restore();
}

async function renderOrganizedBackupPages(
  notes: readonly Note[]
): Promise<HTMLCanvasElement[]> {
  const { pinned, active, archived, ordered } = sortNotesForOrganizedBackup(notes);
  const pages: RenderedPdfPage[] = [];
  let page = createA4Page();
  pages.push(page);
  let cursorY = 58;

  const ensureSpace = (neededHeight: number) => {
    if (cursorY + neededHeight > SAFE_BOTTOM_Y) {
      page = createA4Page();
      pages.push(page);
      cursorY = 64;
    }
  };

  // Top Header Banner (Page 1)
  const ctx0 = page.ctx;
  ctx0.fillStyle = '#312E81';
  ctx0.fillRect(0, 0, PDF_PAGE_PX_W, 12);

  ctx0.fillStyle = '#0F172A';
  ctx0.font = '700 38px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  ctx0.fillText('SmartNotesPro — Organized Notes Backup', MARGIN_X, cursorY + 34);

  const exportedAtStr = formatBackupDateTime(Date.now());
  ctx0.fillStyle = '#475569';
  ctx0.font = '500 20px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  ctx0.fillText(`Exported on ${exportedAtStr}`, MARGIN_X, cursorY + 70);

  // Summary strip
  const checklistCount = ordered.filter((n) => n.isChecklist).length;
  const summaryRectY = cursorY + 94;
  ctx0.fillStyle = '#F8FAFC';
  ctx0.strokeStyle = '#E2E8F0';
  ctx0.lineWidth = 2;
  ctx0.beginPath();
  ctx0.roundRect(MARGIN_X, summaryRectY, CONTENT_W, 56, 12);
  ctx0.fill();
  ctx0.stroke();

  ctx0.fillStyle = '#1E293B';
  ctx0.font = '600 20px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  ctx0.fillText(
    `Total: ${ordered.length} Notes   ·   Pinned: ${pinned.length}   ·   Active: ${active.length}   ·   Archived: ${archived.length}   ·   Checklists: ${checklistCount}`,
    MARGIN_X + 20,
    summaryRectY + 35
  );

  cursorY = summaryRectY + 86;

  if (ordered.length === 0) {
    ctx0.fillStyle = '#64748B';
    ctx0.font = '500 24px system-ui, -apple-system, sans-serif';
    ctx0.fillText('No notes found to export.', MARGIN_X, cursorY + 40);
  }

  // Preload up to 1 thumbnail per note with image/drawing
  const thumbnails = new Map<number, HTMLImageElement | null>();
  await Promise.all(
    ordered.map(async (n) => {
      const visual = (n.attachments ?? []).find(
        (a) => a.type === 'image' || a.type === 'drawing'
      );
      if (visual) {
        const loaded = await loadImageWithTimeout(visual.dataUrl);
        thumbnails.set(n.id, loaded);
      }
    })
  );

  let globalIndex = 0;

  const sections: Array<{ title: string; accent: string; items: Note[] }> = [
    { title: 'PINNED NOTES', accent: '#4F46E5', items: pinned },
    { title: 'ACTIVE NOTES', accent: '#0F766E', items: active },
    { title: 'ARCHIVED NOTES', accent: '#64748B', items: archived },
  ];

  for (const section of sections) {
    if (section.items.length === 0) continue;

    ensureSpace(140);
    // Section Divider Header
    page.ctx.fillStyle = section.accent;
    page.ctx.fillRect(MARGIN_X, cursorY + 8, 6, 26);

    page.ctx.fillStyle = '#0F172A';
    page.ctx.font = '700 24px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
    page.ctx.fillText(
      `${section.title} (${section.items.length})`,
      MARGIN_X + 18,
      cursorY + 29
    );

    page.ctx.strokeStyle = '#E2E8F0';
    page.ctx.lineWidth = 2;
    page.ctx.beginPath();
    page.ctx.moveTo(MARGIN_X, cursorY + 46);
    page.ctx.lineTo(PDF_PAGE_PX_W - MARGIN_X, cursorY + 46);
    page.ctx.stroke();

    cursorY += 66;

    for (const note of section.items) {
      globalIndex += 1;
      const colorOpt = getNoteColorOption(note.colorTag);
      const accentHex =
        colorOpt.swatchHex !== 'transparent' ? colorOpt.swatchHex : section.accent;

      const cardInnerPadX = 28;
      const textMaxW = CONTENT_W - cardInnerPadX * 2 - 8;

      const mctx = page.ctx;
      mctx.font = '700 25px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      const titleText = `#${String(globalIndex).padStart(2, '0')}  ${note.title.trim() || 'Untitled Note'}`;
      const titleLines = wrapMultilineText(mctx, titleText, textMaxW - 210);

      // Build structured metadata string
      const metaParts: string[] = [];
      metaParts.push(`Type: ${getNoteTypeLabel(note)}`);
      if (note.priority && note.priority !== 'normal') {
        metaParts.push(`Priority: ${note.priority.toUpperCase()}`);
      }
      if (note.labels && note.labels.length > 0) {
        metaParts.push(`Labels: ${note.labels.join(', ')}`);
      }
      metaParts.push(`Created: ${formatBackupDateTime(note.createdAt) || '—'}`);
      metaParts.push(`Modified: ${formatBackupDateTime(note.updatedAt) || '—'}`);
      if (note.reminderAt) {
        metaParts.push(`Reminder: ${formatBackupDateTime(note.reminderAt)}`);
      }
      const attSummary = getAttachmentsSummary(note);
      if (attSummary !== 'None') {
        metaParts.push(`Attachments: ${attSummary}`);
      }

      mctx.font = '500 17px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      const metaLines = wrapMultilineText(mctx, metaParts.join('  ·  '), textMaxW);

      // Prepare content rows (either checklist rows or text lines)
      const checklistRows: Array<{ checked: boolean; lines: string[] }> = [];
      let textBodyLines: string[] = [];

      mctx.font = '400 21px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      if (note.isChecklist && note.checklistItems && note.checklistItems.length > 0) {
        for (const item of note.checklistItems) {
          const itemLines = wrapMultilineText(
            mctx,
            item.text.trim() || '(empty item)',
            textMaxW - 36
          );
          checklistRows.push({ checked: item.checked, lines: itemLines });
        }
        if (note.content.trim()) {
          textBodyLines = wrapMultilineText(mctx, note.content.trim(), textMaxW);
        }
      } else {
        const plain = getNotePlainDetails(note);
        textBodyLines = plain ? wrapMultilineText(mctx, plain, textMaxW) : ['(Empty note)'];
      }

      const thumb = thumbnails.get(note.id) ?? null;
      const thumbDrawH = thumb ? Math.min(180, Math.round((thumb.height / thumb.width) * 260)) : 0;
      const thumbDrawW = thumb
        ? Math.min(260, Math.round((thumb.width / thumb.height) * thumbDrawH))
        : 0;

      const headerH = 22 + titleLines.length * 32 + metaLines.length * 24 + 18;
      const checklistH = checklistRows.reduce(
        (acc, r) => acc + r.lines.length * 29 + 6,
        0
      );
      const bodyH = textBodyLines.length * 29 + (checklistRows.length > 0 && textBodyLines.length > 0 ? 12 : 0);
      const thumbH = thumb ? thumbDrawH + 16 : 0;
      const calcH = note.totalCalculation !== 0 ? 48 : 0;
      const estimatedFullCardH = headerH + checklistH + bodyH + thumbH + calcH + 26;

      // If entire note fits on next page cleanly and won't fit here, move to next page
      if (estimatedFullCardH <= SAFE_BOTTOM_Y - 80 && cursorY + estimatedFullCardH > SAFE_BOTTOM_Y) {
        page = createA4Page();
        pages.push(page);
        cursorY = 64;
      } else {
        // Ensure at least header + a couple lines fit before starting card
        ensureSpace(Math.min(estimatedFullCardH, headerH + 90));
      }

      // Draw card header + progressive chunks across page breaks if needed
      let cardStartY = cursorY;
      let y = cursorY + 28;
      const drawCardFrame = (topY: number, bottomY: number) => {
        const ctx = page.ctx;
        ctx.save();
        ctx.strokeStyle = '#CBD5E1';
        ctx.lineWidth = 1.5;
        ctx.fillStyle = '#FFFFFF';
        ctx.globalCompositeOperation = 'destination-over';
        ctx.beginPath();
        ctx.roundRect(MARGIN_X, topY, CONTENT_W, bottomY - topY, 14);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        ctx.stroke();

        // Left colored ribbon
        ctx.fillStyle = accentHex;
        ctx.beginPath();
        ctx.roundRect(MARGIN_X, topY, 9, bottomY - topY, [14, 0, 0, 14]);
        ctx.fill();
        ctx.restore();
      };

      const ctx = page.ctx;
      // Title & right badge
      ctx.fillStyle = '#0F172A';
      ctx.font = '700 25px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      titleLines.forEach((line, idx) => {
        ctx.fillText(line, MARGIN_X + cardInnerPadX, y + idx * 32);
      });

      ctx.textAlign = 'right';
      ctx.fillStyle = accentHex;
      ctx.font = '700 17px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      ctx.fillText(
        `${note.isPinned ? 'PINNED · ' : ''}${getNoteTypeLabel(note).toUpperCase()}`,
        PDF_PAGE_PX_W - MARGIN_X - 22,
        y
      );
      ctx.textAlign = 'left';

      y += titleLines.length * 32 + 4;

      // Meta lines
      ctx.fillStyle = '#64748B';
      ctx.font = '500 17px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      metaLines.forEach((line, idx) => {
        ctx.fillText(line, MARGIN_X + cardInnerPadX, y + idx * 24);
      });
      y += metaLines.length * 24 + 8;

      // Header separator inside card
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(MARGIN_X + cardInnerPadX, y);
      ctx.lineTo(PDF_PAGE_PX_W - MARGIN_X - 22, y);
      ctx.stroke();
      y += 26;

      const breakCardPage = () => {
        drawCardFrame(cardStartY, y + 10);
        page = createA4Page();
        pages.push(page);
        cardStartY = 64;
        y = cardStartY + 34;
        page.ctx.fillStyle = '#64748B';
        page.ctx.font = '600 16px system-ui, -apple-system, sans-serif';
        page.ctx.fillText(
          `${titleText} (continued)`,
          MARGIN_X + cardInnerPadX,
          y
        );
        y += 30;
      };

      // Draw checklist items
      for (const row of checklistRows) {
        const rowH = row.lines.length * 29 + 6;
        if (y + rowH > SAFE_BOTTOM_Y - 24) {
          breakCardPage();
        }
        drawCheckboxGlyph(page.ctx, MARGIN_X + cardInnerPadX, y, row.checked);
        page.ctx.fillStyle = row.checked ? '#94A3B8' : '#1E293B';
        page.ctx.font = '400 21px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
        row.lines.forEach((line, lIdx) => {
          page.ctx.fillText(line, MARGIN_X + cardInnerPadX + 30, y + lIdx * 29);
        });
        y += rowH;
      }

      if (checklistRows.length > 0 && textBodyLines.length > 0) {
        y += 10;
      }

      // Draw text body lines
      for (const line of textBodyLines) {
        if (y + 29 > SAFE_BOTTOM_Y - 24) {
          breakCardPage();
        }
        page.ctx.fillStyle = line === '(Empty note)' ? '#94A3B8' : '#1E293B';
        page.ctx.font = '400 21px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
        page.ctx.fillText(line, MARGIN_X + cardInnerPadX, y);
        y += 29;
      }

      // Optional image/drawing thumbnail
      if (thumb) {
        if (y + thumbDrawH + 16 > SAFE_BOTTOM_Y - 24) {
          breakCardPage();
        }
        y += 6;
        page.ctx.save();
        page.ctx.strokeStyle = '#E2E8F0';
        page.ctx.lineWidth = 2;
        page.ctx.drawImage(thumb, MARGIN_X + cardInnerPadX, y, thumbDrawW, thumbDrawH);
        page.ctx.strokeRect(MARGIN_X + cardInnerPadX, y, thumbDrawW, thumbDrawH);
        page.ctx.restore();
        y += thumbDrawH + 14;
      }

      // Optional calculation total bar
      if (note.totalCalculation !== 0) {
        if (y + 46 > SAFE_BOTTOM_Y - 16) {
          breakCardPage();
        }
        y += 4;
        page.ctx.fillStyle = '#EEF2FF';
        page.ctx.strokeStyle = '#C7D2FE';
        page.ctx.lineWidth = 1.5;
        page.ctx.beginPath();
        page.ctx.roundRect(MARGIN_X + cardInnerPadX, y, 310, 38, 10);
        page.ctx.fill();
        page.ctx.stroke();

        page.ctx.fillStyle = '#3730A3';
        page.ctx.font = '700 18px ui-monospace, SFMono-Regular, Menlo, monospace';
        page.ctx.fillText(
          `Calculation Total: ${formatResult(note.totalCalculation)}`,
          MARGIN_X + cardInnerPadX + 14,
          y + 25
        );
        y += 44;
      }

      const cardBottomY = y + 12;
      drawCardFrame(cardStartY, cardBottomY);
      cursorY = cardBottomY + 20;
    }
  }

  // Stamp clean page footers across all pages
  const totalPages = pages.length;
  pages.forEach((p, idx) => {
    const fctx = p.ctx;
    fctx.strokeStyle = '#E2E8F0';
    fctx.lineWidth = 1.5;
    fctx.beginPath();
    fctx.moveTo(MARGIN_X, PDF_PAGE_PX_H - FOOTER_H);
    fctx.lineTo(PDF_PAGE_PX_W - MARGIN_X, PDF_PAGE_PX_H - FOOTER_H);
    fctx.stroke();

    fctx.fillStyle = '#64748B';
    fctx.font = '500 17px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
    fctx.fillText(
      `SmartNotesPro Local Backup · ${exportedAtStr}`,
      MARGIN_X,
      PDF_PAGE_PX_H - 28
    );

    fctx.textAlign = 'right';
    fctx.fillText(
      `Page ${idx + 1} of ${totalPages}`,
      PDF_PAGE_PX_W - MARGIN_X,
      PDF_PAGE_PX_H - 28
    );
    fctx.textAlign = 'left';
  });

  return pages.map((p) => p.canvas);
}

function encodeUtf8ToBase64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

function decodeBase64ToUtf8(base64: string): string {
  const binary = atob(base64.replace(/\s+/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder('utf-8').decode(bytes);
}

function canvasToJpegBytes(canvas: HTMLCanvasElement): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      async (blob) => {
        if (!blob) {
          reject(new Error('Failed to encode PDF page image'));
          return;
        }
        resolve(new Uint8Array(await blob.arrayBuffer()));
      },
      'image/jpeg',
      0.92
    );
  });
}

function buildMultiPageBackupPdfBytes(
  pageJpegs: Array<{ bytes: Uint8Array; width: number; height: number }>,
  embeddedPayload: string
): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [];
  let cursor = 0;

  const pushStr = (s: string) => {
    const b = encoder.encode(s);
    chunks.push(b);
    cursor += b.length;
  };
  const pushBytes = (b: Uint8Array) => {
    chunks.push(b);
    cursor += b.length;
  };

  pushStr('%PDF-1.4\n%\xFF\xFF\xFF\xFF\n');

  // 1: Catalog
  offsets.push(cursor);
  pushStr('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  // Compute object numbering:
  // 2: Pages
  // For each page i: pageObj = 3 + i*3, imgObj = 4 + i*3, contentObj = 5 + i*3
  const pageObjIds = pageJpegs.map((_, i) => 3 + i * 3);
  offsets.push(cursor);
  pushStr(
    `2 0 obj\n<< /Type /Pages /Kids [${pageObjIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pageJpegs.length} >>\nendobj\n`
  );

  pageJpegs.forEach((p, i) => {
    const pageId = 3 + i * 3;
    const imgId = pageId + 1;
    const contentId = pageId + 2;

    const contentStream = `q ${PDF_PT_W} 0 0 ${PDF_PT_H} 0 0 cm /Im${i} Do Q`;
    const contentBytes = encoder.encode(contentStream);

    // Page object
    offsets.push(cursor);
    pushStr(
      `${pageId} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PDF_PT_W} ${PDF_PT_H}] /Resources << /XObject << /Im${i} ${imgId} 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`
    );

    // Image XObject
    offsets.push(cursor);
    pushStr(
      `${imgId} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${p.width} /Height ${p.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.bytes.length} >>\nstream\n`
    );
    pushBytes(p.bytes);
    pushStr('\nendstream\nendobj\n');

    // Page Content stream
    offsets.push(cursor);
    pushStr(`${contentId} 0 obj\n<< /Length ${contentBytes.length} >>\nstream\n`);
    pushBytes(contentBytes);
    pushStr('\nendstream\nendobj\n');
  });

  // Non-rendered embedded lossless restore stream object
  const backupObjId = 3 + pageJpegs.length * 3;
  const wrappedPayload = `${BACKUP_START_MARKER}${embeddedPayload}${BACKUP_END_MARKER}`;
  const backupBytes = encoder.encode(wrappedPayload);
  offsets.push(cursor);
  pushStr(
    `${backupObjId} 0 obj\n<< /Subtype /SmartNotesProBackup /Length ${backupBytes.length} >>\nstream\n`
  );
  pushBytes(backupBytes);
  pushStr('\nendstream\nendobj\n');

  const xrefOffset = cursor;
  pushStr(`xref\n0 ${offsets.length + 1}\n0000000000 65535 f \n`);
  for (const off of offsets) {
    pushStr(`${String(off).padStart(10, '0')} 00000 n \n`);
  }
  pushStr(
    `trailer\n<< /Size ${offsets.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`
  );

  const out = new Uint8Array(cursor);
  let pos = 0;
  for (const chunk of chunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  return out;
}

export async function downloadNotesAsPdf(notes: readonly Note[]): Promise<void> {
  const canvases = await renderOrganizedBackupPages(notes);
  const pageJpegs = await Promise.all(
    canvases.map(async (canvas) => ({
      bytes: await canvasToJpegBytes(canvas),
      width: canvas.width,
      height: canvas.height,
    }))
  );

  const { ordered } = sortNotesForOrganizedBackup(notes);
  const payloadBase64 = encodeUtf8ToBase64(encodeNotesJson(ordered));
  const pdfBytes = buildMultiPageBackupPdfBytes(pageJpegs, payloadBase64);

  const stamp = new Date().toISOString().slice(0, 10);
  await saveAndShareBinaryFile({
    filename: `smartnotes-backup-${stamp}.pdf`,
    bytes: pdfBytes,
    mimeType: 'application/pdf',
    shareTitle: 'SmartNotesPro PDF Backup',
  });
}

function bytesToLatin1String(bytes: Uint8Array): string {
  const parts: string[] = [];
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    parts.push(String.fromCharCode(...chunk));
  }
  return parts.join('');
}

export function decodeNotesPdf(fileBytes: Uint8Array): Note[] | null {
  try {
    if (fileBytes.length < 10) return null;
    const header = String.fromCharCode(...fileBytes.subarray(0, 5));
    if (header !== '%PDF-') return null;

    const rawText = bytesToLatin1String(fileBytes);
    const startIdx = rawText.indexOf(BACKUP_START_MARKER);
    if (startIdx !== -1) {
      const payloadStart = startIdx + BACKUP_START_MARKER.length;
      const endIdx = rawText.indexOf(BACKUP_END_MARKER, payloadStart);
      if (endIdx !== -1) {
        const base64 = rawText.slice(payloadStart, endIdx);
        const decodedJson = decodeBase64ToUtf8(base64);
        const notes = decodeNotesJson(decodedJson);
        if (notes && notes.length > 0) {
          return notes;
        }
      }
    }

    // Fallback for external text-based PDFs: extract literal "(...)" strings from Tj/TJ operators
    const extractedLines: string[] = [];
    const literalRegex = /\(([^()\\]*(?:\\.[^()\\]*)*)\)\s*Tj/g;
    let m: RegExpExecArray | null;
    while ((m = literalRegex.exec(rawText)) !== null) {
      const cleaned = m[1]
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '')
        .replace(/\\t/g, ' ')
        .replace(/\\\(/g, '(')
        .replace(/\\\)/g, ')')
        .replace(/\\\\/g, '\\')
        .trim();
      if (cleaned) extractedLines.push(cleaned);
    }

    if (extractedLines.length > 0) {
      const now = Date.now();
      return [
        {
          id: 0,
          title: 'Imported PDF Note',
          content: extractedLines.join('\n'),
          fontSize: DEFAULT_NOTE_FONT_SIZE,
          totalCalculation: 0,
          colorTag: 0,
          backgroundId: 'none',
          labels: [],
          isPinned: false,
          isArchived: false,
          isChecklist: false,
          checklistItems: [],
          attachments: [],
          createdAt: now,
          updatedAt: now,
          reminderAt: null,
          priority: 'normal',
          isDeleted: false,
          deletedAt: null,
        },
      ];
    }

    return null;
  } catch {
    return null;
  }
}
