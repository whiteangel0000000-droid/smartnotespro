import {
  Delete,
  Fingerprint,
  Lock,
  ShieldCheck,
  X,
} from 'lucide-react';
import React, { useCallback, useEffect, useState } from 'react';
import {
  authenticateWithVaultBiometric,
  configureVaultPin,
  SecurityVaultState,
  verifyVaultPin,
} from '../../data/storage/securityVault';

interface AppLockOverlayProps {
  vaultState: SecurityVaultState;
  onUnlock: (nextState: SecurityVaultState) => void;
  onVaultStateChange: (nextState: SecurityVaultState) => void;
}

export function AppLockOverlay({
  vaultState,
  onUnlock,
  onVaultStateChange,
}: AppLockOverlayProps) {
  const [digits, setDigits] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [biometricBusy, setBiometricBusy] = useState(false);
  const [cooldownSec, setCooldownSec] = useState(0);

  const pinLen = vaultState.pinLength;

  useEffect(() => {
    const updateCooldown = () => {
      if (vaultState.lockoutUntil && vaultState.lockoutUntil > Date.now()) {
        setCooldownSec(Math.ceil((vaultState.lockoutUntil - Date.now()) / 1000));
      } else {
        setCooldownSec(0);
      }
    };
    updateCooldown();
    const timer = window.setInterval(updateCooldown, 500);
    return () => window.clearInterval(timer);
  }, [vaultState.lockoutUntil]);

  const submitPin = useCallback(
    async (candidate: string) => {
      if (checking || cooldownSec > 0) return;
      setChecking(true);
      setErrorMsg(null);
      try {
        const res = await verifyVaultPin(candidate);
        onVaultStateChange(res.state);
        if (res.ok) {
          setDigits('');
          onUnlock(res.state);
        } else {
          setDigits('');
          setErrorMsg(res.error ?? 'Incorrect PIN');
          if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
            try {
              navigator.vibrate([30, 40, 30]);
            } catch {
              // Ignore
            }
          }
        }
      } finally {
        setChecking(false);
      }
    },
    [checking, cooldownSec, onUnlock, onVaultStateChange]
  );

  const handleDigit = useCallback(
    (d: string) => {
      if (checking || cooldownSec > 0) return;
      setErrorMsg(null);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate(8);
        } catch {
          // Ignore
        }
      }
      setDigits((prev) => {
        if (prev.length >= pinLen) return prev;
        const next = prev + d;
        if (next.length === pinLen) {
          void submitPin(next);
        }
        return next;
      });
    },
    [checking, cooldownSec, pinLen, submitPin]
  );

  const handleBackspace = useCallback(() => {
    if (checking) return;
    setErrorMsg(null);
    setDigits((prev) => prev.slice(0, -1));
  }, [checking]);

  const handleBiometricUnlock = useCallback(async () => {
    if (biometricBusy || !vaultState.biometricEnabled) return;
    setBiometricBusy(true);
    setErrorMsg(null);
    try {
      const res = await authenticateWithVaultBiometric();
      if (res.ok) {
        const next = res.state ?? { ...vaultState, isLocked: false };
        onVaultStateChange(next);
        onUnlock(next);
      } else if (res.error) {
        setErrorMsg(res.error);
      }
    } finally {
      setBiometricBusy(false);
    }
  }, [biometricBusy, vaultState, onUnlock, onVaultStateChange]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleDigit, handleBackspace]);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-gradient-to-b from-[#0A0F1E] via-[#0F172A] to-[#080B14] text-slate-100 p-6 select-none"
      role="dialog"
      aria-modal="true"
      aria-label="SmartNotesPro Vault Lock"
    >
      <div className="w-full max-w-sm flex flex-col items-center text-center">
        {/* Prestigious Vault Crest */}
        <div className="relative mb-6">
          <div className="w-18 h-18 rounded-3xl bg-gradient-to-br from-amber-300/20 via-indigo-400/15 to-slate-800/80 border border-amber-200/30 shadow-2xl flex items-center justify-center">
            <ShieldCheck className="w-8 h-8 text-amber-200" />
          </div>
          <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-slate-900 border border-amber-200/40 flex items-center justify-center">
            <Lock className="w-3 h-3 text-amber-200" />
          </span>
        </div>

        <h1 className="font-display text-2xl font-semibold tracking-tight text-white">
          SmartNotesPro Vault
        </h1>
        <p className="mt-1.5 text-xs text-slate-400">
          {cooldownSec > 0
            ? `Security cooldown active · ${cooldownSec}s`
            : `Enter your ${pinLen}-digit PIN to unlock`}
        </p>

        {/* PIN Indicators */}
        <div
          className="mt-7 mb-4 flex items-center justify-center gap-3.5"
          aria-label={`${digits.length} of ${pinLen} digits entered`}
        >
          {Array.from({ length: pinLen }).map((_, i) => {
            const filled = i < digits.length;
            return (
              <span
                key={i}
                className={`w-3.5 h-3.5 rounded-full border transition-all duration-150 ${
                  filled
                    ? 'bg-amber-200 border-amber-200 scale-110 shadow-[0_0_12px_rgba(253,230,138,0.45)]'
                    : 'border-slate-600 bg-slate-900/60'
                }`}
              />
            );
          })}
        </div>

        <div className="min-h-[20px] mb-4">
          {errorMsg && (
            <p className="text-xs font-medium text-rose-300">{errorMsg}</p>
          )}
        </div>

        {/* Precision Tactile Keypad */}
        <div className="grid grid-cols-3 gap-3.5 w-full max-w-[264px]">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
            <button
              key={d}
              type="button"
              disabled={checking || cooldownSec > 0}
              onClick={() => handleDigit(d)}
              className="h-16 w-16 mx-auto rounded-full border border-white/10 bg-white/[0.05] hover:bg-white/[0.12] active:scale-95 text-xl font-medium text-white tabular-nums transition-all disabled:opacity-35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70"
            >
              {d}
            </button>
          ))}

          {vaultState.biometricEnabled ? (
            <button
              type="button"
              disabled={biometricBusy || cooldownSec > 0}
              onClick={handleBiometricUnlock}
              aria-label="Unlock with fingerprint"
              title="Unlock with Fingerprint"
              className="h-16 w-16 mx-auto rounded-full border border-amber-200/30 bg-amber-200/10 hover:bg-amber-200/20 active:scale-95 text-amber-200 flex items-center justify-center transition-all disabled:opacity-35"
            >
              <Fingerprint className="w-6 h-6" />
            </button>
          ) : (
            <span />
          )}

          <button
            type="button"
            disabled={checking || cooldownSec > 0}
            onClick={() => handleDigit('0')}
            className="h-16 w-16 mx-auto rounded-full border border-white/10 bg-white/[0.05] hover:bg-white/[0.12] active:scale-95 text-xl font-medium text-white tabular-nums transition-all disabled:opacity-35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70"
          >
            0
          </button>

          <button
            type="button"
            disabled={digits.length === 0 || checking}
            onClick={handleBackspace}
            aria-label="Backspace"
            className="h-16 w-16 mx-auto rounded-full border border-white/10 bg-white/[0.03] hover:bg-white/[0.1] active:scale-95 text-slate-300 flex items-center justify-center transition-all disabled:opacity-25"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {vaultState.biometricEnabled && (
          <button
            type="button"
            onClick={handleBiometricUnlock}
            disabled={biometricBusy || cooldownSec > 0}
            className="mt-7 inline-flex items-center gap-2 px-4 py-2 rounded-full border border-amber-200/25 bg-amber-200/10 hover:bg-amber-200/20 text-xs font-medium text-amber-100 transition-colors"
          >
            <Fingerprint className="w-4 h-4" />
            <span>{biometricBusy ? 'Verifying...' : 'Use Fingerprint / Biometrics'}</span>
          </button>
        )}
      </div>
    </div>
  );
}

interface PinSetupModalProps {
  mode: 'create' | 'change' | 'disable' | 'enroll-biometric';
  currentPinLength?: 4 | 6;
  onSuccess: (nextState: SecurityVaultState, infoMsg?: string) => void;
  onVerifyOnly?: (pin: string) => Promise<void>;
  onClose: () => void;
}

export function PinSetupModal({
  mode,
  currentPinLength = 4,
  onSuccess,
  onVerifyOnly,
  onClose,
}: PinSetupModalProps) {
  const [step, setStep] = useState<'verify' | 'enter' | 'confirm'>(
    mode === 'create' ? 'enter' : 'verify'
  );
  const [pinLength, setPinLength] = useState<4 | 6>(currentPinLength);
  const [verifiedPin, setVerifiedPin] = useState('');
  const [firstPin, setFirstPin] = useState('');
  const [inputPin, setInputPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const heading =
    step === 'verify'
      ? mode === 'disable'
        ? 'Verify PIN to remove Vault lock'
        : mode === 'enroll-biometric'
          ? 'Verify PIN to enable Fingerprint'
          : 'Verify current PIN'
      : step === 'enter'
        ? mode === 'change'
          ? 'Enter new PIN'
          : 'Create Vault PIN'
        : 'Confirm your PIN';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const clean = inputPin.replace(/\D/g, '');
    const requiredLen = step === 'verify' ? currentPinLength : pinLength;
    if (clean.length !== requiredLen) {
      setError(`Please enter exactly ${requiredLen} digits.`);
      return;
    }
    setError(null);
    setBusy(true);
    try {
      if (step === 'verify') {
        const res = await verifyVaultPin(clean);
        if (!res.ok) {
          setError(res.error ?? 'Incorrect PIN');
          setInputPin('');
          return;
        }
        setVerifiedPin(clean);
        setInputPin('');
        if (mode === 'disable' || mode === 'enroll-biometric') {
          if (onVerifyOnly) {
            await onVerifyOnly(clean);
          }
          return;
        }
        setStep('enter');
        return;
      }

      if (step === 'enter') {
        setFirstPin(clean);
        setInputPin('');
        setStep('confirm');
        return;
      }

      if (clean !== firstPin) {
        setError('PINs do not match. Try again.');
        setInputPin('');
        setStep('enter');
        setFirstPin('');
        return;
      }

      const nextState = await configureVaultPin(clean);
      onSuccess(
        nextState,
        mode === 'change'
          ? 'Vault PIN updated.'
          : 'Vault PIN protection enabled.'
      );
    } finally {
      setBusy(false);
    }
  };

  // Keep unused verifiedPin suppressed cleanly if needed for future audit
  void verifiedPin;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label={heading}
      onClick={onClose}
    >
      <form
        onSubmit={handleSubmit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-3xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl p-6 space-y-4"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {heading}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close PIN dialog"
            className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {step === 'enter' && (
          <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            {([4, 6] as const).map((len) => (
              <button
                key={len}
                type="button"
                onClick={() => {
                  setPinLength(len);
                  setInputPin('');
                }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  pinLength === len
                    ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {len}-digit PIN
              </button>
            ))}
          </div>
        )}

        <input
          type="password"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={step === 'verify' ? currentPinLength : pinLength}
          value={inputPin}
          onChange={(e) => {
            setInputPin(e.target.value.replace(/\D/g, ''));
            setError(null);
          }}
          autoFocus
          placeholder={`Enter ${step === 'verify' ? currentPinLength : pinLength} digits`}
          className="w-full text-center tracking-[0.5em] font-mono text-xl rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-4 py-3 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />

        {error && (
          <p className="text-xs text-rose-600 dark:text-rose-400 text-center">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] px-4 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={busy}
            className="min-h-[40px] px-5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold disabled:opacity-45"
          >
            {step === 'confirm' ? 'Activate Vault' : 'Continue'}
          </button>
        </div>
      </form>
    </div>
  );
}
