import { Check, Mic, Square, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

interface AudioRecorderModalProps {
  onSave: (dataUrl: string, durationSec: number) => void;
  onClose: () => void;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function AudioRecorderModal({ onSave, onClose }: AudioRecorderModalProps) {
  const [status, setStatus] = useState<'idle' | 'recording' | 'ready' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [seconds, setSeconds] = useState(0);
  const [audioDataUrl, setAudioDataUrl] = useState<string | null>(null);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const secondsRef = useRef(0);

  const cleanupStream = () => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    startRecording();
    return () => {
      if (recorderRef.current && recorderRef.current.state !== 'inactive') {
        recorderRef.current.stop();
      }
      cleanupStream();
    };
  }, []);

  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus('error');
      setErrorMsg('Audio recording is not supported in this browser.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      secondsRef.current = 0;
      setSeconds(0);
      setAudioDataUrl(null);

      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setAudioDataUrl(reader.result);
            setStatus('ready');
          }
        };
        reader.readAsDataURL(blob);
        cleanupStream();
      };

      recorder.start();
      setStatus('recording');
      timerRef.current = window.setInterval(() => {
        secondsRef.current += 1;
        setSeconds(secondsRef.current);
      }, 1000);
    } catch {
      setStatus('error');
      setErrorMsg('Microphone permission was denied or no microphone is available.');
    }
  };

  const stopRecording = () => {
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Voice recording"
    >
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Voice Recording
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cancel recording"
            className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {status === 'error' ? (
          <div className="text-center space-y-4 py-4">
            <p className="text-sm text-rose-600 dark:text-rose-400">{errorMsg}</p>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] px-5 py-2 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-medium"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-5">
            <div
              className={`w-20 h-20 rounded-full flex items-center justify-center ${
                status === 'recording'
                  ? 'bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 ring-4 ring-rose-500/20'
                  : 'bg-indigo-100 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400'
              }`}
            >
              <Mic className="w-8 h-8" />
            </div>

            <div className="font-mono text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {formatDuration(seconds)}
            </div>

            {status === 'recording' && (
              <button
                type="button"
                onClick={stopRecording}
                className="inline-flex items-center gap-2 min-h-[44px] px-6 py-2.5 rounded-full bg-rose-600 hover:bg-rose-700 text-sm font-semibold text-white transition-colors"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Stop Recording</span>
              </button>
            )}

            {status === 'ready' && audioDataUrl && (
              <div className="w-full space-y-4">
                <audio controls src={audioDataUrl} className="w-full h-10" />
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={startRecording}
                    className="min-h-[40px] px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    Re-record
                  </button>
                  <button
                    type="button"
                    onClick={() => onSave(audioDataUrl, Math.max(1, seconds))}
                    className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white"
                  >
                    <Check className="w-4 h-4" />
                    <span>Attach to Note</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
