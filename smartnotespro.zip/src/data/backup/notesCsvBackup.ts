import {
  ChecklistItem,
  DEFAULT_NOTE_FONT_SIZE,
  getNoteColorOption,
  Note,
  NOTE_BACKGROUNDS,
  NOTE_COLOR_PALETTE,
  NoteBackgroundId,
  NotePriority,
  sanitizeBackground,
  sanitizeColor,
  sanitizeLabels,
  sanitizePriority,
  sanitizeReminderAt,
} from '../../domain/model/note';
import { saveAndShareTextFile } from '../../utils/androidBridge';
import { formatResult } from '../../utils/mathEvaluator';
import { extractPlainTextFromHtml } from '../../utils/richText';

const CSV_HEADERS = [
  '#',
  'Section',
  'Title',
  'Note Type',
  'Priority',
  'Labels',
  'Pinned',
  'Created Date',
  'Modified Date',
  'Reminder',
  'Calculation Total',
  'Note Color',
  'Background',
  'Checklist Progress',
  'Attachments',
  'Full Details',
] as const;

export function formatBackupDateTime(ts: number | null | undefined): string {
  if (!ts || !Number.isFinite(ts) || ts <= 0) return '';
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function parseBackupDateTime(raw: string): number {
  const trimmed = raw.trim();
  if (!trimmed || trimmed.toLowerCase() === 'none') return 0;
  // Handle "YYYY-MM-DD HH:mm" in local time
  const match = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/.exec(
    trimmed
  );
  if (match) {
    const year = Number(match[1]);
    const month = Number(match[2]) - 1;
    const day = Number(match[3]);
    const hour = match[4] ? Number(match[4]) : 0;
    const minute = match[5] ? Number(match[5]) : 0;
    const second = match[6] ? Number(match[6]) : 0;
    const dt = new Date(year, month, day, hour, minute, second);
    const ms = dt.getTime();
    return Number.isFinite(ms) ? ms : 0;
  }
  const parsed = Date.parse(trimmed);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function sortNotesForOrganizedBackup(notes: readonly Note[]): {
  pinned: Note[];
  active: Note[];
  archived: Note[];
  ordered: Note[];
} {
  const live = notes.filter((n) => !n.isDeleted);
  const pinned = live
    .filter((n) => !n.isArchived && n.isPinned)
    .sort((a, b) => b.updatedAt - a.updatedAt);
  const active = live
    .filter((n) => !n.isArchived && !n.isPinned)
    .sort((a, b) => b.updatedAt - a.updatedAt);
  const archived = live
    .filter((n) => Boolean(n.isArchived))
    .sort((a, b) => b.updatedAt - a.updatedAt);

  return {
    pinned,
    active,
    archived,
    ordered: [...pinned, ...active, ...archived],
  };
}

function getSectionLabel(note: Note): string {
  if (note.isArchived) return 'Archived';
  if (note.isPinned) return 'Pinned';
  return 'Active';
}

export function getNoteTypeLabel(note: Note): string {
  if (note.isChecklist) return 'Checklist';
  const atts = note.attachments ?? [];
  if (atts.some((a) => a.type === 'audio')) return 'Audio Note';
  if (atts.some((a) => a.type === 'drawing')) return 'Handwriting Note';
  if (atts.some((a) => a.type === 'image')) return 'Image Note';
  return 'Text Note';
}

export function getAttachmentsSummary(note: Note): string {
  const atts = note.attachments ?? [];
  if (atts.length === 0) return 'None';
  const imgs = atts.filter((a) => a.type === 'image').length;
  const drawings = atts.filter((a) => a.type === 'drawing').length;
  const audio = atts.filter((a) => a.type === 'audio').length;
  const parts: string[] = [];
  if (imgs > 0) parts.push(`${imgs} ${imgs === 1 ? 'image' : 'images'}`);
  if (drawings > 0) parts.push(`${drawings} ${drawings === 1 ? 'drawing' : 'drawings'}`);
  if (audio > 0) parts.push(`${audio} ${audio === 1 ? 'audio clip' : 'audio clips'}`);
  return parts.join(', ') || 'None';
}

export function getNotePlainDetails(note: Note): string {
  if (note.isChecklist && note.checklistItems && note.checklistItems.length > 0) {
    const lines = note.checklistItems.map(
      (item) => `${item.checked ? '[x]' : '[ ]'} ${item.text}`
    );
    const extra = (note.content || '').trim();
    return extra ? `${lines.join('\n')}\n\n${extra}` : lines.join('\n');
  }
  const content = note.content || extractPlainTextFromHtml(note.richContent || '');
  return content.trim();
}

function escapeCsvCell(value: string): string {
  if (/[",\r\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export function encodeNotesCsv(notes: readonly Note[]): string {
  const { ordered } = sortNotesForOrganizedBackup(notes);
  const rows: string[] = [CSV_HEADERS.map(escapeCsvCell).join(',')];

  ordered.forEach((note, index) => {
    const colorName = getNoteColorOption(note.colorTag).name;
    const bgId = note.backgroundId ?? 'none';
    const bgName =
      bgId === 'custom'
        ? 'Custom Image'
        : NOTE_BACKGROUNDS.find((b) => b.id === bgId)?.name ?? 'None';
    const checklistItems = note.checklistItems ?? [];
    const doneCount = checklistItems.filter((i) => i.checked).length;
    const checklistProgress = note.isChecklist
      ? `${doneCount}/${checklistItems.length} completed`
      : '—';
    const priority = note.priority ?? 'normal';
    const priorityLabel = priority.charAt(0).toUpperCase() + priority.slice(1);

    const row = [
      String(index + 1),
      getSectionLabel(note),
      note.title.trim() || 'Untitled Note',
      getNoteTypeLabel(note),
      priorityLabel,
      (note.labels ?? []).join('; '),
      note.isPinned ? 'Yes' : 'No',
      formatBackupDateTime(note.createdAt),
      formatBackupDateTime(note.updatedAt),
      note.reminderAt ? formatBackupDateTime(note.reminderAt) : 'None',
      note.totalCalculation ? formatResult(note.totalCalculation) : '0',
      colorName,
      bgName,
      checklistProgress,
      getAttachmentsSummary(note),
      getNotePlainDetails(note),
    ];

    rows.push(row.map(escapeCsvCell).join(','));
  });

  // Prepend UTF-8 BOM for clean Excel / Google Sheets compatibility
  return `\uFEFF${rows.join('\r\n')}`;
}

export async function downloadNotesAsCsv(notes: readonly Note[]): Promise<void> {
  const csv = encodeNotesCsv(notes);
  const stamp = new Date().toISOString().slice(0, 10);
  await saveAndShareTextFile({
    filename: `smartnotes-backup-${stamp}.csv`,
    text: csv,
    mimeType: 'text/csv;charset=utf-8;',
    shareTitle: 'SmartNotesPro CSV Backup',
  });
}

function parseCsvRows(input: string): string[][] {
  const clean = input.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (inQuotes) {
      if (ch === '"') {
        if (clean[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
      continue;
    }

    if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      row.push(field);
      field = '';
    } else if (ch === '\r') {
      if (clean[i + 1] === '\n') i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else if (ch === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += ch;
    }
  }

  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }

  return rows.filter((r) => r.some((cell) => cell.trim().length > 0));
}

function resolveColorIndex(rawColor: string): number {
  const trimmed = rawColor.trim().toLowerCase();
  if (!trimmed) return 0;
  const byName = NOTE_COLOR_PALETTE.find((c) => c.name.toLowerCase() === trimmed);
  if (byName) return byName.index;
  const num = Number(trimmed);
  if (Number.isFinite(num)) return sanitizeColor(num);
  return 0;
}

function resolveBackgroundId(rawBg: string): NoteBackgroundId {
  const trimmed = rawBg.trim().toLowerCase();
  if (!trimmed || trimmed === 'none') return 'none';
  const match = NOTE_BACKGROUNDS.find(
    (b) => b.name.toLowerCase() === trimmed || b.id.toLowerCase() === trimmed
  );
  return match ? sanitizeBackground(match.id) : 'none';
}

export function decodeNotesCsv(csvText: string): Note[] | null {
  try {
    const rows = parseCsvRows(csvText);
    if (rows.length < 2) return null;

    const headers = rows[0].map((h) => h.trim().toLowerCase());
    const colIndex = (...candidates: string[]): number => {
      for (const name of candidates) {
        const idx = headers.indexOf(name.toLowerCase());
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const iSection = colIndex('section', 'status');
    const iTitle = colIndex('title', 'note title');
    const iType = colIndex('note type', 'type');
    const iPriority = colIndex('priority');
    const iLabels = colIndex('labels', 'tags');
    const iPinned = colIndex('pinned', 'is pinned');
    const iCreated = colIndex('created date', 'created', 'created at');
    const iModified = colIndex('modified date', 'updated date', 'modified', 'updated at');
    const iReminder = colIndex('reminder', 'reminder at');
    const iTotal = colIndex('calculation total', 'total', 'total calculation');
    const iColor = colIndex('note color', 'color', 'colour');
    const iBackground = colIndex('background');
    const iDetails = colIndex('full details', 'details', 'content', 'body', 'notes');

    // Must match at least Title or Full Details / Content column to be considered a valid note CSV
    if (iTitle === -1 && iDetails === -1) return null;

    const notes: Note[] = [];
    const baseNow = Date.now();

    for (let r = 1; r < rows.length; r++) {
      const cells = rows[r];
      const get = (idx: number) => (idx >= 0 && idx < cells.length ? cells[idx] : '');

      const rawTitle = get(iTitle).trim();
      const title = rawTitle === 'Untitled Note' ? '' : rawTitle;
      const details = get(iDetails);
      const typeVal = get(iType).trim().toLowerCase();
      const sectionVal = get(iSection).trim().toLowerCase();
      const pinnedVal = get(iPinned).trim().toLowerCase();

      const isArchived = sectionVal === 'archived' || sectionVal === 'archive';
      const isPinned =
        pinnedVal === 'yes' ||
        pinnedVal === 'true' ||
        pinnedVal === '1' ||
        (!isArchived && sectionVal === 'pinned');

      const lines = details.split(/\r?\n/);
      const checklistRegex = /^\[(x| )\]\s?(.*)$/i;
      const detectedChecklistLines = lines.filter((l) => checklistRegex.test(l.trim()));
      const isChecklist =
        typeVal === 'checklist' || detectedChecklistLines.length > 0;

      let checklistItems: ChecklistItem[] = [];
      let content = details;

      if (isChecklist) {
        const items: ChecklistItem[] = [];
        const leftoverLines: string[] = [];
        lines.forEach((line, idx) => {
          const m = checklistRegex.exec(line.trim());
          if (m) {
            items.push({
              id: `csv-chk-${baseNow}-${r}-${idx}`,
              checked: m[1].toLowerCase() === 'x',
              text: m[2] ?? '',
            });
          } else if (line.trim().length > 0) {
            leftoverLines.push(line);
          }
        });
        if (items.length === 0 && details.trim().length > 0) {
          lines
            .filter((l) => l.trim().length > 0)
            .forEach((line, idx) => {
              items.push({
                id: `csv-chk-${baseNow}-${r}-${idx}`,
                checked: false,
                text: line.trim(),
              });
            });
          content = '';
        } else {
          checklistItems = items;
          content = leftoverLines.join('\n').trim();
        }
        if (checklistItems.length === 0 && items.length > 0) {
          checklistItems = items;
        }
      }

      const rawLabels = get(iLabels).trim();
      const labels = rawLabels
        ? sanitizeLabels(rawLabels.split(/[;,]/).map((s) => s.trim()))
        : [];

      const createdAt = parseBackupDateTime(get(iCreated)) || baseNow;
      const updatedAt = parseBackupDateTime(get(iModified)) || createdAt;
      const parsedReminder = parseBackupDateTime(get(iReminder));
      const reminderAt = sanitizeReminderAt(parsedReminder > 0 ? parsedReminder : null);

      const rawTotal = Number(get(iTotal).replace(/,/g, '').trim());
      const totalCalculation = Number.isFinite(rawTotal) ? rawTotal : 0;

      const colorTag = resolveColorIndex(get(iColor));
      const backgroundId = resolveBackgroundId(get(iBackground));
      const priority: NotePriority = sanitizePriority(get(iPriority).trim().toLowerCase());

      notes.push({
        id: 0,
        title,
        content,
        fontSize: DEFAULT_NOTE_FONT_SIZE,
        totalCalculation,
        colorTag,
        backgroundId,
        labels,
        isPinned,
        isArchived,
        isChecklist,
        checklistItems,
        attachments: [],
        createdAt,
        updatedAt,
        reminderAt,
        priority,
        isDeleted: false,
        deletedAt: null,
      });
    }

    return notes.length > 0 ? notes : null;
  } catch {
    return null;
  }
}
