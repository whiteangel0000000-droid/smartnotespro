import { AlertTriangle, RotateCcw, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { formatResult } from '../../domain/calculator/expressionDetector';
import { Note } from '../../domain/model/note';
import { formatTimestamp } from '../utils/formatters';

interface TrashViewProps {
  trashedNotes: readonly Note[];
  onRestore: (id: number) => void;
  onDeletePermanently: (id: number) => void;
  onEmptyTrash: () => void;
}

export function TrashView({
  trashedNotes,
  onRestore,
  onDeletePermanently,
  onEmptyTrash,
}: TrashViewProps) {
  const [confirmEmptyOpen, setConfirmEmptyOpen] = useState(false);

  useEffect(() => {
    if (!confirmEmptyOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setConfirmEmptyOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [confirmEmptyOpen]);

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-white dark:bg-slate-950">
      <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
            Trash
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Notes in Trash are automatically deleted after 30 days.
          </p>
        </div>

        {trashedNotes.length > 0 && (
          <button
            type="button"
            onClick={() => setConfirmEmptyOpen(true)}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg border border-rose-200 dark:border-rose-900/70 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-xs font-medium text-rose-700 dark:text-rose-300 whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Empty Trash</span>
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {trashedNotes.length === 0 ? (
          <div className="h-full min-h-[320px] flex flex-col items-center justify-center text-center max-w-sm mx-auto">
            <div className="w-12 h-12 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-4">
              <Trash2 className="w-5 h-5" />
            </div>
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Trash is empty
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5">
              Deleted notes appear here so you can restore them within 30 days.
            </p>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto space-y-3">
            {trashedNotes.map((note) => (
              <div
                key={note.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="min-w-0 flex-1">
                  <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {note.title.trim() || 'Untitled'}
                  </h3>
                  {note.isChecklist && (note.checklistItems?.length ?? 0) > 0 ? (
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                      {note.checklistItems!
                        .map((i) => `${i.checked ? '☑' : '☐'} ${i.text}`)
                        .join(' · ')}
                    </p>
                  ) : (
                    note.content.trim() && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                        {note.content.trim()}
                      </p>
                    )
                  )}
                  <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                    <span>
                      Deleted {formatTimestamp(note.deletedAt ?? note.updatedAt)}
                    </span>
                    {note.totalCalculation !== 0 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono text-indigo-700 dark:text-indigo-300">
                          Total: {formatResult(note.totalCalculation)}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onRestore(note.id)}
                    className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeletePermanently(note.id)}
                    className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-medium text-rose-700 dark:text-rose-300 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {confirmEmptyOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="empty-trash-title"
          onClick={() => setConfirmEmptyOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3
                  id="empty-trash-title"
                  className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
                >
                  Empty Trash permanently?
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  This permanently deletes {trashedNotes.length}{' '}
                  {trashedNotes.length === 1 ? 'note' : 'notes'} and cannot be undone.
                </p>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmEmptyOpen(false)}
                className="min-h-[40px] px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onEmptyTrash();
                  setConfirmEmptyOpen(false);
                }}
                className="min-h-[40px] px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-xs font-medium text-white transition-colors"
              >
                Empty Trash
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
