import { Capacitor, registerPlugin } from '@capacitor/core';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { StatusBar, Style } from '@capacitor/status-bar';

interface BiometricVaultPluginInterface {
  isAvailable(): Promise<{ available: boolean }>;
  authenticate(options: {
    title?: string;
    subtitle?: string;
  }): Promise<{ verified: boolean }>;
}

const BiometricVault = registerPlugin<BiometricVaultPluginInterface>('BiometricVault');

export function isNativeApp(): boolean {
  return Capacitor.isNativePlatform();
}

export async function checkNativeBiometricAvailable(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const res = await BiometricVault.isAvailable();
    return Boolean(res?.available);
  } catch {
    return false;
  }
}

export async function promptNativeBiometric(
  title: string,
  subtitle: string
): Promise<{ verified: boolean; error?: string }> {
  if (!isNativeApp()) {
    return { verified: false, error: 'Native biometric prompt unavailable.' };
  }
  try {
    const res = await BiometricVault.authenticate({ title, subtitle });
    if (res?.verified) {
      return { verified: true };
    }
    return { verified: false, error: 'Fingerprint verification was cancelled.' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Fingerprint verification failed.';
    return { verified: false, error: msg };
  }
}

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

function triggerBrowserBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function saveAndShareTextFile(options: {
  filename: string;
  text: string;
  mimeType: string;
  shareTitle: string;
}): Promise<void> {
  if (!isNativeApp()) {
    const blob = new Blob([options.text], { type: options.mimeType });
    triggerBrowserBlobDownload(blob, options.filename);
    return;
  }

  let savedUri: string | null = null;
  try {
    const res = await Filesystem.writeFile({
      path: `SmartNotesPro/${options.filename}`,
      data: options.text,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
      recursive: true,
    });
    savedUri = res.uri;
  } catch {
    const cacheRes = await Filesystem.writeFile({
      path: options.filename,
      data: options.text,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
      recursive: true,
    });
    savedUri = cacheRes.uri;
  }

  if (savedUri) {
    try {
      await Share.share({
        title: options.shareTitle,
        url: savedUri,
        dialogTitle: options.shareTitle,
      });
    } catch {
      // User dismissed share sheet; file is already written locally
    }
  }
}

export async function saveAndShareBinaryFile(options: {
  filename: string;
  bytes: Uint8Array;
  mimeType: string;
  shareTitle: string;
}): Promise<void> {
  if (!isNativeApp()) {
    const arrayBuffer = options.bytes.buffer.slice(
      options.bytes.byteOffset,
      options.bytes.byteOffset + options.bytes.byteLength
    ) as ArrayBuffer;
    const blob = new Blob([arrayBuffer], { type: options.mimeType });
    triggerBrowserBlobDownload(blob, options.filename);
    return;
  }

  const base64Data = uint8ToBase64(options.bytes);
  let savedUri: string | null = null;
  try {
    const res = await Filesystem.writeFile({
      path: `SmartNotesPro/${options.filename}`,
      data: base64Data,
      directory: Directory.Documents,
      recursive: true,
    });
    savedUri = res.uri;
  } catch {
    const cacheRes = await Filesystem.writeFile({
      path: options.filename,
      data: base64Data,
      directory: Directory.Cache,
      recursive: true,
    });
    savedUri = cacheRes.uri;
  }

  if (savedUri) {
    try {
      await Share.share({
        title: options.shareTitle,
        url: savedUri,
        dialogTitle: options.shareTitle,
      });
    } catch {
      // User dismissed share sheet; file is already written locally
    }
  }
}

export async function sharePlainTextNatively(
  title: string,
  text: string
): Promise<'shared' | 'copied' | 'failed'> {
  if (isNativeApp()) {
    try {
      await Share.share({
        title: title || 'SmartNotesPro',
        text,
        dialogTitle: 'Share note',
      });
      return 'shared';
    } catch {
      // Fall through to clipboard fallback if cancelled/unavailable
    }
  }

  try {
    if (navigator.share) {
      await navigator.share({ title: title || 'SmartNotesPro', text });
      return 'shared';
    }
  } catch {
    // Fall through to clipboard
  }

  try {
    await navigator.clipboard.writeText(text);
    return 'copied';
  } catch {
    return 'failed';
  }
}

export async function syncNativeStatusBar(isDark: boolean): Promise<void> {
  if (!isNativeApp()) return;
  try {
    await StatusBar.setOverlaysWebView({ overlay: false });
    await StatusBar.setStyle({ style: isDark ? Style.Dark : Style.Light });
    await StatusBar.setBackgroundColor({
      color: isDark ? '#020617' : '#f8fafc',
    });
  } catch {
    // Ignore on unsupported devices
  }
}
