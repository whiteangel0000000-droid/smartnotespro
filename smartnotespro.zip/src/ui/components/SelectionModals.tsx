import {
  Ban,
  Bell,
  BellOff,
  Check,
  Clock,
  ImageOff,
  ImagePlus,
  Minus,
  Pencil,
  Plus,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import React, { useRef, useState } from 'react';
import {
  Note,
  NOTE_BACKGROUNDS,
  NOTE_COLOR_PALETTE,
  NoteBackgroundId,
  sanitizeBackground,
  sanitizeColor,
} from '../../domain/model/note';
import { NoteBackgroundArt } from './NoteBackgroundArt';

function toLocalDateTimeInputValue(timestamp: number): string {
  const d = new Date(timestamp);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}

function getLaterTodayTimestamp(): number {
  const now = new Date();
  const sixPm = new Date(now);
  sixPm.setHours(18, 0, 0, 0);
  if (sixPm.getTime() > now.getTime() + 30 * 60 * 1000) {
    return sixPm.getTime();
  }
  return now.getTime() + 2 * 60 * 60 * 1000;
}

function getTomorrowMorningTimestamp(): number {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(8, 0, 0, 0);
  return d.getTime();
}

function getNextWeekTimestamp(): number {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  d.setHours(9, 0, 0, 0);
  return d.getTime();
}

interface ReminderModalProps {
  noteTitle: string;
  currentReminderAt: number | null;
  onSave: (reminderAt: number | null) => void;
  onClose: () => void;
}

export function ReminderModal({
  noteTitle,
  currentReminderAt,
  onSave,
  onClose,
}: ReminderModalProps) {
  const initialTs = currentReminderAt ?? getLaterTodayTimestamp();
  const [dateTimeValue, setDateTimeValue] = useState<string>(() =>
    toLocalDateTimeInputValue(initialTs)
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleApplyPreset = (ts: number) => {
    onSave(ts);
  };

  const handleSaveCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = new Date(dateTimeValue).getTime();
    if (!Number.isFinite(parsed)) {
      setErrorMsg('Please select a valid date and time.');
      return;
    }
    onSave(parsed);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Set reminder"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <div className="min-w-0">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Add reminder
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {noteTitle.trim() || 'Untitled note'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close reminder dialog"
            className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="space-y-1.5">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Quick presets
            </p>
            <div className="grid grid-cols-1 gap-1.5">
              <button
                type="button"
                onClick={() => handleApplyPreset(getLaterTodayTimestamp())}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-700 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span>Later today</span>
                </span>
                <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                  {new Date(getLaterTodayTimestamp()).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleApplyPreset(getTomorrowMorningTimestamp())}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-700 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span>Tomorrow morning</span>
                </span>
                <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                  08:00 AM
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleApplyPreset(getNextWeekTimestamp())}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-700 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span>Next week</span>
                </span>
                <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                  {new Date(getNextWeekTimestamp()).toLocaleDateString([], {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSaveCustom} className="space-y-3 pt-1 border-t border-slate-200 dark:border-slate-800">
            <label className="block space-y-1.5">
              <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                Pick date & time
              </span>
              <input
                type="datetime-local"
                value={dateTimeValue}
                onChange={(e) => {
                  setDateTimeValue(e.target.value);
                  setErrorMsg(null);
                }}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </label>

            {errorMsg && (
              <p className="text-xs text-rose-600 dark:text-rose-400">{errorMsg}</p>
            )}

            <div className="flex items-center justify-between gap-2 pt-1">
              {currentReminderAt !== null ? (
                <button
                  type="button"
                  onClick={() => onSave(null)}
                  className="inline-flex items-center gap-1.5 min-h-[38px] px-3 rounded-xl text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                >
                  <BellOff className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              ) : (
                <span />
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="min-h-[38px] px-3.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[38px] px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                >
                  Save
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

interface LabelsModalProps {
  selectedNotes: readonly Note[];
  availableLabels: readonly string[];
  onToggleLabel: (label: string, assign: boolean) => void;
  onAddLabel: (newLabel: string) => void;
  onRenameLabel: (oldLabel: string, newLabel: string) => void;
  onDeleteLabel: (label: string) => void;
  onClose: () => void;
}

export function LabelsModal({
  selectedNotes,
  availableLabels,
  onToggleLabel,
  onAddLabel,
  onRenameLabel,
  onDeleteLabel,
  onClose,
}: LabelsModalProps) {
  const [newLabelInput, setNewLabelInput] = useState('');
  const [editingLabel, setEditingLabel] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');

  const trimmedInput = newLabelInput.trim();
  const alreadyExists = availableLabels.some(
    (l) => l.toLowerCase() === trimmedInput.toLowerCase()
  );

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trimmedInput) return;
    if (alreadyExists) {
      const existing = availableLabels.find(
        (l) => l.toLowerCase() === trimmedInput.toLowerCase()
      )!;
      onToggleLabel(existing, true);
    } else {
      onAddLabel(trimmedInput);
    }
    setNewLabelInput('');
  };

  const handleSaveRename = (oldLabel: string) => {
    const trimmed = editingValue.trim();
    if (trimmed && trimmed !== oldLabel) {
      onRenameLabel(oldLabel, trimmed);
    }
    setEditingLabel(null);
    setEditingValue('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Labels"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <Tag className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Label notes
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close labels dialog"
            className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form
          onSubmit={handleCreate}
          className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            value={newLabelInput}
            onChange={(e) => setNewLabelInput(e.target.value)}
            placeholder="Add new label..."
            aria-label="New label name"
            className="flex-1 min-w-0 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            disabled={!trimmedInput}
            className="inline-flex items-center gap-1 min-h-[38px] px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </form>

        <div className="max-h-64 overflow-y-auto py-2 px-2 space-y-0.5">
          {availableLabels.length === 0 ? (
            <p className="px-3 py-5 text-center text-xs text-slate-500 dark:text-slate-400">
              No labels yet. Type above to create one.
            </p>
          ) : (
            availableLabels.map((label) => {
              const key = label.toLowerCase();
              const matchCount = selectedNotes.filter((n) =>
                (n.labels ?? []).some((l) => l.toLowerCase() === key)
              ).length;
              const allChecked =
                selectedNotes.length > 0 && matchCount === selectedNotes.length;
              const someChecked = matchCount > 0 && matchCount < selectedNotes.length;
              const isEditing = editingLabel === label;

              if (isEditing) {
                return (
                  <form
                    key={label}
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSaveRename(label);
                    }}
                    className="flex items-center gap-1.5 px-2 py-1.5 rounded-xl bg-slate-100/80 dark:bg-slate-800/80"
                  >
                    <input
                      type="text"
                      value={editingValue}
                      onChange={(e) => setEditingValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Escape') {
                          setEditingLabel(null);
                          setEditingValue('');
                        }
                      }}
                      autoFocus
                      aria-label={`Rename label ${label}`}
                      className="flex-1 min-w-0 rounded-lg border border-indigo-400 dark:border-indigo-500 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      type="submit"
                      disabled={!editingValue.trim()}
                      aria-label="Save label name"
                      title="Save"
                      className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-40 shrink-0"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingLabel(null);
                        setEditingValue('');
                      }}
                      aria-label="Cancel rename"
                      title="Cancel"
                      className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 shrink-0"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </form>
                );
              }

              return (
                <div
                  key={label}
                  className="flex items-center gap-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors pr-1.5"
                >
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={someChecked ? 'mixed' : allChecked}
                    onClick={() => onToggleLabel(label, !allChecked)}
                    className="flex-1 min-w-0 flex items-center gap-3 px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 text-left"
                  >
                    <span
                      className={`w-5 h-5 rounded flex items-center justify-center border shrink-0 transition-colors ${
                        allChecked || someChecked
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-400 dark:border-slate-500'
                      }`}
                    >
                      {allChecked && <Check className="w-3.5 h-3.5" />}
                      {someChecked && <Minus className="w-3.5 h-3.5" />}
                    </span>
                    <span className="truncate font-medium">{label}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEditingLabel(label);
                      setEditingValue(label);
                    }}
                    aria-label={`Edit label ${label}`}
                    title="Edit label"
                    className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-black/5 dark:hover:bg-white/10 shrink-0 transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteLabel(label)}
                    aria-label={`Delete label ${label}`}
                    title="Delete label"
                    className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 shrink-0 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[38px] px-4 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

interface SelectionPaletteModalProps {
  selectedNotes: readonly Note[];
  onSelectColor: (colorTag: number) => void;
  onSelectBackground: (
    backgroundId: NoteBackgroundId,
    customBackgroundUrl?: string
  ) => void;
  onClose: () => void;
}

function readCompressedBackground(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.onload = () => {
      const rawUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!rawUrl) {
        reject(new Error('Empty image'));
        return;
      }
      const img = new Image();
      img.onload = () => {
        const maxDim = 1440;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(rawUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => resolve(rawUrl);
      img.src = rawUrl;
    };
    reader.readAsDataURL(file);
  });
}

export function SelectionPaletteModal({
  selectedNotes,
  onSelectColor,
  onSelectBackground,
  onClose,
}: SelectionPaletteModalProps) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const firstColor = selectedNotes[0] ? sanitizeColor(selectedNotes[0].colorTag) : 0;
  const allSameColor = selectedNotes.every(
    (n) => sanitizeColor(n.colorTag) === firstColor
  );
  const firstBg = selectedNotes[0]
    ? sanitizeBackground(selectedNotes[0].backgroundId)
    : 'none';
  const allSameBg = selectedNotes.every(
    (n) => sanitizeBackground(n.backgroundId) === firstBg
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Colour and background"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl px-5 py-4 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
            Colour & Background ({selectedNotes.length})
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close colour picker"
            className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-200">
            Colour
          </h3>
          <div className="flex flex-wrap items-center gap-2.5 max-h-36 overflow-y-auto py-1">
            {NOTE_COLOR_PALETTE.map((opt) => {
              const selected = allSameColor && firstColor === opt.index;
              return (
                <button
                  key={opt.index}
                  type="button"
                  onClick={() => onSelectColor(opt.index)}
                  aria-label={`${opt.name} colour`}
                  title={opt.name}
                  className={`relative w-10 h-10 rounded-full shrink-0 flex items-center justify-center border transition-transform hover:scale-105 ${
                    opt.index === 0
                      ? 'border-slate-400 dark:border-slate-500 bg-slate-100 dark:bg-slate-800'
                      : 'border-black/15 dark:border-white/20'
                  } ${
                    selected
                      ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900'
                      : ''
                  }`}
                  style={opt.index === 0 ? undefined : { backgroundColor: opt.swatchHex }}
                >
                  {opt.index === 0 && (
                    <Ban className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                  )}
                  {selected && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs">
                      <Check className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-200">
            Background
          </h3>
          <div className="flex flex-wrap items-center gap-2.5 max-h-40 overflow-y-auto py-1">
            {NOTE_BACKGROUNDS.map((bg) => {
              const selected = allSameBg && firstBg === bg.id;
              return (
                <button
                  key={bg.id}
                  type="button"
                  onClick={() => onSelectBackground(bg.id)}
                  aria-label={bg.name}
                  title={bg.name}
                  className={`relative w-11 h-11 rounded-full shrink-0 overflow-hidden flex items-center justify-center border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 transition-transform hover:scale-105 ${
                    selected
                      ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900'
                      : ''
                  }`}
                >
                  {bg.id === 'none' ? (
                    <ImageOff className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                  ) : (
                    <NoteBackgroundArt backgroundId={bg.id} variant="swatch" />
                  )}
                  {selected && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs z-10">
                      <Check className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              );
            })}

            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              aria-label="Choose custom background image"
              title="Choose your own background image"
              className="relative w-11 h-11 rounded-full shrink-0 flex items-center justify-center border-2 border-dashed border-indigo-400 dark:border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-transform hover:scale-105"
            >
              <ImagePlus className="w-5 h-5" />
            </button>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (!file) return;
            try {
              const url = await readCompressedBackground(file);
              onSelectBackground('custom', url);
            } catch {
              // Ignore unreadable file
            }
          }}
          className="hidden"
        />
      </div>
    </div>
  );
}
