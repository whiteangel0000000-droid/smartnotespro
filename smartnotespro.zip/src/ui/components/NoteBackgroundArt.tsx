import { NoteBackgroundId } from '../../domain/model/note';

interface NoteBackgroundArtProps {
  backgroundId: NoteBackgroundId;
  customBackgroundUrl?: string;
  variant?: 'swatch' | 'surface';
}

export function NoteBackgroundArt({
  backgroundId,
  customBackgroundUrl,
  variant = 'surface',
}: NoteBackgroundArtProps) {
  if (backgroundId === 'none') return null;

  const isSwatch = variant === 'swatch';
  const baseClass = isSwatch
    ? 'absolute inset-0 w-full h-full object-cover'
    : 'pointer-events-none absolute inset-0 w-full h-full object-cover opacity-22 dark:opacity-28 select-none';

  if (backgroundId === 'custom') {
    if (!customBackgroundUrl) return null;
    if (isSwatch) {
      return (
        <img
          src={customBackgroundUrl}
          alt="Custom background preview"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover"
        />
      );
    }
    return (
      <>
        <img
          src={customBackgroundUrl}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="pointer-events-none absolute inset-0 w-full h-full object-cover opacity-30 dark:opacity-35 select-none"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-white/35 dark:bg-slate-950/45"
        />
      </>
    );
  }

  switch (backgroundId) {
    case 'math':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <defs>
            <pattern
              id="blueprint-grid"
              width="20"
              height="20"
              patternUnits="userSpaceOnUse"
            >
              <path
                d="M 20 0 L 0 0 0 20"
                fill="none"
                stroke="#38BDF8"
                strokeWidth="0.8"
                opacity="0.35"
              />
            </pattern>
          </defs>
          <rect width="200" height="200" fill="#172554" />
          <rect width="200" height="200" fill="url(#blueprint-grid)" />
          <circle
            cx="142"
            cy="64"
            r="38"
            fill="none"
            stroke="#7DD3FC"
            strokeWidth="2"
            strokeDasharray="6 4"
            opacity="0.7"
          />
          <polygon
            points="32,166 104,166 32,96"
            fill="none"
            stroke="#A5B4FC"
            strokeWidth="2.5"
            strokeLinejoin="round"
            opacity="0.8"
          />
          <path
            d="M28 52 Q64 26 98 54 T168 48"
            fill="none"
            stroke="#34D399"
            strokeWidth="2"
            opacity="0.65"
          />
        </svg>
      );

    case 'botanical':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#13332B" />
          <circle cx="160" cy="40" r="65" fill="#1E4D40" opacity="0.7" />
          <path
            d="M35 195 Q60 120 130 55"
            stroke="#6EE7B7"
            strokeWidth="3"
            strokeLinecap="round"
            fill="none"
          />
          <path
            d="M72 132 C42 122 30 92 52 78 C74 64 92 98 72 132 Z"
            fill="#34D399"
            opacity="0.82"
          />
          <path
            d="M95 104 C128 112 152 92 144 68 C136 44 104 68 95 104 Z"
            fill="#10B981"
            opacity="0.85"
          />
          <path
            d="M114 78 C95 48 110 22 134 26 C158 30 144 64 114 78 Z"
            fill="#A7F3D0"
            opacity="0.75"
          />
          <path
            d="M54 162 C88 168 108 148 98 128 C88 108 60 130 54 162 Z"
            fill="#059669"
            opacity="0.85"
          />
        </svg>
      );

    case 'aurora':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="aurora-band-1" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#2DD4BF" stopOpacity="0.8" />
              <stop offset="55%" stopColor="#818CF8" stopOpacity="0.65" />
              <stop offset="100%" stopColor="#F472B6" stopOpacity="0.5" />
            </linearGradient>
          </defs>
          <rect width="200" height="200" fill="#0F172A" />
          <path
            d="M-10 95 Q55 30 115 72 T215 45 L215 135 Q145 100 85 130 T-10 150 Z"
            fill="url(#aurora-band-1)"
          />
          <path
            d="M-10 135 Q65 85 135 120 T215 105 L215 170 Q130 145 75 170 T-10 185 Z"
            fill="#38BDF8"
            opacity="0.28"
          />
          <path
            d="M0 175 L45 152 L88 168 L138 146 L200 172 L200 200 L0 200 Z"
            fill="#020617"
            opacity="0.85"
          />
        </svg>
      );

    case 'nightsky':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#0B132B" />
          <circle cx="144" cy="52" r="22" fill="#FDE68A" />
          <circle cx="153" cy="46" r="20" fill="#0B132B" />
          <circle cx="42" cy="40" r="2.2" fill="#E0F2FE" />
          <circle cx="78" cy="68" r="1.8" fill="#E0F2FE" />
          <circle cx="58" cy="96" r="2" fill="#BAE6FD" />
          <circle cx="105" cy="36" r="1.6" fill="#E0F2FE" />
          <circle cx="170" cy="102" r="2" fill="#E0F2FE" />
          <path
            d="M42 40 L78 68 L58 96 M78 68 L105 36"
            stroke="#93C5FD"
            strokeWidth="0.9"
            opacity="0.45"
            fill="none"
          />
          <path
            d="M0 165 Q65 138 130 160 T200 150 L200 200 L0 200 Z"
            fill="#1C2541"
          />
        </svg>
      );

    case 'dunes':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#7C2D12" />
          <circle cx="136" cy="64" r="28" fill="#FDE68A" opacity="0.88" />
          <path
            d="M0 120 Q58 92 122 122 T200 112 L200 200 L0 200 Z"
            fill="#EA580C"
          />
          <path
            d="M0 148 Q75 118 145 148 T200 142 L200 200 L0 200 Z"
            fill="#C2410C"
          />
          <path
            d="M0 172 Q65 152 135 175 T200 168 L200 200 L0 200 Z"
            fill="#431407"
          />
        </svg>
      );

    case 'sunset':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#253659" />
          <circle cx="145" cy="56" r="24" fill="#F59E0B" opacity="0.9" />
          <path
            d="M0 140 Q55 95 115 130 T200 115 L200 200 L0 200 Z"
            fill="#B45309"
          />
          <path
            d="M0 160 Q70 120 140 155 T200 145 L200 200 L0 200 Z"
            fill="#78350F"
          />
          <path
            d="M42 155 Q48 115 44 82 M44 108 Q64 96 76 102 M44 118 Q24 108 16 116"
            stroke="#0F172A"
            strokeWidth="5"
            strokeLinecap="round"
            fill="none"
          />
        </svg>
      );

    case 'culinary':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#263B3F" />
          <circle cx="155" cy="145" r="55" fill="#1E2F33" />
          <g transform="rotate(-32 100 100)">
            <rect x="93" y="88" width="14" height="90" rx="7" fill="#64748B" />
            <path
              d="M80 32 L80 78 Q80 94 100 94 Q120 94 120 78 L120 32"
              stroke="#94A3B8"
              strokeWidth="6"
              strokeLinecap="round"
              fill="none"
            />
            <line x1="93" y1="32" x2="93" y2="76" stroke="#94A3B8" strokeWidth="6" strokeLinecap="round" />
            <line x1="107" y1="32" x2="107" y2="76" stroke="#94A3B8" strokeWidth="6" strokeLinecap="round" />
          </g>
          <path
            d="M35 160 C65 130 95 170 135 135"
            stroke="#FBBF24"
            strokeWidth="4"
            strokeLinecap="round"
            fill="none"
            opacity="0.7"
          />
        </svg>
      );

    case 'arch':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#2A2730" />
          <path
            d="M32 200 L32 105 A68 68 0 0 1 168 105 L168 200 Z"
            fill="#57393B"
          />
          <path
            d="M54 200 L54 110 A46 46 0 0 1 146 110 L146 200 Z"
            fill="#1D4A4C"
          />
          <path
            d="M78 200 L78 118 A22 22 0 0 1 122 118 L122 200 Z"
            fill="#D97757"
          />
          <rect x="115" y="135" width="70" height="65" fill="#134E4A" opacity="0.85" />
        </svg>
      );

    case 'beach':
      return (
        <svg
          viewBox="0 0 200 200"
          preserveAspectRatio="xMidYMid slice"
          className={baseClass}
          aria-hidden="true"
        >
          <rect width="200" height="200" fill="#1E3A5F" />
          <rect y="142" width="200" height="58" fill="#155E75" />
          <line x1="100" y1="68" x2="100" y2="175" stroke="#CBD5E1" strokeWidth="5" strokeLinecap="round" />
          <path d="M35 95 Q100 35 165 95 Z" fill="#0284C7" />
          <path d="M58 95 Q100 42 142 95 Z" fill="#38BDF8" />
          <path d="M84 95 Q100 48 116 95 Z" fill="#0369A1" />
        </svg>
      );
  }
}
