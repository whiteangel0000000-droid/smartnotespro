import { Bell, Mic, Pin, Tag } from 'lucide-react';
import React, { useEffect, useRef } from 'react';
import { getNoteColorOption, Note, sanitizeBackground } from '../../domain/model/note';
import { formatResult } from '../../utils/mathEvaluator';
import { NoteBackgroundArt } from './NoteBackgroundArt';

interface NoteCardProps {
  note: Note;
  selected?: boolean;
  selectionMode?: boolean;
  onSelect: () => void;
  onLongPress?: () => void;
  onTogglePin: () => void;
}

const LONG_PRESS_MS = 420;
const MOVE_THRESHOLD_PX = 10;

function stripMarkdownPreview(text: string): string {
  return text
    .replace(/^#{1,2}\s+/gm, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/__(.+?)__/g, '$1')
    .replace(/~~(.+?)~~/g, '$1')
    .replace(/(?<![*\w])\*(.+?)\*(?![*\w])/g, '$1');
}

function formatReminderShort(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const isSameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();

  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  const isTomorrow =
    date.getFullYear() === tomorrow.getFullYear() &&
    date.getMonth() === tomorrow.getMonth() &&
    date.getDate() === tomorrow.getDate();

  const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (isSameDay) return `Today, ${timeStr}`;
  if (isTomorrow) return `Tomorrow, ${timeStr}`;
  const dayStr = date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  return `${dayStr}, ${timeStr}`;
}

export function NoteCard({
  note,
  selected = false,
  selectionMode = false,
  onSelect,
  onLongPress,
  onTogglePin,
}: NoteCardProps) {
  const colorOption = getNoteColorOption(note.colorTag);
  const bgId = sanitizeBackground(note.backgroundId);
  const visualAttachments = (note.attachments ?? []).filter(
    (a) => a.type === 'image' || a.type === 'drawing'
  );
  const audioCount = (note.attachments ?? []).filter((a) => a.type === 'audio').length;
  const checklistItems = note.checklistItems ?? [];
  const labels = note.labels ?? [];
  const plainBody = stripMarkdownPreview(note.content.trim());

  const pressTimerRef = useRef<number | null>(null);
  const pressStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const longPressFiredRef = useRef(false);

  const clearPressTimer = () => {
    if (pressTimerRef.current !== null) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
    pressStartPosRef.current = null;
  };

  useEffect(() => clearPressTimer, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLElement>) => {
    if (!onLongPress) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (target?.closest('button[data-pin-btn="true"]')) return;

    clearPressTimer();
    longPressFiredRef.current = false;
    pressStartPosRef.current = { x: e.clientX, y: e.clientY };

    pressTimerRef.current = window.setTimeout(() => {
      pressTimerRef.current = null;
      pressStartPosRef.current = null;
      longPressFiredRef.current = true;
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate(14);
        } catch {
          // Ignore vibration errors
        }
      }
      onLongPress();
    }, LONG_PRESS_MS);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLElement>) => {
    if (!pressStartPosRef.current || pressTimerRef.current === null) return;
    const dx = Math.abs(e.clientX - pressStartPosRef.current.x);
    const dy = Math.abs(e.clientY - pressStartPosRef.current.y);
    if (dx > MOVE_THRESHOLD_PX || dy > MOVE_THRESHOLD_PX) {
      clearPressTimer();
    }
  };

  const handlePointerUpOrCancel = () => {
    clearPressTimer();
  };

  const handleClick = (e: React.MouseEvent<HTMLElement>) => {
    if (longPressFiredRef.current) {
      longPressFiredRef.current = false;
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    onSelect();
  };

  const isReminderPast = note.reminderAt !== null && note.reminderAt < Date.now();

  return (
    <article
      role="button"
      tabIndex={0}
      aria-pressed={selectionMode ? selected : undefined}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUpOrCancel}
      onPointerCancel={handlePointerUpOrCancel}
      onPointerLeave={handlePointerUpOrCancel}
      onContextMenu={(e) => {
        if (!onLongPress) return;
        e.preventDefault();
        if (!longPressFiredRef.current && !selectionMode) {
          onLongPress();
        }
      }}
      onClick={handleClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect();
        }
      }}
      className={`group relative overflow-hidden rounded-2xl border transition-all duration-150 cursor-pointer hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 break-inside-avoid select-none ${colorOption.lightCardClass} ${colorOption.darkCardClass} ${
        selected
          ? 'ring-2 ring-indigo-500 dark:ring-[#8AB4F8] border-indigo-500 dark:border-[#8AB4F8] shadow-md'
          : ''
      }`}
    >
      <NoteBackgroundArt
        backgroundId={bgId}
        customBackgroundUrl={note.customBackgroundUrl}
        variant="surface"
      />

      {/* Top image / drawing preview */}
      {visualAttachments.length > 0 && (
        <div className="relative z-10 w-full overflow-hidden border-b border-black/5 dark:border-white/10">
          <img
            src={visualAttachments[0].dataUrl}
            alt="Note attachment"
            loading="lazy"
            className="w-full max-h-48 object-cover bg-white"
          />
          {visualAttachments.length > 1 && (
            <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-slate-950/70 text-[11px] font-medium text-white tabular-nums">
              +{visualAttachments.length - 1}
            </span>
          )}
        </div>
      )}

      <div className="relative z-10 p-3.5 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display text-[15px] font-semibold leading-snug text-slate-900 dark:text-slate-100 break-words min-w-0 flex-1">
            {note.title.trim() || 'Untitled'}
          </h3>

          {!selectionMode && (
            <button
              type="button"
              data-pin-btn="true"
              onClick={(e) => {
                e.stopPropagation();
                onTogglePin();
              }}
              aria-label={note.isPinned ? 'Unpin note' : 'Pin note'}
              className={`min-h-[36px] min-w-[36px] -mr-1.5 -mt-1.5 inline-flex items-center justify-center rounded-lg transition-opacity ${
                note.isPinned
                  ? 'text-indigo-600 dark:text-indigo-300 opacity-100'
                  : 'text-slate-400 dark:text-slate-500 opacity-70 sm:opacity-0 sm:group-hover:opacity-100 focus:opacity-100 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              <Pin className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Checklist preview or text preview */}
        {note.isChecklist && checklistItems.length > 0 ? (
          <ul className="space-y-1">
            {checklistItems.slice(0, 6).map((item) => (
              <li
                key={item.id}
                className={`flex items-start gap-2 text-xs leading-snug ${
                  item.checked
                    ? 'line-through text-slate-400 dark:text-slate-500'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <span
                  aria-hidden="true"
                  className={`mt-0.5 w-3.5 h-3.5 rounded-[3px] border shrink-0 inline-flex items-center justify-center text-[9px] ${
                    item.checked
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'border-slate-400 dark:border-slate-500'
                  }`}
                >
                  {item.checked ? '✓' : ''}
                </span>
                <span className="truncate">{item.text || 'Empty item'}</span>
              </li>
            ))}
            {checklistItems.length > 6 && (
              <li className="text-[11px] text-slate-500 dark:text-slate-400 pl-5 tabular-nums">
                +{checklistItems.length - 6} more items
              </li>
            )}
          </ul>
        ) : (
          plainBody && (
            <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 line-clamp-6 whitespace-pre-line break-words">
              {plainBody}
            </p>
          )
        )}

        {(note.reminderAt !== null || labels.length > 0) && (
          <div className="pt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[11px] text-slate-600 dark:text-slate-300">
            {note.reminderAt !== null && (
              <span
                className={`inline-flex items-center gap-1 tabular-nums ${
                  isReminderPast
                    ? 'text-amber-700 dark:text-amber-300 font-medium'
                    : ''
                }`}
              >
                <Bell className="w-3 h-3 shrink-0" />
                <span>{formatReminderShort(note.reminderAt)}</span>
              </span>
            )}
            {labels.length > 0 && (
              <span className="inline-flex items-center gap-1 min-w-0">
                <Tag className="w-3 h-3 shrink-0 opacity-75" />
                <span className="truncate">{labels.join(' · ')}</span>
              </span>
            )}
          </div>
        )}

        {(audioCount > 0 || note.totalCalculation !== 0) && (
          <div className="pt-1 flex items-center justify-between gap-2 text-xs tabular-nums">
            {audioCount > 0 ? (
              <span className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-400">
                <Mic className="w-3 h-3" />
                <span>
                  {audioCount} {audioCount === 1 ? 'recording' : 'recordings'}
                </span>
              </span>
            ) : (
              <span />
            )}
            {note.totalCalculation !== 0 && (
              <span className="font-mono font-semibold text-indigo-700 dark:text-indigo-300">
                Total: {formatResult(note.totalCalculation)}
              </span>
            )}
          </div>
        )}
      </div>
    </article>
  );
}
