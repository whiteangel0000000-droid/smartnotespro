import {
  DEFAULT_LABELS,
  sanitizeColor,
  sanitizeLabels,
  sanitizeStickyType,
  StickyNoteType,
} from '../../domain/model/note';

export type ThemeMode = 'system' | 'light' | 'dark';

export type SortOrder = 'modified' | 'created' | 'az' | 'highest_total';

export interface WidgetSettings {
  defaultColorTag: number;
  defaultNoteType: StickyNoteType;
  showReminderAndTotal: boolean;
}

export interface AppSettings {
  themeMode: ThemeMode;
  autoCalc: boolean;
  widget: WidgetSettings;
}

export const DEFAULT_WIDGET_SETTINGS: WidgetSettings = {
  defaultColorTag: 12,
  defaultNoteType: 'checklist',
  showReminderAndTotal: true,
};

export const DEFAULT_SETTINGS: AppSettings = {
  themeMode: 'system',
  autoCalc: true,
  widget: DEFAULT_WIDGET_SETTINGS,
};

const SETTINGS_STORAGE_KEY = 'smartnotespro.settings.v1';
const HOME_SORT_STORAGE_KEY = 'smartnotespro.home_sort.v1';
const LABELS_STORAGE_KEY = 'smartnotespro.labels.v1';

const VALID_THEMES = new Set<ThemeMode>(['system', 'light', 'dark']);
const VALID_SORTS = new Set<SortOrder>(['modified', 'created', 'az', 'highest_total']);

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    const rawWidget = parsed.widget as Partial<WidgetSettings> | undefined;
    return {
      themeMode:
        parsed.themeMode && VALID_THEMES.has(parsed.themeMode)
          ? parsed.themeMode
          : DEFAULT_SETTINGS.themeMode,
      autoCalc:
        typeof parsed.autoCalc === 'boolean'
          ? parsed.autoCalc
          : DEFAULT_SETTINGS.autoCalc,
      widget: {
        defaultColorTag:
          typeof rawWidget?.defaultColorTag === 'number'
            ? sanitizeColor(rawWidget.defaultColorTag)
            : DEFAULT_WIDGET_SETTINGS.defaultColorTag,
        defaultNoteType:
          sanitizeStickyType(rawWidget?.defaultNoteType) ??
          DEFAULT_WIDGET_SETTINGS.defaultNoteType,
        showReminderAndTotal:
          typeof rawWidget?.showReminderAndTotal === 'boolean'
            ? rawWidget.showReminderAndTotal
            : DEFAULT_WIDGET_SETTINGS.showReminderAndTotal,
      },
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota / private mode failures
  }
}

export function loadHomeSort(): SortOrder {
  try {
    const raw = localStorage.getItem(HOME_SORT_STORAGE_KEY);
    if (!raw) return 'modified';
    if (VALID_SORTS.has(raw as SortOrder)) return raw as SortOrder;
    if (raw === 'created_newest' || raw === 'created_oldest') return 'created';
    return 'modified';
  } catch {
    return 'modified';
  }
}

export function saveHomeSort(order: SortOrder): void {
  try {
    localStorage.setItem(HOME_SORT_STORAGE_KEY, order);
  } catch {
    // Ignore storage quota / private mode failures
  }
}

export function loadLabels(): string[] {
  try {
    const raw = localStorage.getItem(LABELS_STORAGE_KEY);
    if (raw === null) return [...DEFAULT_LABELS];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [...DEFAULT_LABELS];
    return sanitizeLabels(parsed);
  } catch {
    return [...DEFAULT_LABELS];
  }
}

export function saveLabels(labels: readonly string[]): void {
  try {
    const cleaned = sanitizeLabels(labels);
    localStorage.setItem(LABELS_STORAGE_KEY, JSON.stringify(cleaned));
  } catch {
    // Ignore storage quota / private mode failures
  }
}
