import { Calculator, ChevronUp } from 'lucide-react';
import { formatResult } from '../../domain/calculator/expressionDetector';

interface TotalBarProps {
  total: number;
  count: number;
  includedCount?: number;
  onClick: () => void;
}

export function TotalBar({
  total,
  count,
  includedCount = count,
  onClick,
}: TotalBarProps) {
  if (count === 0) return null;

  const hasExclusions = includedCount < count;

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center justify-between gap-4 px-4 sm:px-6 py-3 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white"
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <Calculator className="w-4 h-4 shrink-0" aria-hidden="true" />
        <span className="font-display text-sm font-semibold truncate font-mono tabular-nums">
          Total: {formatResult(total)}
        </span>
      </div>

      <div className="flex items-center gap-1.5 text-xs font-medium text-indigo-100 whitespace-nowrap shrink-0 tabular-nums">
        <span>
          {hasExclusions
            ? `${includedCount}/${count} calculations`
            : `${count} ${count === 1 ? 'calculation' : 'calculations'}`}
        </span>
        <ChevronUp className="w-4 h-4" aria-hidden="true" />
      </div>
    </button>
  );
}
