import {
  Archive,
  ArchiveRestore,
  ArrowLeft,
  ArrowUpDown,
  BellPlus,
  Brush,
  Check,
  CheckSquare,
  CopyPlus,
  FileText,
  Image as ImageIcon,
  LayoutGrid,
  Lock,
  Menu,
  Mic,
  MoreVertical,
  Palette,
  Pin,
  Plus,
  RotateCcw,
  Rows2,
  Search,
  SearchX,
  Send,
  Settings,
  Tag,
  Trash2,
  Type,
  X,
} from 'lucide-react';
import { App as CapApp } from '@capacitor/app';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AppSettings,
  loadHomeSort,
  loadLabels,
  loadSettings,
  saveHomeSort,
  saveLabels,
  saveSettings,
  SortOrder,
} from './data/preferences/settings';
import {
  deleteAllNotesRecord,
  deleteNotePermanentlyRecord,
  deleteNotesLabelRecord,
  duplicateNoteRecord,
  duplicateNotesRecord,
  emptyTrashRecord,
  importNotesRecords,
  loadAllNotesWithPurge,
  moveNoteToTrashRecord,
  moveNotesToTrashRecord,
  renameNotesLabelRecord,
  restoreNoteFromTrashRecord,
  restoreNotesFromTrashRecord,
  saveNoteRecord,
  setNoteArchivedRecord,
  setNotePinnedRecord,
  setNoteReminderRecord,
  setNotesArchivedRecord,
  setNotesBackgroundRecord,
  setNotesColorRecord,
  setNotesLabelRecord,
  setNotesPinnedRecord,
  sortNotes,
} from './data/storage/notesRepository';
import {
  getLastVaultActivity,
  loadVaultState,
  SecurityVaultState,
  setVaultLockedState,
  shouldAutoLockOnReturn,
  shouldLockInitially,
  touchVaultActivity,
} from './data/storage/securityVault';
import {
  ChecklistItem,
  DEFAULT_NOTE_FONT_SIZE,
  Note,
  NoteAttachment,
  NoteBackgroundId,
  sanitizeLabels,
} from './domain/model/note';
import { AppLockOverlay } from './ui/components/AppLockOverlay';
import { EditorInitialAction, EditorPane } from './ui/components/EditorPane';
import { LongPressTooltipLayer } from './ui/components/LongPressTooltipLayer';
import { NoteCard } from './ui/components/NoteCard';
import {
  LabelsModal,
  ReminderModal,
  SelectionPaletteModal,
} from './ui/components/SelectionModals';
import { SettingsView } from './ui/components/SettingsView';
import { TrashView } from './ui/components/TrashView';
import {
  isNativeApp,
  sharePlainTextNatively,
  syncNativeStatusBar,
} from './utils/androidBridge';

type AppSection = 'notes' | 'archive' | 'trash' | 'settings';
type SelectionModalType = 'none' | 'reminder' | 'palette' | 'labels';

const SORT_LABELS: Record<SortOrder, string> = {
  modified: 'Date modified',
  created: 'Date created',
  az: 'Title A–Z',
  highest_total: 'Highest total',
};

function createBlankDraft(isChecklist = false): Note {
  const now = Date.now();
  return {
    id: 0,
    title: '',
    content: '',
    richContent: '',
    fontSize: DEFAULT_NOTE_FONT_SIZE,
    totalCalculation: 0,
    colorTag: 0,
    backgroundId: 'none',
    customBackgroundUrl: undefined,
    isPinned: false,
    isArchived: false,
    isChecklist,
    checklistItems: isChecklist
      ? [{ id: `chk-${now}`, text: '', checked: false }]
      : [],
    attachments: [],
    excludedCalcKeys: [],
    createdAt: now,
    updatedAt: now,
    reminderAt: null,
    isDeleted: false,
    deletedAt: null,
  };
}

export default function App() {
  const [notes, setNotes] = useState<Note[]>(() => loadAllNotesWithPurge());
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [activeSort, setActiveSort] = useState<SortOrder>(() => loadHomeSort());
  const [availableLabels, setAvailableLabels] = useState<string[]>(() => loadLabels());
  const [activeLabelFilter, setActiveLabelFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState<AppSection>('notes');
  const [gridView, setGridView] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [sortMenuOpen, setSortMenuOpen] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);

  // Home card multi-select state
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [selectionModal, setSelectionModal] = useState<SelectionModalType>('none');
  const [selectionMoreOpen, setSelectionMoreOpen] = useState(false);

  // Active editor state (null = list/grid home; Note = editor open)
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [draftNote, setDraftNote] = useState<Note | null>(null);
  const [draftNonce, setDraftNonce] = useState(0);
  const [initialAction, setInitialAction] = useState<EditorInitialAction>(null);

  // Security Vault state
  const [vaultState, setVaultState] = useState<SecurityVaultState>(() => loadVaultState());
  const [isVaultLocked, setIsVaultLocked] = useState<boolean>(() =>
    shouldLockInitially(loadVaultState())
  );

  // Snackbar toast for trash/archive undo
  const [toast, setToast] = useState<{
    message: string;
    undoLabel?: string;
    onUndo?: () => void;
  } | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const lastActivityWriteRef = useRef<number>(0);

  const handleLockVaultNow = useCallback(() => {
    setVaultState((curr) => {
      if (!curr.enabled) return curr;
      return setVaultLockedState(true);
    });
    setIsVaultLocked(true);
  }, []);

  // Enforce Security Vault auto-lock across manual, immediate, and inactivity modes
  useEffect(() => {
    if (!vaultState.enabled) {
      setIsVaultLocked(false);
      return;
    }

    const recordActivity = () => {
      if (isVaultLocked) return;
      const now = Date.now();
      if (now - lastActivityWriteRef.current >= 3000) {
        lastActivityWriteRef.current = now;
        touchVaultActivity();
      }
    };

    if (!isVaultLocked) {
      lastActivityWriteRef.current = Date.now();
      touchVaultActivity();
    }

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        if (!isVaultLocked) {
          touchVaultActivity();
        }
      } else if (document.visibilityState === 'visible') {
        const latest = loadVaultState();
        setVaultState(latest);
        if (shouldAutoLockOnReturn(latest)) {
          setVaultState(setVaultLockedState(true));
          setIsVaultLocked(true);
        }
      }
    };

    window.addEventListener('pointerdown', recordActivity, { passive: true });
    window.addEventListener('keydown', recordActivity);
    window.addEventListener('touchstart', recordActivity, { passive: true });
    document.addEventListener('visibilitychange', onVisibilityChange);

    let idleTimer: number | null = null;
    if (
      !isVaultLocked &&
      (vaultState.autoLock === '60' || vaultState.autoLock === '300')
    ) {
      const limitMs = Number(vaultState.autoLock) * 1000;
      idleTimer = window.setInterval(() => {
        const last = getLastVaultActivity();
        if (last > 0 && Date.now() - last > limitMs) {
          setVaultState(setVaultLockedState(true));
          setIsVaultLocked(true);
        }
      }, 5000);
    }

    return () => {
      window.removeEventListener('pointerdown', recordActivity);
      window.removeEventListener('keydown', recordActivity);
      window.removeEventListener('touchstart', recordActivity);
      document.removeEventListener('visibilitychange', onVisibilityChange);
      if (idleTimer !== null) window.clearInterval(idleTimer);
    };
  }, [vaultState.enabled, vaultState.autoLock, isVaultLocked]);

  // Sync Tailwind .dark class on <html> and native Android StatusBar
  useEffect(() => {
    const applyTheme = (isDark: boolean) => {
      document.documentElement.classList.toggle('dark', isDark);
      const themeMeta = document.querySelector('meta[name="theme-color"]');
      if (themeMeta) {
        themeMeta.setAttribute('content', isDark ? '#020617' : '#f8fafc');
      }
      void syncNativeStatusBar(isDark);
    };
    if (settings.themeMode === 'dark') {
      applyTheme(true);
      return;
    }
    if (settings.themeMode === 'light') {
      applyTheme(false);
      return;
    }
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    applyTheme(media.matches);
    const handler = (e: MediaQueryListEvent) => applyTheme(e.matches);
    media.addEventListener('change', handler);
    return () => media.removeEventListener('change', handler);
  }, [settings.themeMode]);

  const liveNotes = useMemo(() => {
    const active = notes.filter((n) => !n.isDeleted && !n.isArchived);
    return sortNotes(active, activeSort);
  }, [notes, activeSort]);

  const archivedNotes = useMemo(() => {
    const archived = notes.filter((n) => !n.isDeleted && Boolean(n.isArchived));
    return sortNotes(archived, activeSort);
  }, [notes, activeSort]);

  const trashedNotes = useMemo(() => {
    return notes
      .filter((n) => n.isDeleted)
      .sort((a, b) => (b.deletedAt ?? b.updatedAt) - (a.deletedAt ?? a.updatedAt));
  }, [notes]);

  const displayedNotes = useMemo(() => {
    const base = activeSection === 'archive' ? archivedNotes : liveNotes;
    const labelFiltered = activeLabelFilter
      ? base.filter((n) =>
          (n.labels ?? []).some(
            (l) => l.toLowerCase() === activeLabelFilter.toLowerCase()
          )
        )
      : base;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return labelFiltered;
    return labelFiltered.filter((n) => {
      if (
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        (n.labels ?? []).some((l) => l.toLowerCase().includes(q))
      ) {
        return true;
      }
      return Boolean(
        n.checklistItems?.some((item) => item.text.toLowerCase().includes(q))
      );
    });
  }, [activeSection, archivedNotes, liveNotes, activeLabelFilter, searchQuery]);

  const selectedNotes = useMemo(() => {
    if (selectedIds.length === 0) return [];
    const set = new Set(selectedIds);
    return displayedNotes.filter((n) => set.has(n.id));
  }, [displayedNotes, selectedIds]);

  const allSelectedPinned =
    selectedNotes.length > 0 && selectedNotes.every((n) => n.isPinned);

  const selectionMode =
    (activeSection === 'notes' || activeSection === 'archive') &&
    selectedIds.length > 0;

  const pinnedDisplayed = useMemo(
    () => displayedNotes.filter((n) => n.isPinned),
    [displayedNotes]
  );
  const otherDisplayed = useMemo(
    () => displayedNotes.filter((n) => !n.isPinned),
    [displayedNotes]
  );

  const activeEditorNote = useMemo(() => {
    if (editingNoteId === null) return null;
    if (editingNoteId === 0) return draftNote ?? createBlankDraft();
    return notes.find((n) => n.id === editingNoteId && !n.isDeleted) ?? null;
  }, [editingNoteId, draftNote, notes]);

  const draftKey = useMemo(() => {
    if (editingNoteId === null) return 'closed';
    return `session-${draftNonce}`;
  }, [editingNoteId, draftNonce]);

  const showToast = useCallback(
    (message: string, undoLabel?: string, onUndo?: () => void) => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
      setToast({ message, undoLabel, onUndo });
      toastTimerRef.current = window.setTimeout(() => {
        setToast(null);
        toastTimerRef.current = null;
      }, 4500);
    },
    []
  );

  const handleUpdateSettings = useCallback((next: AppSettings) => {
    setSettings(next);
    saveSettings(next);
  }, []);

  const clearSelection = useCallback(() => {
    setSelectedIds([]);
    setSelectionModal('none');
    setSelectionMoreOpen(false);
  }, []);

  const toggleCardSelection = useCallback((id: number) => {
    setSelectionMoreOpen(false);
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }, []);

  const startCardSelection = useCallback((id: number) => {
    setFabOpen(false);
    setSortMenuOpen(false);
    setSelectionMoreOpen(false);
    setSelectedIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  }, []);

  const openNewNote = useCallback(
    (options?: { checklist?: boolean; action?: EditorInitialAction }) => {
      clearSelection();
      setFabOpen(false);
      setActiveSection('notes');
      setDraftNote(createBlankDraft(Boolean(options?.checklist)));
      setEditingNoteId(0);
      setDraftNonce((n) => n + 1);
      setInitialAction(options?.action ?? null);
    },
    [clearSelection]
  );

  const handleSelectNote = useCallback(
    (id: number) => {
      if (selectionMode) {
        toggleCardSelection(id);
        return;
      }
      setFabOpen(false);
      setDraftNote(null);
      setInitialAction(null);
      setEditingNoteId(id);
      setDraftNonce((n) => n + 1);
    },
    [selectionMode, toggleCardSelection]
  );

  const handleSaveNote = useCallback(
    (draft: {
      id: number;
      title: string;
      content: string;
      richContent: string;
      fontSize: number;
      totalCalculation: number;
      colorTag: number;
      backgroundId: NoteBackgroundId;
      customBackgroundUrl?: string;
      isPinned: boolean;
      isArchived: boolean;
      isChecklist: boolean;
      checklistItems: ChecklistItem[];
      attachments: NoteAttachment[];
      excludedCalcKeys: string[];
    }): Note => {
      const existing = draft.id > 0 ? notes.find((n) => n.id === draft.id) : null;
      const base = existing ?? createBlankDraft(draft.isChecklist);
      const { notes: updatedList, saved } = saveNoteRecord({
        ...base,
        id: draft.id,
        title: draft.title,
        content: draft.content,
        richContent: draft.richContent,
        fontSize: draft.fontSize,
        totalCalculation: draft.totalCalculation,
        colorTag: draft.colorTag,
        backgroundId: draft.backgroundId,
        customBackgroundUrl: draft.customBackgroundUrl,
        isPinned: draft.isPinned,
        isArchived: draft.isArchived,
        isChecklist: draft.isChecklist,
        checklistItems: draft.checklistItems,
        attachments: draft.attachments,
        excludedCalcKeys: draft.excludedCalcKeys,
      });
      setNotes(updatedList);
      setEditingNoteId((currentId) =>
        currentId === 0 || currentId === draft.id ? saved.id : currentId
      );
      return saved;
    },
    [notes]
  );

  const handleTogglePin = useCallback((id: number, pinned: boolean) => {
    setNotes(setNotePinnedRecord(id, pinned));
  }, []);

  const handleToggleArchive = useCallback(
    (id: number, archived: boolean) => {
      const next = setNoteArchivedRecord(id, archived);
      setNotes(next);
      showToast(
        archived ? 'Note archived' : 'Note unarchived',
        'Undo',
        () => {
          setNotes(setNoteArchivedRecord(id, !archived));
          setToast(null);
        }
      );
    },
    [showToast]
  );

  const handleDuplicateNote = useCallback((id: number) => {
    const { notes: next } = duplicateNoteRecord(id);
    setNotes(next);
  }, []);

  const handleMoveToTrash = useCallback(
    (id: number) => {
      if (id === 0) {
        setEditingNoteId(null);
        setDraftNote(null);
        return;
      }
      const next = moveNoteToTrashRecord(id);
      setNotes(next);
      if (editingNoteId === id) {
        setEditingNoteId(null);
      }
      showToast('Note moved to Trash', 'Undo', () => {
        setNotes(restoreNoteFromTrashRecord(id));
        setToast(null);
      });
    },
    [editingNoteId, showToast]
  );

  const handleRestoreFromTrash = useCallback((id: number) => {
    setNotes(restoreNoteFromTrashRecord(id));
  }, []);

  const handleDeletePermanently = useCallback((id: number) => {
    setNotes(deleteNotePermanentlyRecord(id));
  }, []);

  const handleEmptyTrash = useCallback(() => {
    setNotes(emptyTrashRecord());
  }, []);

  const handleImportNotes = useCallback((imported: Note[]): number => {
    const { notes: updated, addedCount } = importNotesRecords(imported);
    setNotes(updated);
    const importedLabels = imported.flatMap((n) => sanitizeLabels(n.labels));
    if (importedLabels.length > 0) {
      setAvailableLabels((prev) => {
        const merged = sanitizeLabels([...prev, ...importedLabels]);
        saveLabels(merged);
        return merged;
      });
    }
    return addedCount;
  }, []);

  const handleDeleteAll = useCallback(() => {
    setNotes(deleteAllNotesRecord());
    setEditingNoteId(null);
    setDraftNote(null);
    clearSelection();
  }, [clearSelection]);

  // Multi-select contextual bar actions
  const handleBatchTogglePin = useCallback(() => {
    if (selectedIds.length === 0) return;
    const nextPinned = !allSelectedPinned;
    setNotes(setNotesPinnedRecord(selectedIds, nextPinned));
    setSelectionMoreOpen(false);
    showToast(
      nextPinned
        ? `Pinned ${selectedIds.length} ${selectedIds.length === 1 ? 'note' : 'notes'}`
        : `Unpinned ${selectedIds.length} ${selectedIds.length === 1 ? 'note' : 'notes'}`
    );
  }, [selectedIds, allSelectedPinned, showToast]);

  const handleSaveSingleReminder = useCallback(
    (reminderAt: number | null) => {
      if (selectedIds.length !== 1) return;
      const targetId = selectedIds[0];
      setNotes(setNoteReminderRecord(targetId, reminderAt));
      setSelectionModal('none');
      showToast(reminderAt ? 'Reminder set' : 'Reminder removed');
    },
    [selectedIds, showToast]
  );

  const handleBatchColor = useCallback(
    (colorTag: number) => {
      if (selectedIds.length === 0) return;
      setNotes(setNotesColorRecord(selectedIds, colorTag));
    },
    [selectedIds]
  );

  const handleBatchBackground = useCallback(
    (backgroundId: NoteBackgroundId, customBackgroundUrl?: string) => {
      if (selectedIds.length === 0) return;
      setNotes(setNotesBackgroundRecord(selectedIds, backgroundId, customBackgroundUrl));
    },
    [selectedIds]
  );

  const handleBatchToggleLabel = useCallback(
    (label: string, assign: boolean) => {
      if (selectedIds.length === 0) return;
      setNotes(setNotesLabelRecord(selectedIds, label, assign));
    },
    [selectedIds]
  );

  const handleAddLabelAndAssign = useCallback(
    (newLabel: string) => {
      const cleaned = newLabel.trim();
      if (!cleaned) return;
      setAvailableLabels((prev) => {
        const merged = sanitizeLabels([...prev, cleaned]);
        saveLabels(merged);
        return merged;
      });
      if (selectedIds.length > 0) {
        setNotes(setNotesLabelRecord(selectedIds, cleaned, true));
      }
    },
    [selectedIds]
  );

  const handleRenameLabel = useCallback(
    (oldLabel: string, newLabel: string) => {
      const oldTrimmed = oldLabel.trim();
      const newTrimmed = newLabel.trim();
      if (!oldTrimmed || !newTrimmed) return;
      const oldKey = oldTrimmed.toLowerCase();

      setAvailableLabels((prev) => {
        const replaced = prev.map((l) =>
          l.toLowerCase() === oldKey ? newTrimmed : l
        );
        const merged = sanitizeLabels(replaced);
        saveLabels(merged);
        return merged;
      });
      setNotes(renameNotesLabelRecord(oldTrimmed, newTrimmed));
      setActiveLabelFilter((curr) =>
        curr && curr.toLowerCase() === oldKey ? newTrimmed : curr
      );
      showToast(`Label renamed to "${newTrimmed}"`);
    },
    [showToast]
  );

  const handleDeleteLabel = useCallback(
    (label: string) => {
      const trimmed = label.trim();
      if (!trimmed) return;
      const key = trimmed.toLowerCase();

      setAvailableLabels((prev) => {
        const filtered = prev.filter((l) => l.toLowerCase() !== key);
        saveLabels(filtered);
        return filtered;
      });
      setNotes(deleteNotesLabelRecord(trimmed));
      setActiveLabelFilter((curr) =>
        curr && curr.toLowerCase() === key ? null : curr
      );
      showToast(`Deleted label "${trimmed}"`);
    },
    [showToast]
  );

  const handleBatchArchive = useCallback(() => {
    if (selectedIds.length === 0) return;
    const targetIds = [...selectedIds];
    const archiveTarget = activeSection !== 'archive';
    setNotes(setNotesArchivedRecord(targetIds, archiveTarget));
    clearSelection();
    showToast(
      archiveTarget
        ? `${targetIds.length} ${targetIds.length === 1 ? 'note' : 'notes'} archived`
        : `${targetIds.length} ${targetIds.length === 1 ? 'note' : 'notes'} unarchived`,
      'Undo',
      () => {
        setNotes(setNotesArchivedRecord(targetIds, !archiveTarget));
        setToast(null);
      }
    );
  }, [selectedIds, activeSection, clearSelection, showToast]);

  const handleBatchDelete = useCallback(() => {
    if (selectedIds.length === 0) return;
    const targetIds = [...selectedIds];
    setNotes(moveNotesToTrashRecord(targetIds));
    clearSelection();
    showToast(
      `${targetIds.length} ${targetIds.length === 1 ? 'note' : 'notes'} moved to Trash`,
      'Undo',
      () => {
        setNotes(restoreNotesFromTrashRecord(targetIds));
        setToast(null);
      }
    );
  }, [selectedIds, clearSelection, showToast]);

  const handleBatchMakeCopy = useCallback(() => {
    if (selectedIds.length === 0) return;
    const count = selectedIds.length;
    setNotes(duplicateNotesRecord(selectedIds));
    clearSelection();
    showToast(`Copied ${count} ${count === 1 ? 'note' : 'notes'}`);
  }, [selectedIds, clearSelection, showToast]);

  const handleBatchSend = useCallback(async () => {
    if (selectedNotes.length === 0) return;
    const payload = selectedNotes
      .map((n) => {
        const body = n.isChecklist
          ? (n.checklistItems ?? [])
              .map((i) => `${i.checked ? '[x]' : '[ ]'} ${i.text}`)
              .join('\n')
          : n.content;
        return n.title.trim() ? `${n.title.trim()}\n${body}` : body;
      })
      .join('\n\n---\n\n');

    clearSelection();
    const shareTitle =
      selectedNotes.length === 1
        ? selectedNotes[0].title.trim() || 'SmartNotesPro'
        : `${selectedNotes.length} Notes`;
    const outcome = await sharePlainTextNatively(shareTitle, payload);
    if (outcome === 'copied') {
      showToast('Copied to clipboard to share');
    }
  }, [selectedNotes, clearSelection, showToast]);

  // Keyboard shortcuts: Ctrl/Cmd+K focuses search, Escape closes open overlays or selection mode
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        clearSelection();
        setEditingNoteId(null);
        setActiveSection('notes');
        requestAnimationFrame(() => searchInputRef.current?.focus());
      } else if (e.key === 'Escape' && editingNoteId === null) {
        if (selectionModal !== 'none') {
          setSelectionModal('none');
        } else if (drawerOpen) {
          setDrawerOpen(false);
        } else if (fabOpen) {
          setFabOpen(false);
        } else if (sortMenuOpen) {
          setSortMenuOpen(false);
        } else if (selectionMoreOpen) {
          setSelectionMoreOpen(false);
        } else if (selectedIds.length > 0) {
          clearSelection();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    clearSelection,
    selectedIds.length,
    editingNoteId,
    selectionModal,
    drawerOpen,
    fabOpen,
    sortMenuOpen,
    selectionMoreOpen,
  ]);

  // Handle Android hardware Back button / edge gesture cleanly in APK
  useEffect(() => {
    if (!isNativeApp()) return;
    let disposed = false;
    let listenerHandle: { remove: () => Promise<void> } | null = null;

    void CapApp.addListener('backButton', () => {
      if (vaultState.enabled && isVaultLocked) return;

      const backEv = new CustomEvent('smartnotes:android-back', {
        cancelable: true,
      });
      if (!window.dispatchEvent(backEv)) {
        return;
      }

      if (selectionModal !== 'none') {
        setSelectionModal('none');
      } else if (drawerOpen) {
        setDrawerOpen(false);
      } else if (fabOpen) {
        setFabOpen(false);
      } else if (sortMenuOpen) {
        setSortMenuOpen(false);
      } else if (selectionMoreOpen) {
        setSelectionMoreOpen(false);
      } else if (selectedIds.length > 0) {
        clearSelection();
      } else if (activeSection !== 'notes') {
        setActiveSection('notes');
        setActiveLabelFilter(null);
      } else if (activeLabelFilter) {
        setActiveLabelFilter(null);
      } else if (searchQuery.trim().length > 0) {
        setSearchQuery('');
      } else {
        void CapApp.exitApp();
      }
    }).then((handle) => {
      if (disposed) {
        void handle.remove();
      } else {
        listenerHandle = handle;
      }
    });

    return () => {
      disposed = true;
      if (listenerHandle) {
        void listenerHandle.remove();
      }
    };
  }, [
    vaultState.enabled,
    isVaultLocked,
    selectionModal,
    drawerOpen,
    fabOpen,
    sortMenuOpen,
    selectionMoreOpen,
    selectedIds.length,
    clearSelection,
    activeSection,
    activeLabelFilter,
    searchQuery,
  ]);

  // Lock Vault immediately if Security Vault is enabled and locked
  if (vaultState.enabled && isVaultLocked) {
    return (
      <>
        <AppLockOverlay
          vaultState={vaultState}
          onVaultStateChange={setVaultState}
          onUnlock={(next) => {
            const unlocked = next.isLocked ? setVaultLockedState(false) : next;
            setVaultState(unlocked);
            setIsVaultLocked(false);
          }}
        />
        <LongPressTooltipLayer />
      </>
    );
  }

  // Editor View (Images 1, 2, 3)
  if (activeEditorNote) {
    return (
      <div className="h-dvh w-full flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden">
        <EditorPane
          note={activeEditorNote}
          draftKey={draftKey}
          autoCalcEnabled={settings.autoCalc}
          initialAction={initialAction}
          onConsumeInitialAction={() => setInitialAction(null)}
          onSaveNote={handleSaveNote}
          onTogglePin={handleTogglePin}
          onToggleArchive={handleToggleArchive}
          onDuplicateNote={handleDuplicateNote}
          onMoveToTrash={handleMoveToTrash}
          onBack={() => {
            setEditingNoteId(null);
            setDraftNote(null);
          }}
        />
        <LongPressTooltipLayer />
      </div>
    );
  }

  return (
    <div className="h-dvh w-full flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden">
      {/* Top Bar: Contextual Multi-Select Bar OR Keep-style pill search bar OR section header */}
      {(activeSection === 'notes' || activeSection === 'archive') && selectionMode ? (
        <header className="px-3 sm:px-6 pt-3 pb-2 shrink-0">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 rounded-2xl bg-slate-200/90 dark:bg-slate-900 px-2.5 py-1.5 border border-slate-300/70 dark:border-slate-700/80 shadow-sm">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={clearSelection}
                aria-label="Clear selection"
                title="Close selection"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <span
                className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100 tabular-nums px-1"
                aria-live="polite"
              >
                {selectedIds.length}
              </span>
            </div>

            <div className="flex items-center gap-0.5 sm:gap-1">
              <button
                type="button"
                onClick={handleBatchTogglePin}
                aria-label={allSelectedPinned ? 'Unpin selected' : 'Pin selected'}
                title={allSelectedPinned ? 'Unpin' : 'Pin'}
                className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full transition-colors ${
                  allSelectedPinned
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10'
                }`}
              >
                <Pin className="w-5 h-5" />
              </button>

              <button
                type="button"
                disabled={selectedIds.length > 1}
                onClick={() => {
                  setSelectionMoreOpen(false);
                  setSelectionModal('reminder');
                }}
                aria-label="Set reminder"
                title={
                  selectedIds.length > 1
                    ? 'Reminder available for single note selection only'
                    : 'Set reminder'
                }
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              >
                <BellPlus className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectionMoreOpen(false);
                  setSelectionModal('palette');
                }}
                aria-label="Colour and background"
                title="Colour & background"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
              >
                <Palette className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectionMoreOpen(false);
                  setSelectionModal('labels');
                }}
                aria-label="Labels"
                title="Labels"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
              >
                <Tag className="w-5 h-5" />
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setSelectionMoreOpen((o) => !o)}
                  aria-label="More selection options"
                  title="More options"
                  className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-800 dark:text-slate-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>

                {selectionMoreOpen && (
                  <div
                    className="absolute right-0 mt-2 w-48 z-50 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xl py-1"
                    role="menu"
                  >
                    <button
                      type="button"
                      onClick={handleBatchArchive}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      {activeSection === 'archive' ? (
                        <>
                          <ArchiveRestore className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                          <span>Unarchive</span>
                        </>
                      ) : (
                        <>
                          <Archive className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                          <span>Archive</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={handleBatchDelete}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleBatchMakeCopy}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <CopyPlus className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                      <span>Make a copy</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleBatchSend}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <Send className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                      <span>Send</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>
      ) : activeSection === 'notes' || activeSection === 'archive' ? (
        <header className="px-3 sm:px-6 pt-3 pb-2 shrink-0">
          <div className="max-w-6xl mx-auto flex items-center gap-2 rounded-full bg-slate-200/75 dark:bg-slate-800/90 px-2.5 py-1.5 border border-slate-300/60 dark:border-slate-700/70">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              aria-label="Menu"
              title="Menu"
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>

            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape' && searchQuery) setSearchQuery('');
              }}
              placeholder={
                activeLabelFilter
                  ? `Search in ${activeLabelFilter}`
                  : activeSection === 'archive'
                    ? 'Search archive'
                    : 'Search notes'
              }
              aria-label="Search notes"
              className="flex-1 min-w-0 bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-500 dark:placeholder:text-slate-400 focus:outline-none px-1"
            />

            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search"
                title="Clear search"
                className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-full text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setGridView((g) => !g)}
              aria-label={gridView ? 'Switch to single-column view' : 'Switch to grid view'}
              title={gridView ? 'Single-column view' : 'Grid view'}
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors shrink-0"
            >
              {gridView ? (
                <Rows2 className="w-4 h-4" />
              ) : (
                <LayoutGrid className="w-4 h-4" />
              )}
            </button>

            <div className="relative shrink-0">
              <button
                type="button"
                onClick={() => setSortMenuOpen((o) => !o)}
                aria-label="Sort notes"
                title={`Sort: ${SORT_LABELS[activeSort]}`}
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
              >
                <ArrowUpDown className="w-4 h-4" />
              </button>

              {sortMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-52 z-40 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xl py-1"
                  role="menu"
                >
                  {(Object.keys(SORT_LABELS) as SortOrder[]).map((order) => (
                    <button
                      key={order}
                      type="button"
                      onClick={() => {
                        setActiveSort(order);
                        saveHomeSort(order);
                        setSortMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 text-xs font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <span>{SORT_LABELS[order]}</span>
                      {activeSort === order && (
                        <Check className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {vaultState.enabled && (
              <button
                type="button"
                onClick={handleLockVaultNow}
                aria-label="Lock app vault"
                title="Lock Vault"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors shrink-0"
              >
                <Lock className="w-4 h-4" />
              </button>
            )}
          </div>
        </header>
      ) : (
        <header className="flex items-center justify-between gap-3 px-3 sm:px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              aria-label="Open navigation menu"
              title="Menu"
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100 capitalize">
              {activeSection}
            </h1>
          </div>
          <button
            type="button"
            onClick={() => setActiveSection('notes')}
            title="Back to notes"
            className="inline-flex items-center gap-1.5 min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Notes</span>
          </button>
        </header>
      )}

      {/* Main Content Area */}
      {activeSection === 'trash' && (
        <TrashView
          trashedNotes={trashedNotes}
          onRestore={handleRestoreFromTrash}
          onDeletePermanently={handleDeletePermanently}
          onEmptyTrash={handleEmptyTrash}
        />
      )}

      {activeSection === 'settings' && (
        <SettingsView
          settings={settings}
          vaultState={vaultState}
          liveNotes={notes.filter((n) => !n.isDeleted)}
          totalNotesCount={notes.length}
          onUpdateSettings={handleUpdateSettings}
          onVaultStateChange={(next) => {
            setVaultState(next);
            if (!next.enabled) setIsVaultLocked(false);
          }}
          onLockNow={handleLockVaultNow}
          onImportNotes={handleImportNotes}
          onDeleteAll={handleDeleteAll}
        />
      )}

      {(activeSection === 'notes' || activeSection === 'archive') && (
        <main
          className="flex-1 overflow-y-auto px-3 sm:px-6 pt-3 pb-28"
          onClick={() => {
            if (sortMenuOpen) setSortMenuOpen(false);
            if (selectionMoreOpen) setSelectionMoreOpen(false);
          }}
        >
          <div className="max-w-6xl mx-auto">

            {activeLabelFilter && (
              <div className="mb-3 flex items-center justify-between gap-2 px-1 text-xs text-slate-600 dark:text-slate-300">
                <span className="inline-flex items-center gap-1.5 font-medium">
                  <Tag className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>Label: {activeLabelFilter}</span>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveLabelFilter(null)}
                  className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Show all
                </button>
              </div>
            )}
            {displayedNotes.length === 0 ? (
              <div className="min-h-[55vh] flex flex-col items-center justify-center text-center px-4">
                <div className="w-14 h-14 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-4">
                  {searchQuery ? (
                    <SearchX className="w-6 h-6" />
                  ) : activeSection === 'archive' ? (
                    <Archive className="w-6 h-6" />
                  ) : activeLabelFilter ? (
                    <Tag className="w-6 h-6" />
                  ) : (
                    <Search className="w-6 h-6" />
                  )}
                </div>
                <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                  {searchQuery
                    ? 'No matching notes'
                    : activeLabelFilter
                      ? `No notes with "${activeLabelFilter}"`
                      : activeSection === 'archive'
                        ? 'Your archived notes appear here'
                        : 'Notes you add appear here'}
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5 max-w-sm">
                  {searchQuery
                    ? 'Try another search keyword or clear the search.'
                    : activeLabelFilter
                      ? 'Long-press any note card to assign labels to it.'
                      : 'Tap the + button to create a text note, checklist, drawing, image, or voice recording.'}
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {pinnedDisplayed.length > 0 && (
                  <section className="space-y-2.5">
                    <h2 className="px-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Pinned
                    </h2>
                    <div
                      className={
                        gridView
                          ? 'columns-2 md:columns-3 lg:columns-4 gap-3 space-y-3'
                          : 'max-w-2xl mx-auto space-y-3'
                      }
                    >
                      {pinnedDisplayed.map((note) => (
                        <NoteCard
                          key={note.id}
                          note={note}
                          selected={selectedIds.includes(note.id)}
                          selectionMode={selectionMode}
                          onSelect={() => handleSelectNote(note.id)}
                          onLongPress={() => startCardSelection(note.id)}
                          onTogglePin={() => handleTogglePin(note.id, !note.isPinned)}
                        />
                      ))}
                    </div>
                  </section>
                )}

                {otherDisplayed.length > 0 && (
                  <section className="space-y-2.5">
                    {pinnedDisplayed.length > 0 && (
                      <h2 className="px-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                        Others
                      </h2>
                    )}
                    <div
                      className={
                        gridView
                          ? 'columns-2 md:columns-3 lg:columns-4 gap-3 space-y-3'
                          : 'max-w-2xl mx-auto space-y-3'
                      }
                    >
                      {otherDisplayed.map((note) => (
                        <NoteCard
                          key={note.id}
                          note={note}
                          selected={selectedIds.includes(note.id)}
                          selectionMode={selectionMode}
                          onSelect={() => handleSelectNote(note.id)}
                          onLongPress={() => startCardSelection(note.id)}
                          onTogglePin={() => handleTogglePin(note.id, !note.isPinned)}
                        />
                      ))}
                    </div>
                  </section>
                )}
              </div>
            )}
          </div>
        </main>
      )}

      {/* Image 4 Speed-Dial Floating Action Button (+ -> Image, Drawing, Audio, List, Text, ×) */}
      {(activeSection === 'notes' || activeSection === 'archive') && (
        <>
          {fabOpen && (
            <div
              className="animate-fade-in fixed inset-0 z-30 bg-slate-950/40 backdrop-blur-[1px]"
              onClick={() => setFabOpen(false)}
              aria-hidden="true"
            />
          )}

          <div className="fixed bottom-6 right-5 sm:right-8 z-40 flex flex-col items-end gap-2.5">
            {fabOpen && (
              <div className="animate-sheet-up flex flex-col items-end gap-2.5 mb-1">
                <button
                  type="button"
                  onClick={() => openNewNote({ action: 'image' })}
                  title="New image note"
                  className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-full bg-indigo-900 dark:bg-[#1E3A5F] hover:bg-indigo-800 dark:hover:bg-[#274B7A] text-white text-sm font-medium shadow-lg whitespace-nowrap transition-transform active:scale-95"
                >
                  <ImageIcon className="w-4 h-4" />
                  <span>Image</span>
                </button>
                <button
                  type="button"
                  onClick={() => openNewNote({ action: 'drawing' })}
                  title="New drawing note"
                  className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-full bg-indigo-900 dark:bg-[#1E3A5F] hover:bg-indigo-800 dark:hover:bg-[#274B7A] text-white text-sm font-medium shadow-lg whitespace-nowrap transition-transform active:scale-95"
                >
                  <Brush className="w-4 h-4" />
                  <span>Drawing</span>
                </button>
                <button
                  type="button"
                  onClick={() => openNewNote({ action: 'audio' })}
                  title="New audio note"
                  className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-full bg-indigo-900 dark:bg-[#1E3A5F] hover:bg-indigo-800 dark:hover:bg-[#274B7A] text-white text-sm font-medium shadow-lg whitespace-nowrap transition-transform active:scale-95"
                >
                  <Mic className="w-4 h-4" />
                  <span>Audio</span>
                </button>
                <button
                  type="button"
                  onClick={() => openNewNote({ checklist: true })}
                  title="New checklist"
                  className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-full bg-indigo-900 dark:bg-[#1E3A5F] hover:bg-indigo-800 dark:hover:bg-[#274B7A] text-white text-sm font-medium shadow-lg whitespace-nowrap transition-transform active:scale-95"
                >
                  <CheckSquare className="w-4 h-4" />
                  <span>List</span>
                </button>
                <button
                  type="button"
                  onClick={() => openNewNote()}
                  title="New text note"
                  className="inline-flex items-center gap-3 min-h-[44px] px-4 py-2 rounded-full bg-indigo-900 dark:bg-[#1E3A5F] hover:bg-indigo-800 dark:hover:bg-[#274B7A] text-white text-sm font-medium shadow-lg whitespace-nowrap transition-transform active:scale-95"
                >
                  <Type className="w-4 h-4" />
                  <span>Text</span>
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => setFabOpen((o) => !o)}
              aria-label={fabOpen ? 'Close create menu' : 'Create new note'}
              title={fabOpen ? 'Close menu' : 'Create new note'}
              className={`w-14 h-14 flex items-center justify-center shadow-xl transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 ${
                fabOpen
                  ? 'rounded-full bg-indigo-200 dark:bg-sky-200 text-slate-900'
                  : 'rounded-2xl bg-indigo-600 dark:bg-[#2B4C7E] hover:bg-indigo-700 dark:hover:bg-[#345C99] text-white'
              }`}
            >
              {fabOpen ? <X className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
            </button>
          </div>
        </>
      )}

      {/* Slide-out Navigation Drawer */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-50 flex"
          role="dialog"
          aria-modal="true"
          aria-label="Navigation menu"
        >
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs"
            onClick={() => setDrawerOpen(false)}
          />
          <aside className="relative z-10 w-72 max-w-[82vw] h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col p-4 shadow-2xl">
            <div className="flex items-center justify-between px-2 pb-4 mb-2 border-b border-slate-200 dark:border-slate-800">
              <span className="font-display text-lg font-bold text-slate-900 dark:text-slate-50">
                SmartNotesPro
              </span>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label="Close navigation menu"
                className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <nav className="space-y-1 flex-1 overflow-y-auto">
              <button
                type="button"
                onClick={() => {
                  clearSelection();
                  setActiveLabelFilter(null);
                  setActiveSection('notes');
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-full text-sm font-medium transition-colors ${
                  activeSection === 'notes' && !activeLabelFilter
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-900 dark:text-indigo-200'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span className="flex items-center gap-3">
                  <FileText className="w-4 h-4" />
                  <span>Notes</span>
                </span>
                <span className="text-xs tabular-nums opacity-75">
                  {liveNotes.length}
                </span>
              </button>

              {availableLabels.length > 0 && (
                <div className="pt-2 pb-1 space-y-0.5">
                  <p className="px-4 py-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                    Labels
                  </p>
                  {availableLabels.map((label) => {
                    const isActive =
                      activeSection === 'notes' &&
                      activeLabelFilter?.toLowerCase() === label.toLowerCase();
                    return (
                      <button
                        key={label}
                        type="button"
                        onClick={() => {
                          clearSelection();
                          setActiveSection('notes');
                          setActiveLabelFilter(label);
                          setDrawerOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-full text-sm font-medium transition-colors ${
                          isActive
                            ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-900 dark:text-indigo-200'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Tag className="w-4 h-4 shrink-0" />
                        <span className="truncate">{label}</span>
                      </button>
                    );
                  })}
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  clearSelection();
                  setActiveLabelFilter(null);
                  setActiveSection('archive');
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-full text-sm font-medium transition-colors ${
                  activeSection === 'archive'
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-900 dark:text-indigo-200'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Archive className="w-4 h-4" />
                  <span>Archive</span>
                </span>
                {archivedNotes.length > 0 && (
                  <span className="text-xs tabular-nums opacity-75">
                    {archivedNotes.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  clearSelection();
                  setActiveLabelFilter(null);
                  setActiveSection('trash');
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-full text-sm font-medium transition-colors ${
                  activeSection === 'trash'
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-900 dark:text-indigo-200'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Trash2 className="w-4 h-4" />
                  <span>Trash</span>
                </span>
                {trashedNotes.length > 0 && (
                  <span className="text-xs tabular-nums opacity-75">
                    {trashedNotes.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  clearSelection();
                  setActiveLabelFilter(null);
                  setActiveSection('settings');
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-full text-sm font-medium transition-colors ${
                  activeSection === 'settings'
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-900 dark:text-indigo-200'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
            </nav>
          </aside>
        </div>
      )}

      {/* Multi-Select Modals: Reminder, Colour/Background Palette, Labels */}
      {selectionModal === 'reminder' && selectedNotes.length === 1 && (
        <ReminderModal
          noteTitle={selectedNotes[0].title}
          currentReminderAt={selectedNotes[0].reminderAt}
          onSave={handleSaveSingleReminder}
          onClose={() => setSelectionModal('none')}
        />
      )}

      {selectionModal === 'palette' && selectedNotes.length > 0 && (
        <SelectionPaletteModal
          selectedNotes={selectedNotes}
          onSelectColor={handleBatchColor}
          onSelectBackground={handleBatchBackground}
          onClose={() => setSelectionModal('none')}
        />
      )}

      {selectionModal === 'labels' && selectedNotes.length > 0 && (
        <LabelsModal
          selectedNotes={selectedNotes}
          availableLabels={availableLabels}
          onToggleLabel={handleBatchToggleLabel}
          onAddLabel={handleAddLabelAndAssign}
          onRenameLabel={handleRenameLabel}
          onDeleteLabel={handleDeleteLabel}
          onClose={() => setSelectionModal('none')}
        />
      )}

      {/* Undo Snackbar Toast */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 left-4 right-24 sm:right-auto sm:left-6 z-50 flex items-center justify-between gap-3 rounded-xl border border-slate-800 dark:border-slate-700 bg-slate-900 dark:bg-slate-800 text-white px-4 py-3 shadow-lg max-w-sm"
        >
          <span className="text-xs text-slate-200 truncate">{toast.message}</span>
          <div className="flex items-center gap-2 shrink-0">
            {toast.undoLabel && toast.onUndo && (
              <button
                type="button"
                onClick={toast.onUndo}
                className="inline-flex items-center gap-1 min-h-[30px] px-2.5 py-1 rounded-md bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold text-white whitespace-nowrap"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{toast.undoLabel}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setToast(null)}
              aria-label="Dismiss"
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
      <LongPressTooltipLayer />
    </div>
  );
}
