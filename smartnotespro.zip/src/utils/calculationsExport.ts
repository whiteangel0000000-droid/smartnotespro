import { ExpressionMatch, formatResult } from './mathEvaluator';
import { saveAndShareBinaryFile } from './androidBridge';

export interface CalculationsExportOptions {
  noteTitle: string;
  matches: readonly ExpressionMatch[];
  total: number;
}

function makeFileSlug(title: string): string {
  const cleaned = title
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleaned || 'note';
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      if (ctx.measureText(word).width <= maxWidth) {
        current = word;
      } else {
        // Hard-break extra long token
        let slice = '';
        for (const ch of word) {
          if (ctx.measureText(slice + ch).width > maxWidth && slice) {
            lines.push(slice);
            slice = ch;
          } else {
            slice += ch;
          }
        }
        current = slice;
      }
    }
  }
  if (current) lines.push(current);
  return lines.length > 0 ? lines : [''];
}

function renderCalculationsCanvas({
  noteTitle,
  matches,
  total,
}: CalculationsExportOptions): HTMLCanvasElement {
  const width = 1200;
  const padX = 72;
  const headerH = 170;
  const footerH = 140;
  const rowBasePad = 26;
  const lineStep = 34;

  const measureCanvas = document.createElement('canvas');
  const mctx = measureCanvas.getContext('2d')!;
  mctx.font = '500 26px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';

  const rowLayouts = matches.map((m) => {
    const resultStr = `= ${formatResult(m.result)}`;
    mctx.font = '700 28px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    const resultW = Math.max(150, mctx.measureText(resultStr).width + 32);
    mctx.font = '500 26px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    const exprMaxW = width - padX * 2 - resultW - 48;
    const exprLines = wrapTextLines(mctx, m.expression.trim(), exprMaxW);
    const height = Math.max(76, rowBasePad * 2 + exprLines.length * lineStep);
    return { exprLines, resultStr, height };
  });

  const bodyH = rowLayouts.reduce((acc, r) => acc + r.height, 0);
  const totalHeight = Math.max(420, headerH + bodyH + footerH + 40);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = totalHeight;
  const ctx = canvas.getContext('2d')!;

  // White background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, totalHeight);

  // Subtle top accent bar
  ctx.fillStyle = '#4F46E5';
  ctx.fillRect(0, 0, width, 10);

  // Header
  const displayTitle = noteTitle.trim() || 'Calculations';
  ctx.fillStyle = '#0F172A';
  ctx.font = '700 40px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  ctx.fillText(displayTitle, padX, 78, width - padX * 2);

  const dateStr = new Date().toLocaleString([], {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  ctx.fillStyle = '#64748B';
  ctx.font = '500 22px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  ctx.fillText(
    `${matches.length} ${matches.length === 1 ? 'calculation' : 'calculations'}  ·  ${dateStr}`,
    padX,
    120
  );

  // Header divider
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(padX, headerH - 16);
  ctx.lineTo(width - padX, headerH - 16);
  ctx.stroke();

  // Calculation Rows
  let y = headerH;
  rowLayouts.forEach((row, idx) => {
    if (idx % 2 === 1) {
      ctx.fillStyle = '#F8FAFC';
      ctx.fillRect(padX - 16, y, width - (padX - 16) * 2, row.height);
    }

    // Index number
    ctx.fillStyle = '#94A3B8';
    ctx.font = '600 20px system-ui, -apple-system, sans-serif';
    ctx.fillText(`${idx + 1}.`, padX, y + 42);

    // Expression lines
    ctx.fillStyle = '#1E293B';
    ctx.font = '500 26px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    row.exprLines.forEach((line, lIdx) => {
      ctx.fillText(line, padX + 44, y + 42 + lIdx * lineStep);
    });

    // Result right-aligned
    ctx.fillStyle = '#4F46E5';
    ctx.font = '700 28px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    ctx.textAlign = 'right';
    ctx.fillText(row.resultStr, width - padX, y + 42);
    ctx.textAlign = 'left';

    y += row.height;

    ctx.strokeStyle = '#F1F5F9';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(padX, y);
    ctx.lineTo(width - padX, y);
    ctx.stroke();
  });

  // Total Footer Box
  const footerY = totalHeight - footerH + 16;
  ctx.fillStyle = '#EEF2FF';
  ctx.strokeStyle = '#C7D2FE';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(padX - 16, footerY, width - (padX - 16) * 2, 86, 16);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#312E81';
  ctx.font = '700 30px system-ui, -apple-system, sans-serif';
  ctx.fillText('Total', padX + 12, footerY + 54);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#4338CA';
  ctx.font = '700 34px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
  ctx.fillText(formatResult(total), width - padX - 12, footerY + 55);
  ctx.textAlign = 'left';

  return canvas;
}

export function buildPdfBytesFromJpeg(
  jpegBytes: Uint8Array,
  imgWidth: number,
  imgHeight: number
): Uint8Array {
  const encoder = new TextEncoder();
  const pageW = 595;
  const pageH = Math.max(220, Math.round((imgHeight / imgWidth) * pageW));
  const contentStream = `q ${pageW} 0 0 ${pageH} 0 0 cm /Im0 Do Q`;
  const contentBytes = encoder.encode(contentStream);

  const chunks: Uint8Array[] = [];
  const offsets: number[] = [];
  let cursor = 0;

  const pushStr = (s: string) => {
    const b = encoder.encode(s);
    chunks.push(b);
    cursor += b.length;
  };
  const pushBytes = (b: Uint8Array) => {
    chunks.push(b);
    cursor += b.length;
  };

  pushStr('%PDF-1.4\n%\xFF\xFF\xFF\xFF\n');

  // 1: Catalog
  offsets.push(cursor);
  pushStr('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  // 2: Pages
  offsets.push(cursor);
  pushStr('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');

  // 3: Page
  offsets.push(cursor);
  pushStr(
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>\nendobj\n`
  );

  // 4: Image XObject (JPEG /DCTDecode)
  offsets.push(cursor);
  pushStr(
    `4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imgWidth} /Height ${imgHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n`
  );
  pushBytes(jpegBytes);
  pushStr('\nendstream\nendobj\n');

  // 5: Page Content Stream
  offsets.push(cursor);
  pushStr(`5 0 obj\n<< /Length ${contentBytes.length} >>\nstream\n`);
  pushBytes(contentBytes);
  pushStr('\nendstream\nendobj\n');

  // Cross-reference table
  const xrefOffset = cursor;
  pushStr(`xref\n0 ${offsets.length + 1}\n0000000000 65535 f \n`);
  for (const off of offsets) {
    pushStr(`${String(off).padStart(10, '0')} 00000 n \n`);
  }
  pushStr(
    `trailer\n<< /Size ${offsets.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`
  );

  const out = new Uint8Array(cursor);
  let pos = 0;
  for (const chunk of chunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  return out;
}

function canvasToJpegBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Failed to encode JPEG'));
      },
      'image/jpeg',
      0.95
    );
  });
}

export async function downloadCalculationsAsJpg(
  options: CalculationsExportOptions
): Promise<void> {
  const canvas = renderCalculationsCanvas(options);
  const blob = await canvasToJpegBlob(canvas);
  const jpegBytes = new Uint8Array(await blob.arrayBuffer());
  await saveAndShareBinaryFile({
    filename: `${makeFileSlug(options.noteTitle)}-calculations.jpg`,
    bytes: jpegBytes,
    mimeType: 'image/jpeg',
    shareTitle: 'Export Calculations (JPG)',
  });
}

export async function downloadCalculationsAsPdf(
  options: CalculationsExportOptions
): Promise<void> {
  const canvas = renderCalculationsCanvas(options);
  const jpegBlob = await canvasToJpegBlob(canvas);
  const jpegBytes = new Uint8Array(await jpegBlob.arrayBuffer());
  const pdfBytes = buildPdfBytesFromJpeg(jpegBytes, canvas.width, canvas.height);
  await saveAndShareBinaryFile({
    filename: `${makeFileSlug(options.noteTitle)}-calculations.pdf`,
    bytes: pdfBytes,
    mimeType: 'application/pdf',
    shareTitle: 'Export Calculations (PDF)',
  });
}
