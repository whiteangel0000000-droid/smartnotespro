export type NoteBackgroundId =
  | 'none'
  | 'sunset'
  | 'culinary'
  | 'arch'
  | 'beach'
  | 'math'
  | 'botanical'
  | 'aurora'
  | 'nightsky'
  | 'dunes'
  | 'custom';

export type StickyNoteType =
  | 'text'
  | 'checklist'
  | 'audio'
  | 'handwriting'
  | 'image';

export type StickyCurveStyle = 'peel' | 'wave' | 'arch' | 'pill';

export type NotePriority = 'normal' | 'focus' | 'urgent';

export interface ChecklistItem {
  id: string;
  text: string;
  checked: boolean;
}

export interface NoteAttachment {
  id: string;
  type: 'image' | 'drawing' | 'audio';
  dataUrl: string;
  name?: string;
  durationSec?: number;
  createdAt: number;
}

export interface NoteColorOption {
  index: number;
  name: string;
  tone: 'neutral' | 'classic' | 'soft' | 'vibrant';
  swatchHex: string;
  lightCardClass: string;
  darkCardClass: string;
  lightEditorClass: string;
  darkEditorClass: string;
}

export const NOTE_COLOR_PALETTE: readonly NoteColorOption[] = [
  {
    index: 0,
    name: 'Default',
    tone: 'neutral',
    swatchHex: 'transparent',
    lightCardClass: 'bg-white border-slate-200',
    darkCardClass: 'dark:bg-slate-900 dark:border-slate-800',
    lightEditorClass: 'bg-white',
    darkEditorClass: 'dark:bg-slate-950',
  },
  // Classic deep accents
  {
    index: 1,
    name: 'Berry',
    tone: 'classic',
    swatchHex: '#9D2242',
    lightCardClass: 'bg-rose-50 border-rose-200',
    darkCardClass: 'dark:bg-[#4B1D28] dark:border-[#6A2B3A]',
    lightEditorClass: 'bg-rose-50/75',
    darkEditorClass: 'dark:bg-[#2E131A]',
  },
  {
    index: 2,
    name: 'Terracotta',
    tone: 'classic',
    swatchHex: '#A04525',
    lightCardClass: 'bg-orange-50 border-orange-200',
    darkCardClass: 'dark:bg-[#492519] dark:border-[#683625]',
    lightEditorClass: 'bg-orange-50/75',
    darkEditorClass: 'dark:bg-[#2C1811]',
  },
  {
    index: 3,
    name: 'Amber',
    tone: 'classic',
    swatchHex: '#B4690E',
    lightCardClass: 'bg-amber-50 border-amber-200',
    darkCardClass: 'dark:bg-[#4E360F] dark:border-[#6D4D19]',
    lightEditorClass: 'bg-amber-50/75',
    darkEditorClass: 'dark:bg-[#2C200B]',
  },
  {
    index: 4,
    name: 'Sage',
    tone: 'classic',
    swatchHex: '#2E6B4F',
    lightCardClass: 'bg-emerald-50 border-emerald-200',
    darkCardClass: 'dark:bg-[#1E3B2E] dark:border-[#2E5745]',
    lightEditorClass: 'bg-emerald-50/75',
    darkEditorClass: 'dark:bg-[#13261E]',
  },
  {
    index: 5,
    name: 'Teal',
    tone: 'classic',
    swatchHex: '#0E7C76',
    lightCardClass: 'bg-teal-50 border-teal-200',
    darkCardClass: 'dark:bg-[#134240] dark:border-[#1E605D]',
    lightEditorClass: 'bg-teal-50/75',
    darkEditorClass: 'dark:bg-[#0D2B2A]',
  },
  {
    index: 6,
    name: 'Storm',
    tone: 'classic',
    swatchHex: '#256D85',
    lightCardClass: 'bg-sky-50 border-sky-200',
    darkCardClass: 'dark:bg-[#1B3B4B] dark:border-[#29556B]',
    lightEditorClass: 'bg-sky-50/75',
    darkEditorClass: 'dark:bg-[#122630]',
  },
  // Soft pastel tints suited for calm note-taking
  {
    index: 7,
    name: 'Soft Lavender',
    tone: 'soft',
    swatchHex: '#C4B5FD',
    lightCardClass: 'bg-[#F5F3FF] border-[#DDD6FE]',
    darkCardClass: 'dark:bg-[#2D224A] dark:border-[#4A3878]',
    lightEditorClass: 'bg-[#F5F3FF]/90',
    darkEditorClass: 'dark:bg-[#1D1530]',
  },
  {
    index: 8,
    name: 'Blush Rose',
    tone: 'soft',
    swatchHex: '#FDA4AF',
    lightCardClass: 'bg-[#FFF1F2] border-[#FECDD3]',
    darkCardClass: 'dark:bg-[#4A1C29] dark:border-[#702B3F]',
    lightEditorClass: 'bg-[#FFF1F2]/90',
    darkEditorClass: 'dark:bg-[#2B1018]',
  },
  {
    index: 9,
    name: 'Peach Cloud',
    tone: 'soft',
    swatchHex: '#FDBA74',
    lightCardClass: 'bg-[#FFF7ED] border-[#FED7AA]',
    darkCardClass: 'dark:bg-[#472914] dark:border-[#6E4020]',
    lightEditorClass: 'bg-[#FFF7ED]/90',
    darkEditorClass: 'dark:bg-[#29170B]',
  },
  {
    index: 10,
    name: 'Mint Dew',
    tone: 'soft',
    swatchHex: '#86EFAC',
    lightCardClass: 'bg-[#ECFDF5] border-[#A7F3D0]',
    darkCardClass: 'dark:bg-[#143B2E] dark:border-[#205E49]',
    lightEditorClass: 'bg-[#ECFDF5]/90',
    darkEditorClass: 'dark:bg-[#0C261D]',
  },
  {
    index: 11,
    name: 'Sky Mist',
    tone: 'soft',
    swatchHex: '#93C5FD',
    lightCardClass: 'bg-[#F0F9FF] border-[#BAE6FD]',
    darkCardClass: 'dark:bg-[#14344B] dark:border-[#215275]',
    lightEditorClass: 'bg-[#F0F9FF]/90',
    darkEditorClass: 'dark:bg-[#0C2130]',
  },
  {
    index: 12,
    name: 'Warm Sand',
    tone: 'soft',
    swatchHex: '#E7D4B5',
    lightCardClass: 'bg-[#FAF6EE] border-[#E6DAC3]',
    darkCardClass: 'dark:bg-[#3A3124] dark:border-[#594B38]',
    lightEditorClass: 'bg-[#FAF6EE]/90',
    darkEditorClass: 'dark:bg-[#241E16]',
  },
  // Vibrant energetic accents
  {
    index: 13,
    name: 'Vibrant Coral',
    tone: 'vibrant',
    swatchHex: '#F43F5E',
    lightCardClass: 'bg-[#FFE4E6] border-[#FDA4AF]',
    darkCardClass: 'dark:bg-[#591829] dark:border-[#88253F]',
    lightEditorClass: 'bg-[#FFE4E6]/90',
    darkEditorClass: 'dark:bg-[#360E19]',
  },
  {
    index: 14,
    name: 'Vibrant Cobalt',
    tone: 'vibrant',
    swatchHex: '#3B82F6',
    lightCardClass: 'bg-[#EFF6FF] border-[#93C5FD]',
    darkCardClass: 'dark:bg-[#172E59] dark:border-[#254A8F]',
    lightEditorClass: 'bg-[#EFF6FF]/90',
    darkEditorClass: 'dark:bg-[#0E1D3B]',
  },
  {
    index: 15,
    name: 'Vibrant Emerald',
    tone: 'vibrant',
    swatchHex: '#10B981',
    lightCardClass: 'bg-[#DCFCE7] border-[#86EFAC]',
    darkCardClass: 'dark:bg-[#113D2B] dark:border-[#1B6144]',
    lightEditorClass: 'bg-[#DCFCE7]/90',
    darkEditorClass: 'dark:bg-[#0A261B]',
  },
  {
    index: 16,
    name: 'Royal Violet',
    tone: 'vibrant',
    swatchHex: '#8B5CF6',
    lightCardClass: 'bg-[#EDE9FE] border-[#C4B5FD]',
    darkCardClass: 'dark:bg-[#331E63] dark:border-[#513199]',
    lightEditorClass: 'bg-[#EDE9FE]/90',
    darkEditorClass: 'dark:bg-[#1F123D]',
  },
  {
    index: 17,
    name: 'Vibrant Gold',
    tone: 'vibrant',
    swatchHex: '#F59E0B',
    lightCardClass: 'bg-[#FEF3C7] border-[#FCD34D]',
    darkCardClass: 'dark:bg-[#4D340B] dark:border-[#785213]',
    lightEditorClass: 'bg-[#FEF3C7]/90',
    darkEditorClass: 'dark:bg-[#2E1F06]',
  },
] as const;

export const NOTE_COLOR_COUNT = NOTE_COLOR_PALETTE.length;

export const NOTE_BACKGROUNDS: readonly { id: NoteBackgroundId; name: string }[] = [
  { id: 'none', name: 'None' },
  { id: 'math', name: 'Blueprint Grid' },
  { id: 'botanical', name: 'Botanical' },
  { id: 'aurora', name: 'Aurora Glow' },
  { id: 'nightsky', name: 'Starry Night' },
  { id: 'dunes', name: 'Warm Dunes' },
  { id: 'sunset', name: 'Sunset Hills' },
  { id: 'culinary', name: 'Kitchen' },
  { id: 'arch', name: 'Geometric Arch' },
  { id: 'beach', name: 'Beach' },
] as const;

export const DEFAULT_NOTE_FONT_SIZE = 16;
export const MIN_NOTE_FONT_SIZE = 12;
export const MAX_NOTE_FONT_SIZE = 30;

export interface Note {
  id: number;
  title: string;
  content: string;
  richContent?: string;
  fontSize?: number;
  totalCalculation: number;
  colorTag: number;
  backgroundId?: NoteBackgroundId;
  customBackgroundUrl?: string;
  labels?: string[];
  isPinned: boolean;
  isArchived?: boolean;
  isChecklist?: boolean;
  checklistItems?: ChecklistItem[];
  attachments?: NoteAttachment[];
  excludedCalcKeys?: string[];
  createdAt: number;
  updatedAt: number;
  reminderAt: number | null;
  isStickyWidget?: boolean;
  stickyCurve?: StickyCurveStyle;
  stickyType?: StickyNoteType;
  priority?: NotePriority;
  isDeleted: boolean;
  deletedAt: number | null;
}

export function sanitizeColor(value: number): number {
  if (!Number.isFinite(value)) return 0;
  const int = Math.trunc(value);
  return Math.max(0, Math.min(NOTE_COLOR_COUNT - 1, int));
}

export function sanitizeFontSize(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    return DEFAULT_NOTE_FONT_SIZE;
  }
  const int = Math.round(value);
  return Math.max(MIN_NOTE_FONT_SIZE, Math.min(MAX_NOTE_FONT_SIZE, int));
}

export function sanitizeBackground(value: unknown): NoteBackgroundId {
  if (
    value === 'sunset' ||
    value === 'culinary' ||
    value === 'arch' ||
    value === 'beach' ||
    value === 'math' ||
    value === 'botanical' ||
    value === 'aurora' ||
    value === 'nightsky' ||
    value === 'dunes' ||
    value === 'custom'
  ) {
    return value;
  }
  return 'none';
}

export function sanitizeCustomBackgroundUrl(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  if (!trimmed) return undefined;
  if (
    trimmed.startsWith('data:image/') ||
    trimmed.startsWith('https://') ||
    trimmed.startsWith('http://') ||
    trimmed.startsWith('/')
  ) {
    return trimmed;
  }
  return undefined;
}

export const DEFAULT_LABELS: readonly string[] = [
  'Inspiration',
  'Work',
  'Personal',
] as const;

export function sanitizeLabels(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of value) {
    if (typeof raw !== 'string') continue;
    const trimmed = raw.trim();
    if (!trimmed) continue;
    const key = trimmed.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(trimmed);
  }
  return out;
}

export function sanitizeReminderAt(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
    return value;
  }
  return null;
}

export function sanitizeExcludedCalcKeys(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of value) {
    if (typeof raw !== 'string') continue;
    const trimmed = raw.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    out.push(trimmed);
  }
  return out;
}

export function sanitizeStickyCurve(value: unknown): StickyCurveStyle {
  if (value === 'wave' || value === 'arch' || value === 'pill') return value;
  return 'peel';
}

export function sanitizeStickyType(value: unknown): StickyNoteType | undefined {
  if (
    value === 'text' ||
    value === 'checklist' ||
    value === 'audio' ||
    value === 'handwriting' ||
    value === 'image'
  ) {
    return value;
  }
  return undefined;
}

export function sanitizePriority(value: unknown): NotePriority {
  if (value === 'focus' || value === 'urgent') return value;
  return 'normal';
}

export function inferStickyType(
  note: Pick<Note, 'stickyType' | 'isChecklist' | 'attachments'>
): StickyNoteType {
  if (note.stickyType) return note.stickyType;
  if (note.isChecklist) return 'checklist';
  const attachments = note.attachments ?? [];
  if (attachments.some((a) => a.type === 'drawing')) return 'handwriting';
  if (attachments.some((a) => a.type === 'audio')) return 'audio';
  if (attachments.some((a) => a.type === 'image')) return 'image';
  return 'text';
}

export function getNoteColorOption(tag: number): NoteColorOption {
  return NOTE_COLOR_PALETTE[sanitizeColor(tag)];
}

export function isNoteBlank(
  note: Pick<
    Note,
    'title' | 'content' | 'isChecklist' | 'checklistItems' | 'attachments'
  >
): boolean {
  const hasChecklistText = Boolean(
    note.isChecklist && note.checklistItems?.some((item) => item.text.trim().length > 0)
  );
  const hasAttachments = Boolean(note.attachments && note.attachments.length > 0);
  return (
    note.title.trim().length === 0 &&
    note.content.trim().length === 0 &&
    !hasChecklistText &&
    !hasAttachments
  );
}
