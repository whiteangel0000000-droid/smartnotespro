import {
  Archive,
  ArchiveRestore,
  ArrowLeft,
  Ban,
  Baseline,
  Bold,
  Brush,
  Camera,
  Check,
  CheckSquare,
  CopyPlus,
  Eye,
  Image as ImageIcon,
  ImageOff,
  ImagePlus,
  Italic,
  Mic,
  MoreVertical,
  Palette,
  PenLine,
  Pin,
  Plus,
  PlusSquare,
  Redo2,
  RemoveFormatting,
  Strikethrough,
  Trash2,
  Underline,
  Undo2,
  UserPlus,
  X,
} from 'lucide-react';
import React, {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  ChecklistItem,
  DEFAULT_NOTE_FONT_SIZE,
  getNoteColorOption,
  MAX_NOTE_FONT_SIZE,
  MIN_NOTE_FONT_SIZE,
  Note,
  NOTE_BACKGROUNDS,
  NOTE_COLOR_PALETTE,
  NoteAttachment,
  NoteBackgroundId,
  sanitizeBackground,
  sanitizeColor,
  sanitizeCustomBackgroundUrl,
  sanitizeExcludedCalcKeys,
  sanitizeFontSize,
} from '../../domain/model/note';
import {
  autoUpdatePrintedResultsInText,
  ExpressionMatch,
  findExpressions,
  formatEquation,
  formatPercentDelta,
  formatResult,
  getMatchKeys,
  isCaretInPrintedSuffix,
  replaceWithResult,
  totalOfMatches,
} from '../../utils/mathEvaluator';
import { sharePlainTextNatively } from '../../utils/androidBridge';
import {
  clearAllFormattingInSelection,
  clearFontSizeInSelection,
  extractPlainTextAndSegments,
  extractPlainTextFromHtml,
  getFontSizeAtNode,
  getPlainTextSelectionOffsets,
  normalizeDecorationNesting,
  plainTextToRichHtml,
  prepareFontSizeTargetSpan,
  replacePlainTextRangeInElement,
  restoreSelectionByPlainTextOffsets,
  sanitizeRichHtml,
} from '../../utils/richText';
import { countWords, formatTimestamp } from '../utils/formatters';
import { AudioRecorderModal } from './AudioRecorderModal';
import { CalcChipRow } from './CalcChipRow';
import { CalculationsModal } from './CalculationsModal';
import { DrawingCanvasModal } from './DrawingCanvasModal';
import { MarkdownPreview } from './MarkdownPreview';
import { NoteBackgroundArt } from './NoteBackgroundArt';
import { TotalBar } from './TotalBar';

export type EditorInitialAction = 'image' | 'drawing' | 'audio' | null;

interface EditorPaneProps {
  note: Note;
  draftKey: string | number;
  autoCalcEnabled: boolean;
  initialAction?: EditorInitialAction;
  onConsumeInitialAction?: () => void;
  onSaveNote: (draft: {
    id: number;
    title: string;
    content: string;
    richContent: string;
    fontSize: number;
    totalCalculation: number;
    colorTag: number;
    backgroundId: NoteBackgroundId;
    customBackgroundUrl?: string;
    isPinned: boolean;
    isArchived: boolean;
    isChecklist: boolean;
    checklistItems: ChecklistItem[];
    attachments: NoteAttachment[];
    excludedCalcKeys: string[];
  }) => Note;
  onTogglePin: (id: number, pinned: boolean) => void;
  onToggleArchive: (id: number, archived: boolean) => void;
  onDuplicateNote: (id: number) => void;
  onMoveToTrash: (id: number) => void;
  onBack: () => void;
}

interface RichSnapshot {
  html: string;
  text: string;
  fontSize: number;
}

interface ChecklistExpressionEntry {
  itemId: string;
  match: ExpressionMatch;
}

interface ActiveFormatsState {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
}

interface PercentAnnotation {
  key: string;
  text: string;
  isNegative: boolean;
  left: number;
  top: number;
  fontSize: number;
  alignRight: boolean;
  placement: 'inline-right' | 'below-right';
}

const MAX_HISTORY = 100;
const COALESCE_MS = 900;
const AUTO_SAVE_DELAY_MS = 450;

function makeId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function getInitialRichHtml(note: Note): string {
  if (note.richContent && note.richContent.trim().length > 0) {
    return sanitizeRichHtml(note.richContent);
  }
  return plainTextToRichHtml(note.content);
}

function readImageAsCompressedDataUrl(
  file: File,
  maxDim = 1280,
  quality = 0.82
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.onload = () => {
      const rawUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!rawUrl) {
        reject(new Error('Empty image'));
        return;
      }
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(rawUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => resolve(rawUrl);
      img.src = rawUrl;
    };
    reader.readAsDataURL(file);
  });
}

export function EditorPane({
  note,
  draftKey,
  autoCalcEnabled,
  initialAction = null,
  onConsumeInitialAction,
  onSaveNote,
  onTogglePin,
  onToggleArchive,
  onDuplicateNote,
  onMoveToTrash,
  onBack,
}: EditorPaneProps) {
  const titleInputRef = useRef<HTMLInputElement | null>(null);
  const editorContainerRef = useRef<HTMLDivElement | null>(null);
  const editorRef = useRef<HTMLDivElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const customBgInputRef = useRef<HTMLInputElement | null>(null);
  const checklistInputRefs = useRef<Map<string, HTMLInputElement>>(new Map());
  const [percentAnnotations, setPercentAnnotations] = useState<PercentAnnotation[]>([]);

  const [draftId, setDraftId] = useState<number>(note.id);
  const [title, setTitle] = useState<string>(note.title);
  const [content, setContent] = useState<string>(note.content);
  const [richContent, setRichContent] = useState<string>(() => getInitialRichHtml(note));
  const [fontSize, setFontSize] = useState<number>(() => sanitizeFontSize(note.fontSize));
  const [sliderFontSize, setSliderFontSize] = useState<number>(() =>
    sanitizeFontSize(note.fontSize)
  );
  const [colorTag, setColorTag] = useState<number>(sanitizeColor(note.colorTag));
  const [backgroundId, setBackgroundId] = useState<NoteBackgroundId>(
    sanitizeBackground(note.backgroundId)
  );
  const [customBackgroundUrl, setCustomBackgroundUrl] = useState<string | undefined>(() =>
    sanitizeCustomBackgroundUrl(note.customBackgroundUrl)
  );
  const [isPinned, setIsPinned] = useState<boolean>(note.isPinned);
  const [isArchived, setIsArchived] = useState<boolean>(Boolean(note.isArchived));
  const [isChecklist, setIsChecklist] = useState<boolean>(Boolean(note.isChecklist));
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>(
    note.checklistItems ?? []
  );
  const [attachments, setAttachments] = useState<NoteAttachment[]>(
    note.attachments ?? []
  );
  const [excludedCalcKeys, setExcludedCalcKeys] = useState<string[]>(() =>
    sanitizeExcludedCalcKeys(note.excludedCalcKeys)
  );
  const [updatedAt, setUpdatedAt] = useState<number>(note.updatedAt);

  // Toolbar / Sheet / Modal states
  const [activeSheet, setActiveSheet] = useState<'none' | 'add' | 'palette' | 'more'>(
    'none'
  );
  const [formatBarOpen, setFormatBarOpen] = useState<boolean>(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [drawingModalOpen, setDrawingModalOpen] = useState(false);
  const [audioModalOpen, setAudioModalOpen] = useState(false);
  const [calcModalOpen, setCalcModalOpen] = useState(false);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [statusToast, setStatusToast] = useState<string | null>(null);

  const [activeFormats, setActiveFormats] = useState<ActiveFormatsState>({
    bold: false,
    italic: false,
    underline: false,
    strike: false,
  });

  // Saved selection inside contentEditable so slider/toolbar buttons keep selection intact
  const savedRangeRef = useRef<Range | null>(null);
  const sliderGestureRecordedRef = useRef<boolean>(false);
  const sliderSessionRef = useRef<
    { mode: 'selection'; span: HTMLSpanElement } | { mode: 'note' } | null
  >(null);

  // Undo/redo stacks stored in refs with render tick
  const undoStackRef = useRef<RichSnapshot[]>([]);
  const redoStackRef = useRef<RichSnapshot[]>([]);
  const lastEditAtRef = useRef<number>(0);
  const lastSnapshotRef = useRef<RichSnapshot>({
    html: getInitialRichHtml(note),
    text: note.content,
    fontSize: sanitizeFontSize(note.fontSize),
  });
  const [historyTick, setHistoryTick] = useState(0);

  const lastSavedKeyRef = useRef<string>('');
  const saveTimerRef = useRef<number | null>(null);
  const isDiscardedRef = useRef<boolean>(false);
  const onSaveNoteRef = useRef(onSaveNote);
  onSaveNoteRef.current = onSaveNote;

  const richContentRef = useRef(richContent);
  richContentRef.current = richContent;
  const contentRef = useRef(content);
  contentRef.current = content;
  const fontSizeRef = useRef(fontSize);
  fontSizeRef.current = fontSize;

  const showToast = (msg: string) => {
    setStatusToast(msg);
    window.setTimeout(() => {
      setStatusToast((prev) => (prev === msg ? null : prev));
    }, 2000);
  };

  // Detect expressions in either plain content or checklist items
  const checklistExprEntries = useMemo<ChecklistExpressionEntry[]>(() => {
    if (!autoCalcEnabled || !isChecklist) return [];
    const entries: ChecklistExpressionEntry[] = [];
    for (const item of checklistItems) {
      for (const m of findExpressions(item.text)) {
        entries.push({ itemId: item.id, match: m });
      }
    }
    return entries;
  }, [autoCalcEnabled, isChecklist, checklistItems]);

  const textMatches = useMemo(() => {
    if (!autoCalcEnabled || isChecklist) return [];
    return findExpressions(content);
  }, [autoCalcEnabled, isChecklist, content]);

  const allMatches = useMemo(() => {
    if (!isChecklist) return textMatches;
    return checklistExprEntries.map((e, idx) => ({
      ...e.match,
      startIndex: idx * 10000 + e.match.startIndex,
    }));
  }, [isChecklist, textMatches, checklistExprEntries]);

  const matchKeys = useMemo(() => {
    if (!isChecklist) return getMatchKeys(textMatches);
    return getMatchKeys(
      checklistExprEntries.map((e) => e.match),
      checklistExprEntries.map((e) => e.itemId)
    );
  }, [isChecklist, textMatches, checklistExprEntries]);

  const excludedCalcSet = useMemo(
    () => new Set(excludedCalcKeys),
    [excludedCalcKeys]
  );

  const activeMatches = useMemo(
    () => allMatches.filter((_, idx) => !excludedCalcSet.has(matchKeys[idx])),
    [allMatches, matchKeys, excludedCalcSet]
  );

  const total = useMemo(() => {
    if (!autoCalcEnabled) return 0;
    return totalOfMatches(activeMatches);
  }, [autoCalcEnabled, activeMatches]);

  const words = useMemo(() => {
    if (isChecklist) {
      return countWords(checklistItems.map((i) => i.text).join(' '));
    }
    return countWords(content);
  }, [isChecklist, checklistItems, content]);

  const latestDraftRef = useRef({
    id: draftId,
    title,
    content,
    richContent,
    fontSize,
    colorTag,
    backgroundId,
    customBackgroundUrl,
    isPinned,
    isArchived,
    isChecklist,
    checklistItems,
    attachments,
    excludedCalcKeys,
    total,
  });
  latestDraftRef.current = {
    id: draftId,
    title,
    content,
    richContent,
    fontSize,
    colorTag,
    backgroundId,
    customBackgroundUrl,
    isPinned,
    isArchived,
    isChecklist,
    checklistItems,
    attachments,
    excludedCalcKeys,
    total,
  };

  const refreshToolbarStateFromSelection = useCallback(() => {
    const editor = editorRef.current;
    if (!editor || document.activeElement !== editor) return;
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    if (!editor.contains(range.commonAncestorContainer)) return;

    savedRangeRef.current = range.cloneRange();

    try {
      setActiveFormats({
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        strike: document.queryCommandState('strikeThrough'),
      });
    } catch {
      // Ignore queryCommandState errors on unsupported nodes
    }

    const detectedSize = getFontSizeAtNode(
      range.startContainer,
      editor,
      fontSizeRef.current
    );
    setSliderFontSize(detectedSize);
  }, []);

  useEffect(() => {
    const onSelectionChange = () => {
      refreshToolbarStateFromSelection();
    };
    document.addEventListener('selectionchange', onSelectionChange);
    return () => document.removeEventListener('selectionchange', onSelectionChange);
  }, [refreshToolbarStateFromSelection]);

  useEffect(() => {
    if (!lightboxUrl && activeSheet === 'none') return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (lightboxUrl) setLightboxUrl(null);
        else if (activeSheet !== 'none') setActiveSheet('none');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [lightboxUrl, activeSheet]);

  useEffect(() => {
    const onAndroidBack = (e: Event) => {
      e.preventDefault();
      if (lightboxUrl) {
        setLightboxUrl(null);
      } else if (drawingModalOpen) {
        setDrawingModalOpen(false);
      } else if (audioModalOpen) {
        setAudioModalOpen(false);
      } else if (calcModalOpen) {
        setCalcModalOpen(false);
      } else if (activeSheet !== 'none') {
        setActiveSheet('none');
      } else {
        onBack();
      }
    };
    window.addEventListener('smartnotes:android-back', onAndroidBack);
    return () =>
      window.removeEventListener('smartnotes:android-back', onAndroidBack);
  }, [
    lightboxUrl,
    drawingModalOpen,
    audioModalOpen,
    calcModalOpen,
    activeSheet,
    onBack,
  ]);

  // Keep focused editor / input smoothly visible when Android keyboard opens
  useEffect(() => {
    const vv = typeof window !== 'undefined' ? window.visualViewport : null;
    if (!vv) return;
    const onViewportResize = () => {
      const active = document.activeElement;
      if (
        active instanceof HTMLElement &&
        (active === editorRef.current ||
          (editorRef.current && editorRef.current.contains(active)) ||
          active.tagName === 'INPUT')
      ) {
        requestAnimationFrame(() => {
          const sel = window.getSelection();
          if (
            editorRef.current &&
            sel &&
            sel.rangeCount > 0 &&
            editorRef.current.contains(sel.getRangeAt(0).commonAncestorContainer)
          ) {
            const rect = sel.getRangeAt(0).getBoundingClientRect();
            if (rect.height > 0 && rect.bottom > vv.height - 96) {
              active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            }
          } else {
            active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          }
        });
      }
    };
    vv.addEventListener('resize', onViewportResize);
    return () => vv.removeEventListener('resize', onViewportResize);
  }, []);

  // Populate rich editor DOM BEFORE measuring inline delta annotations on mount / note switch / mode switch
  useLayoutEffect(() => {
    if (isChecklist || previewMode) return;
    const el = editorRef.current;
    if (!el) return;
    const targetHtml =
      richContentRef.current || plainTextToRichHtml(contentRef.current);
    if (el.innerHTML !== targetHtml) {
      el.innerHTML = targetHtml;
    }
  }, [draftKey, isChecklist, previewMode]);

  // Measure inline positions for operand value changes directly adjacent to calculation results
  useLayoutEffect(() => {
    if (isChecklist || previewMode || !autoCalcEnabled) {
      setPercentAnnotations([]);
      return;
    }
    const editorEl = editorRef.current;
    const containerEl = editorContainerRef.current;
    if (!editorEl || !containerEl) {
      setPercentAnnotations([]);
      return;
    }

    const computeAnnotations = () => {
      const containerRect = containerEl.getBoundingClientRect();
      if (containerRect.width === 0) return;

      const next: PercentAnnotation[] = [];
      for (const m of textMatches) {
        const deltaText = formatPercentDelta(m);
        if (!deltaText) continue;

        const targetEnd = (m.printedEndIndexInclusive ?? m.endIndexInclusive) + 1;
        const range = restoreSelectionByPlainTextOffsets(
          editorEl,
          m.startIndex,
          targetEnd
        );
        if (!range) continue;

        const rects = Array.from(range.getClientRects()).filter(
          (r) => r.width > 0 || r.height > 0
        );
        const lastRect =
          rects.length > 0 ? rects[rects.length - 1] : range.getBoundingClientRect();
        if (!lastRect || (lastRect.width === 0 && lastRect.height === 0)) continue;

        const endEl =
          range.endContainer.nodeType === Node.ELEMENT_NODE
            ? (range.endContainer as HTMLElement)
            : range.endContainer.parentElement;
        const computedPx = endEl
          ? Number.parseFloat(window.getComputedStyle(endEl).fontSize)
          : Number.NaN;
        const exprFontSize =
          Number.isFinite(computedPx) && computedPx > 0 ? computedPx : fontSize;
        const deltaFontSize = Math.max(
          10,
          Math.min(22, Math.round(exprFontSize * 0.68))
        );

        const rightOffset = lastRect.right - containerRect.left;
        const leftOffset = lastRect.left - containerRect.left;
        const nextNewlineIdx = content.indexOf('\n', targetEnd);
        const tailOnSameLine =
          nextNewlineIdx === -1
            ? content.slice(targetEnd)
            : content.slice(targetEnd, nextNewlineIdx);
        const hasTrailingTextOnLine = tailOnSameLine.trim().length > 0;
        const estimatedWidth = Math.max(
          24,
          deltaText.length * Math.max(6, Math.round(deltaFontSize * 0.65)) + 10
        );
        const canPlaceInlineRight =
          !hasTrailingTextOnLine && rightOffset + 6 + estimatedWidth <= containerRect.width;

        const alignRight = rightOffset >= 32;
        const placement: PercentAnnotation['placement'] = canPlaceInlineRight
          ? 'inline-right'
          : 'below-right';
        const left = canPlaceInlineRight
          ? rightOffset + 6
          : alignRight
            ? Math.min(rightOffset, containerRect.width)
            : Math.max(0, leftOffset);
        const topOffset = canPlaceInlineRight
          ? Math.max(0, lastRect.top - containerRect.top + lastRect.height * 0.56)
          : Math.max(0, lastRect.bottom - containerRect.top - 2);

        next.push({
          key: `${m.startIndex}:${deltaText}`,
          text: deltaText,
          isNegative: (m.percentDelta ?? 0) < 0,
          left,
          top: topOffset,
          fontSize: deltaFontSize,
          alignRight,
          placement,
        });
      }

      setPercentAnnotations((prev) => {
        if (
          prev.length === next.length &&
          prev.every(
            (p, i) =>
              p.key === next[i].key &&
              Math.abs(p.left - next[i].left) < 0.5 &&
              Math.abs(p.top - next[i].top) < 0.5 &&
              p.fontSize === next[i].fontSize &&
              p.alignRight === next[i].alignRight &&
              p.placement === next[i].placement
          )
        ) {
          return prev;
        }
        return next;
      });
    };

    computeAnnotations();

    let cancelled = false;
    if (typeof document !== 'undefined' && document.fonts?.ready) {
      void document.fonts.ready.then(() => {
        if (!cancelled) computeAnnotations();
      });
    }

    if (typeof ResizeObserver === 'undefined') {
      return () => {
        cancelled = true;
      };
    }
    const ro = new ResizeObserver(() => computeAnnotations());
    ro.observe(containerEl);
    ro.observe(editorEl);
    return () => {
      cancelled = true;
      ro.disconnect();
    };
  }, [
    draftKey,
    richContent,
    content,
    fontSize,
    sliderFontSize,
    textMatches,
    isChecklist,
    previewMode,
    autoCalcEnabled,
  ]);

  // Sync editor state when switching notes and flush pending edits on leave
  useEffect(() => {
    const nextId = note.id;
    const nextTitle = note.title;
    const nextContent = note.content;
    const nextRich = getInitialRichHtml(note);
    const nextFontSize = sanitizeFontSize(note.fontSize);
    const nextColor = sanitizeColor(note.colorTag);
    const nextBg = sanitizeBackground(note.backgroundId);
    const nextCustomBg = sanitizeCustomBackgroundUrl(note.customBackgroundUrl);
    const nextPinned = note.isPinned;
    const nextArchived = Boolean(note.isArchived);
    const nextChecklist = Boolean(note.isChecklist);
    const nextItems = note.checklistItems ?? [];
    const nextAttachments = note.attachments ?? [];
    const nextExcludedCalcKeys = sanitizeExcludedCalcKeys(note.excludedCalcKeys);
    const nextUpdated = note.updatedAt;

    isDiscardedRef.current = false;
    savedRangeRef.current = null;
    sliderSessionRef.current = null;
    setDraftId(nextId);
    setTitle(nextTitle);
    setContent(nextContent);
    setRichContent(nextRich);
    setFontSize(nextFontSize);
    setSliderFontSize(nextFontSize);
    setColorTag(nextColor);
    setBackgroundId(nextBg);
    setCustomBackgroundUrl(nextCustomBg);
    setIsPinned(nextPinned);
    setIsArchived(nextArchived);
    setIsChecklist(nextChecklist);
    setChecklistItems(nextItems);
    setAttachments(nextAttachments);
    setExcludedCalcKeys(nextExcludedCalcKeys);
    setUpdatedAt(nextUpdated);
    setActiveSheet('none');
    setFormatBarOpen(false);
    setPreviewMode(false);
    setDrawingModalOpen(false);
    setAudioModalOpen(false);
    setCalcModalOpen(false);
    setLightboxUrl(null);
    setActiveFormats({ bold: false, italic: false, underline: false, strike: false });

    undoStackRef.current = [];
    redoStackRef.current = [];
    lastEditAtRef.current = 0;
    lastSnapshotRef.current = {
      html: nextRich,
      text: nextContent,
      fontSize: nextFontSize,
    };
    setHistoryTick((t) => t + 1);

    const nextExcludedSet = new Set(nextExcludedCalcKeys);
    let initialTotal = 0;
    if (autoCalcEnabled) {
      if (nextChecklist) {
        const initEntries = nextItems.flatMap((i) =>
          findExpressions(i.text).map((m) => ({ itemId: i.id, match: m }))
        );
        const initMatches = initEntries.map((e) => e.match);
        const initKeys = getMatchKeys(
          initMatches,
          initEntries.map((e) => e.itemId)
        );
        initialTotal = totalOfMatches(
          initMatches.filter((_, idx) => !nextExcludedSet.has(initKeys[idx]))
        );
      } else {
        const initMatches = findExpressions(nextContent);
        const initKeys = getMatchKeys(initMatches);
        initialTotal = totalOfMatches(
          initMatches.filter((_, idx) => !nextExcludedSet.has(initKeys[idx]))
        );
      }
    }

    lastSavedKeyRef.current = JSON.stringify({
      id: nextId,
      title: nextTitle,
      content: nextContent,
      richContent: nextRich,
      fontSize: nextFontSize,
      colorTag: nextColor,
      backgroundId: nextBg,
      customBackgroundUrl: nextCustomBg ?? null,
      isPinned: nextPinned,
      isArchived: nextArchived,
      isChecklist: nextChecklist,
      checklistItems: nextItems,
      attachments: nextAttachments,
      excludedCalcKeys: nextExcludedCalcKeys,
      total: initialTotal,
    });

    if (nextId === 0 && !initialAction) {
      requestAnimationFrame(() => {
        if (nextChecklist) {
          titleInputRef.current?.focus();
        } else {
          editorRef.current?.focus();
        }
      });
    }

    return () => {
      if (saveTimerRef.current !== null) {
        window.clearTimeout(saveTimerRef.current);
        saveTimerRef.current = null;
      }
      if (isDiscardedRef.current) return;
      const d = latestDraftRef.current;
      const hasChecklistContent =
        d.isChecklist && d.checklistItems.some((i) => i.text.trim().length > 0);
      const hasMedia =
        d.attachments.length > 0 ||
        (d.backgroundId === 'custom' && Boolean(d.customBackgroundUrl));
      if (
        d.id === 0 &&
        !d.title.trim() &&
        !d.content.trim() &&
        !hasChecklistContent &&
        !hasMedia
      ) {
        return;
      }
      const key = JSON.stringify({
        id: d.id,
        title: d.title,
        content: d.content,
        richContent: d.richContent,
        fontSize: d.fontSize,
        colorTag: d.colorTag,
        backgroundId: d.backgroundId,
        customBackgroundUrl: d.customBackgroundUrl ?? null,
        isPinned: d.isPinned,
        isArchived: d.isArchived,
        isChecklist: d.isChecklist,
        checklistItems: d.checklistItems,
        attachments: d.attachments,
        excludedCalcKeys: d.excludedCalcKeys,
        total: d.total,
      });
      if (key !== lastSavedKeyRef.current) {
        onSaveNoteRef.current({
          id: d.id,
          title: d.title,
          content: d.content,
          richContent: d.richContent,
          fontSize: d.fontSize,
          totalCalculation: d.total,
          colorTag: d.colorTag,
          backgroundId: d.backgroundId,
          customBackgroundUrl: d.customBackgroundUrl,
          isPinned: d.isPinned,
          isArchived: d.isArchived,
          isChecklist: d.isChecklist,
          checklistItems: d.checklistItems,
          attachments: d.attachments,
          excludedCalcKeys: d.excludedCalcKeys,
        });
      }
    };
  }, [draftKey]);

  // Handle initial action from Home Speed Dial FAB
  useEffect(() => {
    if (!initialAction) return;
    if (initialAction === 'drawing') {
      setDrawingModalOpen(true);
    } else if (initialAction === 'audio') {
      setAudioModalOpen(true);
    } else if (initialAction === 'image') {
      requestAnimationFrame(() => imageInputRef.current?.click());
    }
    onConsumeInitialAction?.();
  }, [initialAction, onConsumeInitialAction]);

  // Sync pin/archive flags if changed externally
  useEffect(() => {
    if (note.id === draftId && draftId > 0) {
      setIsPinned(note.isPinned);
      setIsArchived(Boolean(note.isArchived));
      setUpdatedAt(note.updatedAt);
    }
  }, [note.isPinned, note.isArchived, note.updatedAt, draftId, note.id]);

  // Debounced auto-save
  useEffect(() => {
    const currentKey = JSON.stringify({
      id: draftId,
      title,
      content,
      richContent,
      fontSize,
      colorTag,
      backgroundId,
      customBackgroundUrl: customBackgroundUrl ?? null,
      isPinned,
      isArchived,
      isChecklist,
      checklistItems,
      attachments,
      excludedCalcKeys,
      total,
    });
    if (currentKey === lastSavedKeyRef.current) return;

    const hasChecklistContent =
      isChecklist && checklistItems.some((i) => i.text.trim().length > 0);
    const hasCustomBackground =
      backgroundId === 'custom' && Boolean(customBackgroundUrl);
    if (
      draftId === 0 &&
      !title.trim() &&
      !content.trim() &&
      !hasChecklistContent &&
      attachments.length === 0 &&
      !hasCustomBackground
    ) {
      return;
    }

    if (saveTimerRef.current !== null) {
      window.clearTimeout(saveTimerRef.current);
    }

    saveTimerRef.current = window.setTimeout(() => {
      saveTimerRef.current = null;
      const saved = onSaveNote({
        id: draftId,
        title,
        content,
        richContent,
        fontSize,
        totalCalculation: total,
        colorTag,
        backgroundId,
        customBackgroundUrl,
        isPinned,
        isArchived,
        isChecklist,
        checklistItems,
        attachments,
        excludedCalcKeys,
      });
      lastSavedKeyRef.current = JSON.stringify({
        id: saved.id,
        title: saved.title,
        content: saved.content,
        richContent: saved.richContent ?? '',
        fontSize: sanitizeFontSize(saved.fontSize),
        colorTag: saved.colorTag,
        backgroundId: sanitizeBackground(saved.backgroundId),
        customBackgroundUrl: sanitizeCustomBackgroundUrl(saved.customBackgroundUrl) ?? null,
        isPinned: saved.isPinned,
        isArchived: Boolean(saved.isArchived),
        isChecklist: Boolean(saved.isChecklist),
        checklistItems: saved.checklistItems ?? [],
        attachments: saved.attachments ?? [],
        excludedCalcKeys: sanitizeExcludedCalcKeys(saved.excludedCalcKeys),
        total: saved.totalCalculation,
      });
      setDraftId(saved.id);
      setUpdatedAt(saved.updatedAt);
    }, AUTO_SAVE_DELAY_MS);

    return () => {
      if (saveTimerRef.current !== null) {
        window.clearTimeout(saveTimerRef.current);
      }
    };
  }, [
    draftId,
    title,
    content,
    richContent,
    fontSize,
    colorTag,
    backgroundId,
    customBackgroundUrl,
    isPinned,
    isArchived,
    isChecklist,
    checklistItems,
    attachments,
    excludedCalcKeys,
    total,
    onSaveNote,
  ]);

  const pushUndo = (snapshot: RichSnapshot) => {
    const stack = undoStackRef.current;
    stack.push(snapshot);
    if (stack.length > MAX_HISTORY) stack.shift();
  };

  const syncFromEditorDom = (recordCoalescedUndo: boolean, forceDiscreteUndo = false) => {
    const el = editorRef.current;
    if (!el) return;
    let rawHtml = el.innerHTML;
    let { text: nextText } = extractPlainTextAndSegments(el);
    const prevSnapshot = lastSnapshotRef.current;

    if ((recordCoalescedUndo || forceDiscreteUndo) && autoCalcEnabled) {
      const sel = window.getSelection();
      const currentRange = sel && sel.rangeCount > 0 ? sel.getRangeAt(0) : null;
      const caretOffsets =
        currentRange && el.contains(currentRange.commonAncestorContainer)
          ? getPlainTextSelectionOffsets(el, currentRange)
          : null;

      const liveMatches = findExpressions(nextText);
      let didAutoUpdate = false;
      let nextCaretOffset: { start: number; end: number } | null = caretOffsets;

      // Instant "=" auto-evaluation right after typing "=" on an unprinted expression
      if (
        recordCoalescedUndo &&
        caretOffsets &&
        caretOffsets.start === caretOffsets.end &&
        caretOffsets.start > 0 &&
        nextText.length > prevSnapshot.text.length &&
        nextText[caretOffsets.start - 1] === '='
      ) {
        const eqIdx = caretOffsets.start - 1;
        const eqMatch = liveMatches.find(
          (m) =>
            !m.isApplied &&
            m.printedEndIndexInclusive === undefined &&
            m.endIndexInclusive + 1 <= eqIdx &&
            /^[ \t]*$/.test(nextText.slice(m.endIndexInclusive + 1, eqIdx))
        );
        if (eqMatch) {
          const nextSuffix = ` = ${formatResult(eqMatch.result)}`;
          const replaced = replacePlainTextRangeInElement(
            el,
            eqMatch.endIndexInclusive + 1,
            eqIdx,
            nextSuffix
          );
          if (replaced) {
            didAutoUpdate = true;
            const afterEnd = eqMatch.endIndexInclusive + 1 + nextSuffix.length;
            nextCaretOffset = { start: afterEnd, end: afterEnd };
          }
        }
      }

      if (!didAutoUpdate) {
        for (let i = liveMatches.length - 1; i >= 0; i--) {
          const m = liveMatches[i];
          if (m.printedEndIndexInclusive === undefined || m.isApplied) continue;
          if (
            isCaretInPrintedSuffix(
              m,
              caretOffsets?.start ?? null,
              caretOffsets?.end ?? null
            )
          ) {
            continue;
          }

          const nextSuffix = ` = ${formatResult(m.result)}`;
          const replaced = replacePlainTextRangeInElement(
            el,
            m.endIndexInclusive + 1,
            m.printedEndIndexInclusive,
            nextSuffix
          );
          if (replaced) {
            didAutoUpdate = true;
          }
        }
      }

      if (didAutoUpdate) {
        if (nextCaretOffset && sel) {
          const restored = restoreSelectionByPlainTextOffsets(
            el,
            nextCaretOffset.start,
            nextCaretOffset.end
          );
          if (restored) {
            sel.removeAllRanges();
            sel.addRange(restored);
            savedRangeRef.current = restored.cloneRange();
          }
        }
        rawHtml = el.innerHTML;
        nextText = extractPlainTextAndSegments(el).text;
      }
    }

    if (forceDiscreteUndo) {
      pushUndo(prevSnapshot);
      redoStackRef.current = [];
      lastEditAtRef.current = 0;
    } else if (recordCoalescedUndo) {
      const now = Date.now();
      const isSmallEdit = Math.abs(nextText.length - prevSnapshot.text.length) <= 1;
      const coalesce =
        undoStackRef.current.length > 0 &&
        isSmallEdit &&
        now - lastEditAtRef.current < COALESCE_MS;
      if (!coalesce) {
        pushUndo(prevSnapshot);
      }
      redoStackRef.current = [];
      lastEditAtRef.current = now;
    }

    lastSnapshotRef.current = {
      html: rawHtml,
      text: nextText,
      fontSize: fontSizeRef.current,
    };
    setRichContent(rawHtml);
    setContent(nextText);
    setHistoryTick((t) => t + 1);
  };

  const restoreSnapshot = (snap: RichSnapshot) => {
    lastSnapshotRef.current = snap;
    setRichContent(snap.html);
    setContent(snap.text);
    setFontSize(snap.fontSize);
    setSliderFontSize(snap.fontSize);
    setHistoryTick((t) => t + 1);
    requestAnimationFrame(() => {
      const el = editorRef.current;
      if (el) {
        el.innerHTML = snap.html;
        el.focus();
        const sel = window.getSelection();
        if (sel) {
          const range = document.createRange();
          range.selectNodeContents(el);
          range.collapse(false);
          sel.removeAllRanges();
          sel.addRange(range);
          savedRangeRef.current = range.cloneRange();
        }
        refreshToolbarStateFromSelection();
      }
    });
  };

  const handleUndo = () => {
    if (undoStackRef.current.length === 0) return;
    const currentSnap: RichSnapshot = {
      html: editorRef.current ? editorRef.current.innerHTML : richContent,
      text: content,
      fontSize,
    };
    redoStackRef.current.push(currentSnap);
    const prev = undoStackRef.current.pop()!;
    lastEditAtRef.current = 0;
    restoreSnapshot(prev);
  };

  const handleRedo = () => {
    if (redoStackRef.current.length === 0) return;
    const currentSnap: RichSnapshot = {
      html: editorRef.current ? editorRef.current.innerHTML : richContent,
      text: content,
      fontSize,
    };
    undoStackRef.current.push(currentSnap);
    const next = redoStackRef.current.pop()!;
    lastEditAtRef.current = 0;
    restoreSnapshot(next);
  };

  // Focus editor and restore saved range before executing formatting commands
  const ensureSelectionInEditor = (): Range | null => {
    const el = editorRef.current;
    if (!el) return null;
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const current = sel.getRangeAt(0);
      if (el.contains(current.commonAncestorContainer)) {
        return current;
      }
    }
    el.focus();
    if (savedRangeRef.current && el.contains(savedRangeRef.current.commonAncestorContainer)) {
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(savedRangeRef.current);
      }
      return savedRangeRef.current;
    }
    const fallbackRange = document.createRange();
    fallbackRange.selectNodeContents(el);
    fallbackRange.collapse(false);
    if (sel) {
      sel.removeAllRanges();
      sel.addRange(fallbackRange);
    }
    savedRangeRef.current = fallbackRange.cloneRange();
    return fallbackRange;
  };

  const applyRichCommand = (command: 'bold' | 'italic' | 'underline' | 'strikeThrough') => {
    if (isChecklist || previewMode) return;
    const el = editorRef.current;
    const range = ensureSelectionInEditor();
    if (!el || !range) return;

    pushUndo({
      html: el.innerHTML,
      text: content,
      fontSize,
    });
    redoStackRef.current = [];
    lastEditAtRef.current = 0;

    document.execCommand(command, false);

    // Ensure any <s> / <u> stays inside <span style="font-size: ..."> for accurate strike/underline alignment
    const sel = window.getSelection();
    const currentRange = sel && sel.rangeCount > 0 ? sel.getRangeAt(0) : null;
    const offsets = currentRange ? getPlainTextSelectionOffsets(el, currentRange) : null;
    normalizeDecorationNesting(el);
    if (offsets && sel) {
      const restored = restoreSelectionByPlainTextOffsets(el, offsets.start, offsets.end);
      if (restored) {
        sel.removeAllRanges();
        sel.addRange(restored);
        savedRangeRef.current = restored.cloneRange();
      }
    }

    refreshToolbarStateFromSelection();
    syncFromEditorDom(false, false);
  };

  const handleClearFormatting = () => {
    if (isChecklist || previewMode) return;
    const el = editorRef.current;
    const range = ensureSelectionInEditor();
    if (!el || !range) return;

    pushUndo({
      html: el.innerHTML,
      text: content,
      fontSize,
    });
    redoStackRef.current = [];
    lastEditAtRef.current = 0;

    // Turn off any pending collapsed typing states first
    if (range.collapsed) {
      (['bold', 'italic', 'underline', 'strikeThrough'] as const).forEach((cmd) => {
        try {
          if (document.queryCommandState(cmd)) {
            document.execCommand(cmd, false);
          }
        } catch {
          // Ignore
        }
      });
    } else {
      document.execCommand('removeFormat', false);
    }

    const updatedSelRange = window.getSelection()?.rangeCount
      ? window.getSelection()!.getRangeAt(0)
      : range;
    const nextRange = clearAllFormattingInSelection(el, updatedSelRange);
    if (nextRange) {
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(nextRange);
      }
      savedRangeRef.current = nextRange.cloneRange();
    }

    setActiveFormats({ bold: false, italic: false, underline: false, strike: false });
    setSliderFontSize(fontSize);
    syncFromEditorDom(false, false);
  };

  const beginSliderSession = () => {
    if (sliderSessionRef.current) return;
    sliderGestureRecordedRef.current = false;
    const el = editorRef.current;
    if (!el || isChecklist || previewMode) {
      sliderSessionRef.current = { mode: 'note' };
      return;
    }

    let activeRange: Range | null = null;
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const r = sel.getRangeAt(0);
      if (el.contains(r.commonAncestorContainer) && !r.collapsed && r.toString().length > 0) {
        activeRange = r.cloneRange();
      }
    }
    if (
      !activeRange &&
      savedRangeRef.current &&
      el.contains(savedRangeRef.current.commonAncestorContainer) &&
      !savedRangeRef.current.collapsed &&
      savedRangeRef.current.toString().length > 0
    ) {
      activeRange = savedRangeRef.current.cloneRange();
    }

    if (activeRange) {
      const prepared = prepareFontSizeTargetSpan(el, activeRange, sliderFontSize);
      if (prepared) {
        savedRangeRef.current = prepared.range.cloneRange();
        sliderSessionRef.current = { mode: 'selection', span: prepared.span };
        return;
      }
    }

    sliderSessionRef.current = { mode: 'note' };
  };

  const endSliderSession = (restoreVisualHighlight = false) => {
    const session = sliderSessionRef.current;
    sliderSessionRef.current = null;
    sliderGestureRecordedRef.current = false;
    const el = editorRef.current;
    if (session?.mode === 'selection' && session.span.isConnected) {
      const nextRange = document.createRange();
      nextRange.selectNodeContents(session.span);
      savedRangeRef.current = nextRange.cloneRange();
      if (restoreVisualHighlight && el) {
        el.focus({ preventScroll: true });
        const sel = window.getSelection();
        if (sel) {
          sel.removeAllRanges();
          sel.addRange(nextRange);
        }
      }
    }
  };

  const handleFontSizeSliderChange = (nextSizeRaw: number) => {
    const nextSize = sanitizeFontSize(nextSizeRaw);
    setSliderFontSize(nextSize);
    if (isChecklist || previewMode) {
      setFontSize(nextSize);
      return;
    }

    const el = editorRef.current;
    if (!sliderSessionRef.current) {
      beginSliderSession();
    }

    if (!sliderGestureRecordedRef.current) {
      pushUndo({
        html: el ? el.innerHTML : richContent,
        text: content,
        fontSize,
      });
      redoStackRef.current = [];
      sliderGestureRecordedRef.current = true;
    }

    const session = sliderSessionRef.current;
    if (el && session?.mode === 'selection' && session.span.isConnected) {
      session.span.style.fontSize = `${nextSize}px`;
      const nextRange = document.createRange();
      nextRange.selectNodeContents(session.span);
      savedRangeRef.current = nextRange;
      const html = el.innerHTML;
      const { text } = extractPlainTextAndSegments(el);
      lastSnapshotRef.current = { html, text, fontSize: fontSizeRef.current };
      setRichContent(html);
      setContent(text);
      setHistoryTick((t) => t + 1);
    } else {
      setFontSize(nextSize);
      lastSnapshotRef.current = {
        html: el ? el.innerHTML : richContent,
        text: content,
        fontSize: nextSize,
      };
    }
  };

  const handleResetDefaultFontSize = () => {
    if (isChecklist || previewMode) {
      setFontSize(DEFAULT_NOTE_FONT_SIZE);
      setSliderFontSize(DEFAULT_NOTE_FONT_SIZE);
      return;
    }

    const el = editorRef.current;
    pushUndo({
      html: el ? el.innerHTML : richContent,
      text: content,
      fontSize,
    });
    redoStackRef.current = [];

    const saved = savedRangeRef.current;
    if (el && saved && !saved.collapsed && el.contains(saved.commonAncestorContainer)) {
      const nextRange = clearFontSizeInSelection(saved);
      if (nextRange) {
        savedRangeRef.current = nextRange.cloneRange();
        const sel = window.getSelection();
        if (sel) {
          sel.removeAllRanges();
          sel.addRange(nextRange);
        }
      }
      setSliderFontSize(fontSize);
      syncFromEditorDom(false, false);
      return;
    }

    // No text selected: reset the note base font size to default AND unwrap inline font-size spans
    if (el) {
      const spans = Array.from(el.querySelectorAll('span[style*="font-size"]'));
      for (const span of spans) {
        const htmlSpan = span as HTMLElement;
        htmlSpan.style.removeProperty('font-size');
        if (!htmlSpan.getAttribute('style')?.trim()) {
          const frag = document.createDocumentFragment();
          while (htmlSpan.firstChild) frag.appendChild(htmlSpan.firstChild);
          htmlSpan.parentNode?.replaceChild(frag, htmlSpan);
        }
      }
    }
    setFontSize(DEFAULT_NOTE_FONT_SIZE);
    setSliderFontSize(DEFAULT_NOTE_FONT_SIZE);
    if (el) {
      const html = el.innerHTML;
      const { text } = extractPlainTextAndSegments(el);
      lastSnapshotRef.current = { html, text, fontSize: DEFAULT_NOTE_FONT_SIZE };
      setRichContent(html);
      setContent(text);
      setHistoryTick((t) => t + 1);
    }
  };

  const handleApplyExpression = (chipMatch: ExpressionMatch) => {
    if (!isChecklist) {
      const replacedPlain = replaceWithResult(content, chipMatch);
      if (replacedPlain === content) return;

      const fullEquation = formatEquation(chipMatch);

      if (editorRef.current && !previewMode) {
        pushUndo({
          html: editorRef.current.innerHTML,
          text: content,
          fontSize,
        });
        redoStackRef.current = [];
        const didReplace = replacePlainTextRangeInElement(
          editorRef.current,
          chipMatch.startIndex,
          chipMatch.endIndexInclusive,
          fullEquation
        );
        if (didReplace) {
          syncFromEditorDom(false, false);
          return;
        }
      }

      // Preview mode or detached fallback: apply on a temporary sanitized container
      const temp = document.createElement('div');
      temp.innerHTML = richContent || plainTextToRichHtml(content);
      const didReplaceDetached = replacePlainTextRangeInElement(
        temp,
        chipMatch.startIndex,
        chipMatch.endIndexInclusive,
        fullEquation
      );
      const nextHtml = didReplaceDetached
        ? temp.innerHTML
        : plainTextToRichHtml(replacedPlain);
      const nextText = didReplaceDetached
        ? extractPlainTextFromHtml(nextHtml)
        : replacedPlain;
      pushUndo({ html: richContent, text: content, fontSize });
      redoStackRef.current = [];
      lastSnapshotRef.current = { html: nextHtml, text: nextText, fontSize };
      setRichContent(nextHtml);
      setContent(nextText);
      setHistoryTick((t) => t + 1);
      return;
    }

    const idx = Math.floor(chipMatch.startIndex / 10000);
    const entry = checklistExprEntries[idx];
    if (!entry) return;
    setChecklistItems((prev) =>
      prev.map((item) =>
        item.id === entry.itemId
          ? { ...item, text: replaceWithResult(item.text, entry.match) }
          : item
      )
    );
  };

  const focusChecklistItem = (itemId: string) => {
    requestAnimationFrame(() => {
      const targetInput = checklistInputRefs.current.get(itemId);
      if (targetInput) {
        targetInput.focus();
        const len = targetInput.value.length;
        targetInput.setSelectionRange(len, len);
      }
    });
  };

  const removeChecklistItem = (itemId: string, focusOnRemove = false) => {
    const idx = checklistItems.findIndex((c) => c.id === itemId);
    if (idx === -1) return;

    if (checklistItems.length <= 1) {
      setContent('');
      setRichContent('');
      setChecklistItems([]);
      setIsChecklist(false);
      lastSnapshotRef.current = { html: '', text: '', fontSize };
      if (focusOnRemove) {
        requestAnimationFrame(() => editorRef.current?.focus());
      }
      return;
    }

    const nextItems = checklistItems.filter((c) => c.id !== itemId);
    setChecklistItems(nextItems);
    if (focusOnRemove) {
      const targetIdx = Math.max(0, idx - 1);
      const targetId = nextItems[targetIdx]?.id;
      if (targetId) {
        focusChecklistItem(targetId);
      }
    }
  };

  const handleToggleChecklistMode = () => {
    if (!isChecklist) {
      const liveText =
        editorRef.current && !previewMode
          ? extractPlainTextAndSegments(editorRef.current).text
          : content;
      const lines = liveText
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l.length > 0);
      const items: ChecklistItem[] =
        lines.length > 0
          ? lines.map((text) => ({ id: makeId('chk'), text, checked: false }))
          : [{ id: makeId('chk'), text: '', checked: false }];
      setChecklistItems(items);
      setContent('');
      setRichContent('');
      setIsChecklist(true);
      setFormatBarOpen(false);
      setPreviewMode(false);
      if (items[0]) {
        focusChecklistItem(items[0].id);
      }
    } else {
      const joined = checklistItems
        .map((i) => i.text)
        .filter((t) => t.trim().length > 0)
        .join('\n');
      const nextHtml = plainTextToRichHtml(joined);
      setContent(joined);
      setRichContent(nextHtml);
      setChecklistItems([]);
      setIsChecklist(false);
      setFormatBarOpen(false);
      lastSnapshotRef.current = {
        html: nextHtml,
        text: joined,
        fontSize,
      };
      requestAnimationFrame(() => editorRef.current?.focus());
    }
    setActiveSheet('none');
  };

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    setActiveSheet('none');
    if (files.length === 0) return;

    const added: NoteAttachment[] = [];
    for (const file of files) {
      try {
        const dataUrl = await readImageAsCompressedDataUrl(file);
        added.push({
          id: makeId('img'),
          type: 'image',
          dataUrl,
          name: file.name,
          createdAt: Date.now(),
        });
      } catch {
        // Skip unreadable image
      }
    }
    if (added.length > 0) {
      setAttachments((prev) => [...prev, ...added]);
    }
  };

  const handleCustomBackgroundSelected = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const dataUrl = await readImageAsCompressedDataUrl(file, 1440, 0.8);
      setCustomBackgroundUrl(dataUrl);
      setBackgroundId('custom');
      showToast('Custom background applied');
    } catch {
      showToast('Could not load background image');
    }
  };

  const handleShareOrCopy = async () => {
    const bodyText = isChecklist
      ? checklistItems
          .map((i) => `${i.checked ? '[x]' : '[ ]'} ${i.text}`)
          .join('\n')
      : content;
    const shareBody = title.trim() ? `${title.trim()}\n\n${bodyText}` : bodyText;
    const outcome = await sharePlainTextNatively(
      title.trim() || 'SmartNotesPro',
      shareBody
    );
    if (outcome === 'copied') {
      showToast('Copied note to clipboard');
    }
  };

  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.metaKey && !e.ctrlKey && !e.altKey) {
      const el = editorRef.current;
      const sel = window.getSelection();
      if (el && sel && sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        if (range.collapsed && el.contains(range.commonAncestorContainer)) {
          const offsets = getPlainTextSelectionOffsets(el, range);
          if (offsets) {
            const { text } = extractPlainTextAndSegments(el);
            const caretPos = offsets.start;
            const prevNl = text.lastIndexOf('\n', caretPos - 1);
            const lineStart = prevNl === -1 ? 0 : prevNl + 1;
            const lineUpToCaret = text.slice(lineStart, caretPos);
            const bulletMatch = /^([ \t]*)([-*•])\s(.*)$/.exec(lineUpToCaret);
            const numberMatch = /^([ \t]*)(\d+)\.\s(.*)$/.exec(lineUpToCaret);
            const listMatch = bulletMatch || numberMatch;

            if (listMatch) {
              const indent = listMatch[1];
              const body = listMatch[3];
              const nextNl = text.indexOf('\n', caretPos);
              const trailing =
                nextNl === -1 ? text.slice(caretPos) : text.slice(caretPos, nextNl);

              if (body.trim().length === 0 && trailing.trim().length === 0) {
                e.preventDefault();
                pushUndo({
                  html: el.innerHTML,
                  text: content,
                  fontSize,
                });
                const removed = replacePlainTextRangeInElement(
                  el,
                  lineStart,
                  caretPos - 1,
                  ''
                );
                if (removed) {
                  const restored = restoreSelectionByPlainTextOffsets(
                    el,
                    lineStart,
                    lineStart
                  );
                  if (restored) {
                    sel.removeAllRanges();
                    sel.addRange(restored);
                    savedRangeRef.current = restored.cloneRange();
                  }
                }
                syncFromEditorDom(false, false);
                return;
              }

              e.preventDefault();
              pushUndo({
                html: el.innerHTML,
                text: content,
                fontSize,
              });
              const nextPrefix = bulletMatch
                ? `${indent}${bulletMatch[2]} `
                : `${indent}${Number(numberMatch![2]) + 1}. `;
              document.execCommand('insertParagraph', false);
              document.execCommand('insertText', false, nextPrefix);
              syncFromEditorDom(false, false);
              return;
            }
          }
        }
      }
    }

    const mod = e.metaKey || e.ctrlKey;
    if (!mod) return;
    const key = e.key.toLowerCase();
    if (key === 'z' && !e.shiftKey) {
      e.preventDefault();
      handleUndo();
    } else if ((key === 'z' && e.shiftKey) || key === 'y') {
      e.preventDefault();
      handleRedo();
    } else if (key === 'b') {
      e.preventDefault();
      applyRichCommand('bold');
    } else if (key === 'i') {
      e.preventDefault();
      applyRichCommand('italic');
    } else if (key === 'u') {
      e.preventDefault();
      applyRichCommand('underline');
    } else if (key === 'x' && e.shiftKey) {
      e.preventDefault();
      applyRichCommand('strikeThrough');
    }
  };

  const handleEditorPaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
    e.preventDefault();
    const plain = e.clipboardData.getData('text/plain');
    if (!plain) return;
    document.execCommand('insertText', false, plain);
    syncFromEditorDom(false, true);
  };

  void historyTick;
  const canUndo = undoStackRef.current.length > 0;
  const canRedo = redoStackRef.current.length > 0;
  const colorOption = getNoteColorOption(colorTag);

  const visualAttachments = attachments.filter(
    (a) => a.type === 'image' || a.type === 'drawing'
  );
  const audioAttachments = attachments.filter((a) => a.type === 'audio');
  const isEditorEmpty = content.length === 0;

  return (
    <div
      className={`relative flex-1 flex flex-col min-h-0 overflow-hidden transition-colors duration-200 ${colorOption.lightEditorClass} ${colorOption.darkEditorClass}`}
    >
      <NoteBackgroundArt
        backgroundId={backgroundId}
        customBackgroundUrl={customBackgroundUrl}
        variant="surface"
      />

      {/* Top Action Bar */}
      <header className="relative z-20 flex items-center justify-between gap-2 px-3 sm:px-5 py-3">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back to notes"
          title="Back to notes"
          className="min-h-[42px] min-w-[42px] inline-flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {!isChecklist && (
            <>
              <button
                type="button"
                disabled={!canUndo}
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleUndo}
                aria-label="Undo"
                title="Undo (Ctrl+Z)"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15 disabled:opacity-35 disabled:pointer-events-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              >
                <Undo2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                disabled={!canRedo}
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleRedo}
                aria-label="Redo"
                title="Redo (Ctrl+Y)"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15 disabled:opacity-35 disabled:pointer-events-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              >
                <Redo2 className="w-4 h-4" />
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => {
              const nextPinned = !isPinned;
              setIsPinned(nextPinned);
              if (draftId > 0) onTogglePin(draftId, nextPinned);
            }}
            aria-label={isPinned ? 'Unpin note' : 'Pin note'}
            title={isPinned ? 'Unpin note' : 'Pin note'}
            className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
              isPinned
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15'
            }`}
          >
            <Pin className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleShareOrCopy}
            aria-label="Share or copy note"
            title="Share / Copy note"
            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            <UserPlus className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              const nextArchived = !isArchived;
              const nextPinned = nextArchived ? false : isPinned;
              setIsArchived(nextArchived);
              setIsPinned(nextPinned);
              if (saveTimerRef.current !== null) {
                window.clearTimeout(saveTimerRef.current);
                saveTimerRef.current = null;
              }
              const d = latestDraftRef.current;
              const hasChecklistContent =
                d.isChecklist && d.checklistItems.some((i) => i.text.trim().length > 0);
              const hasContent = Boolean(
                d.title.trim() ||
                  d.content.trim() ||
                  hasChecklistContent ||
                  d.attachments.length > 0
              );
              if (d.id > 0 || hasContent) {
                const saved = onSaveNoteRef.current({
                  id: d.id,
                  title: d.title,
                  content: d.content,
                  richContent: d.richContent,
                  fontSize: d.fontSize,
                  totalCalculation: d.total,
                  colorTag: d.colorTag,
                  backgroundId: d.backgroundId,
                  customBackgroundUrl: d.customBackgroundUrl,
                  isPinned: nextPinned,
                  isArchived: nextArchived,
                  isChecklist: d.isChecklist,
                  checklistItems: d.checklistItems,
                  attachments: d.attachments,
                  excludedCalcKeys: d.excludedCalcKeys,
                });
                onToggleArchive(saved.id, nextArchived);
              }
              isDiscardedRef.current = true;
              onBack();
            }}
            aria-label={isArchived ? 'Unarchive note' : 'Archive note'}
            title={isArchived ? 'Unarchive' : 'Archive'}
            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            {isArchived ? (
              <ArchiveRestore className="w-4 h-4" />
            ) : (
              <Archive className="w-4 h-4" />
            )}
          </button>
        </div>
      </header>

      {/* Main Writing & Media Canvas */}
      <div
        className="relative z-10 flex-1 overflow-y-auto px-5 sm:px-10 pt-2 pb-6"
        onClick={() => {
          if (activeSheet !== 'none') setActiveSheet('none');
        }}
      >
        <div className="w-full max-w-3xl mx-auto flex flex-col min-h-full">
          {/* Attached Images & Drawings */}
          {visualAttachments.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
              {visualAttachments.map((att) => (
                <div
                  key={att.id}
                  className="group relative rounded-xl overflow-hidden border border-black/10 dark:border-white/15 bg-white"
                >
                  <button
                    type="button"
                    onClick={() => setLightboxUrl(att.dataUrl)}
                    className="block w-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                  >
                    <img
                      src={att.dataUrl}
                      alt={att.name || 'Attachment'}
                      className="w-full h-36 object-cover"
                    />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setAttachments((prev) => prev.filter((a) => a.id !== att.id))
                    }
                    aria-label="Remove attachment"
                    className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-slate-950/70 text-white flex items-center justify-center opacity-85 hover:opacity-100"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Attached Audio Recordings */}
          {audioAttachments.length > 0 && (
            <div className="space-y-2 mb-4">
              {audioAttachments.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center gap-3 rounded-xl border border-black/10 dark:border-white/15 bg-white/75 dark:bg-slate-900/75 px-3 py-2"
                >
                  <Mic className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                  <audio controls src={att.dataUrl} className="flex-1 h-9" />
                  <button
                    type="button"
                    onClick={() =>
                      setAttachments((prev) => prev.filter((a) => a.id !== att.id))
                    }
                    aria-label="Delete recording"
                    className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Title */}
          <input
            ref={titleInputRef}
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title"
            aria-label="Title"
            className="w-full bg-transparent font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-slate-50 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none"
          />

          {/* Subtle Metadata */}
          <div className="mt-1.5 mb-4 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            <span>{updatedAt ? `Edited ${formatTimestamp(updatedAt)}` : 'New note'}</span>
            <span aria-hidden="true">·</span>
            <span>
              {words} {words === 1 ? 'word' : 'words'}
            </span>
          </div>

          {/* Body: Checklist OR Preview OR Live Rich Text Editor */}
          {isChecklist ? (
            <div className="space-y-2 pb-6">
              {checklistItems.map((item, idx) => {
                const itemDeltas = checklistExprEntries
                  .filter((e) => e.itemId === item.id)
                  .map((e) => ({
                    delta: formatPercentDelta(e.match),
                    isNegative: (e.match.percentDelta ?? 0) < 0,
                    endOffset:
                      (e.match.printedEndIndexInclusive ?? e.match.endIndexInclusive) + 1,
                    key: `${e.itemId}:${e.match.startIndex}`,
                  }))
                  .filter(
                    (
                      d
                    ): d is {
                      delta: string;
                      isNegative: boolean;
                      endOffset: number;
                      key: string;
                    } => d.delta !== null
                  );
                const inlineDelta =
                  itemDeltas.length === 1 &&
                  item.text.slice(itemDeltas[0].endOffset).trim().length === 0
                    ? itemDeltas[0]
                    : null;

                return (
                  <div key={item.id} className="flex items-center gap-2.5 group">
                    <button
                      type="button"
                      role="checkbox"
                      aria-checked={item.checked}
                      aria-label={item.checked ? 'Uncheck item' : 'Check item'}
                      onClick={() =>
                        setChecklistItems((prev) =>
                          prev.map((c) =>
                            c.id === item.id ? { ...c, checked: !c.checked } : c
                          )
                        )
                      }
                      className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors ${
                        item.checked
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-400 dark:border-slate-500 hover:border-indigo-500'
                      }`}
                    >
                      {item.checked && <Check className="w-3.5 h-3.5" />}
                    </button>
                    <div className="relative flex-1 min-w-0 flex items-center">
                      <input
                        ref={(el) => {
                          if (el) {
                            checklistInputRefs.current.set(item.id, el);
                          } else {
                            checklistInputRefs.current.delete(item.id);
                          }
                        }}
                        type="text"
                        value={item.text}
                        onChange={(e) => {
                          const inputEl = e.currentTarget;
                          const val = inputEl.value;
                          const selStart = inputEl.selectionStart;
                          const selEnd = inputEl.selectionEnd;
                          if (autoCalcEnabled) {
                            if (
                              selStart !== null &&
                              selStart === selEnd &&
                              selStart > 0 &&
                              val.length > item.text.length &&
                              val[selStart - 1] === '='
                            ) {
                              const eqIdx = selStart - 1;
                              const eqMatch = findExpressions(val).find(
                                (m) =>
                                  !m.isApplied &&
                                  m.printedEndIndexInclusive === undefined &&
                                  m.endIndexInclusive + 1 <= eqIdx &&
                                  /^[ \t]*$/.test(
                                    val.slice(m.endIndexInclusive + 1, eqIdx)
                                  )
                              );
                              if (eqMatch) {
                                const nextSuffix = ` = ${formatResult(eqMatch.result)}`;
                                const nextText =
                                  val.slice(0, eqMatch.endIndexInclusive + 1) +
                                  nextSuffix +
                                  val.slice(eqIdx + 1);
                                const nextCaret =
                                  eqMatch.endIndexInclusive + 1 + nextSuffix.length;
                                setChecklistItems((prev) =>
                                  prev.map((c) =>
                                    c.id === item.id ? { ...c, text: nextText } : c
                                  )
                                );
                                requestAnimationFrame(() => {
                                  if (document.activeElement === inputEl) {
                                    inputEl.setSelectionRange(nextCaret, nextCaret);
                                  }
                                });
                                return;
                              }
                            }

                            const auto = autoUpdatePrintedResultsInText(
                              val,
                              selStart,
                              selEnd
                            );
                            if (auto.changed) {
                              setChecklistItems((prev) =>
                                prev.map((c) =>
                                  c.id === item.id ? { ...c, text: auto.text } : c
                                )
                              );
                              if (selStart !== null && selEnd !== null) {
                                requestAnimationFrame(() => {
                                  if (document.activeElement === inputEl) {
                                    inputEl.setSelectionRange(selStart, selEnd);
                                  }
                                });
                              }
                              return;
                            }
                          }
                          setChecklistItems((prev) =>
                            prev.map((c) => (c.id === item.id ? { ...c, text: val } : c))
                          );
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const newItem: ChecklistItem = {
                              id: makeId('chk'),
                              text: '',
                              checked: false,
                            };
                            setChecklistItems((prev) => {
                              const copy = [...prev];
                              copy.splice(idx + 1, 0, newItem);
                              return copy;
                            });
                            focusChecklistItem(newItem.id);
                          } else if (e.key === 'Backspace' && item.text === '') {
                            e.preventDefault();
                            removeChecklistItem(item.id, true);
                          }
                        }}
                        placeholder="List item"
                        style={{ fontSize: `${fontSize}px` }}
                        className={`w-full min-w-0 bg-transparent py-1 focus:outline-none ${
                          inlineDelta ? 'pr-14' : ''
                        } ${
                          item.checked
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-800 dark:text-slate-100'
                        }`}
                      />
                      {inlineDelta && (
                        <div
                          aria-hidden="true"
                          style={{ fontSize: `${fontSize}px` }}
                          className="pointer-events-none select-none absolute inset-0 flex items-center py-1 overflow-hidden"
                        >
                          <span className="invisible whitespace-pre max-w-[calc(100%-3.5rem)] overflow-hidden">
                            {item.text.slice(0, inlineDelta.endOffset)}
                          </span>
                          <span
                            style={{
                              fontSize: `${Math.max(10, Math.min(20, Math.round(fontSize * 0.68)))}px`,
                            }}
                            className={`ml-1.5 font-mono font-semibold leading-none tabular-nums whitespace-nowrap shrink-0 ${
                              inlineDelta.isNegative
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-emerald-600 dark:text-emerald-400'
                            }`}
                          >
                            {inlineDelta.delta}
                          </span>
                        </div>
                      )}
                    </div>
                    {!inlineDelta && itemDeltas.length > 0 && (
                      <span
                        style={{
                          fontSize: `${Math.max(10, Math.min(20, Math.round(fontSize * 0.68)))}px`,
                        }}
                        className="flex items-center gap-1.5 shrink-0 font-mono font-semibold tabular-nums"
                      >
                        {itemDeltas.map((d) => (
                          <span
                            key={d.key}
                            className={
                              d.isNegative
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-emerald-600 dark:text-emerald-400'
                            }
                          >
                            {d.delta}
                          </span>
                        ))}
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => removeChecklistItem(item.id, true)}
                      aria-label="Remove item"
                      title="Remove item"
                      className="min-h-[32px] min-w-[32px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 opacity-60 group-hover:opacity-100"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}

              <button
                type="button"
                onClick={() => {
                  const newItem: ChecklistItem = {
                    id: makeId('chk'),
                    text: '',
                    checked: false,
                  };
                  setChecklistItems((prev) => [...prev, newItem]);
                  focusChecklistItem(newItem.id);
                }}
                className="mt-2 inline-flex items-center gap-2 min-h-[38px] px-2 py-1 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
              >
                <Plus className="w-4 h-4" />
                <span>List item</span>
              </button>
            </div>
          ) : previewMode ? (
            <div className="flex-1 pb-6">
              <MarkdownPreview
                text={content}
                richContent={richContent}
                fontSize={fontSize}
                matches={textMatches}
                onApplyMatch={handleApplyExpression}
              />
            </div>
          ) : (
            <div ref={editorContainerRef} className="relative flex-1 flex flex-col">
              {isEditorEmpty && (
                <span
                  aria-hidden="true"
                  style={{ fontSize: `${fontSize}px` }}
                  className="pointer-events-none absolute top-0 left-0 text-left leading-[1.72] text-slate-400 dark:text-slate-500 select-none"
                >
                  Note
                </span>
              )}
              <div
                ref={editorRef}
                contentEditable
                suppressContentEditableWarning
                role="textbox"
                aria-multiline="true"
                aria-label="Note"
                onInput={() => {
                  syncFromEditorDom(true, false);
                  refreshToolbarStateFromSelection();
                }}
                onKeyUp={refreshToolbarStateFromSelection}
                onMouseUp={refreshToolbarStateFromSelection}
                onKeyDown={handleEditorKeyDown}
                onPaste={handleEditorPaste}
                style={{ fontSize: `${fontSize}px` }}
                className="flex-1 w-full min-h-[260px] text-left leading-[1.72] text-slate-800 dark:text-slate-200 focus:outline-none break-words [&>div]:leading-[1.72] [&>div]:min-h-[1.72em] [&_span]:leading-[1.35] [&_span]:align-baseline [&_b]:font-bold [&_strong]:font-bold [&_b]:align-baseline [&_strong]:align-baseline [&_i]:italic [&_em]:italic [&_i]:align-baseline [&_em]:align-baseline [&_u]:underline [&_u]:decoration-from-font [&_u]:underline-offset-4 [&_u]:align-baseline [&_s]:line-through [&_s]:decoration-from-font [&_s]:align-baseline"
              />
              {percentAnnotations.length > 0 && (
                <div
                  aria-hidden="true"
                  className="pointer-events-none select-none absolute inset-0 overflow-visible z-10"
                >
                  {percentAnnotations.map((ann) => (
                    <span
                      key={ann.key}
                      style={{
                        left: `${ann.left}px`,
                        top: `${ann.top}px`,
                        fontSize: `${ann.fontSize}px`,
                        transform:
                          ann.placement === 'inline-right'
                            ? 'translateY(-50%)'
                            : ann.alignRight
                              ? 'translateX(-100%)'
                              : undefined,
                      }}
                      className={`absolute font-mono font-semibold leading-none tracking-tight tabular-nums whitespace-nowrap transition-[left,top,opacity] duration-150 ease-out ${
                        ann.isNegative
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {ann.text}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Live Math Chips & Sticky Total Bar */}
      <div className="relative z-20">
        <CalcChipRow matches={allMatches} onChipClick={handleApplyExpression} />
        <TotalBar
          total={total}
          count={allMatches.length}
          includedCount={activeMatches.length}
          onClick={() => setCalcModalOpen(true)}
        />
      </div>

      {/* Bottom Sheets (Add Menu, Colour/Background, More Menu) */}
      {activeSheet === 'add' && (
        <div
          className="animate-sheet-up relative z-30 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl rounded-t-2xl px-2 py-2"
          role="menu"
          aria-label="Add to note"
        >
          <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Camera className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            <span>Take photo</span>
          </button>
          <button
            type="button"
            onClick={() => imageInputRef.current?.click()}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <ImageIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            <span>Add image</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSheet('none');
              setAudioModalOpen(true);
            }}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Mic className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            <span>Recording</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSheet('none');
              setDrawingModalOpen(true);
            }}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Brush className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            <span>Drawing</span>
          </button>
          <button
            type="button"
            onClick={handleToggleChecklistMode}
            className="w-full flex items-center justify-between gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <span className="flex items-center gap-4">
              <CheckSquare className="w-5 h-5 text-slate-600 dark:text-slate-300" />
              <span>{isChecklist ? 'Remove tick boxes' : 'Tick boxes'}</span>
            </span>
            {isChecklist && (
              <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                Turn off
              </span>
            )}
          </button>
        </div>
      )}

      {activeSheet === 'palette' && (
        <div
          className="animate-sheet-up relative z-30 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl rounded-t-2xl px-5 py-4 space-y-4"
          role="dialog"
          aria-label="Colour and background"
        >
          {/* Colour Row */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                Colour
                <span className="ml-2 font-normal text-slate-500 dark:text-slate-400">
                  {colorOption.name}
                </span>
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-2.5 max-h-36 overflow-y-auto py-1">
              {NOTE_COLOR_PALETTE.map((opt) => {
                const selected = colorTag === opt.index;
                return (
                  <button
                    key={opt.index}
                    type="button"
                    onClick={() => setColorTag(opt.index)}
                    aria-label={`${opt.name} colour`}
                    title={opt.name}
                    className={`relative w-10 h-10 rounded-full shrink-0 flex items-center justify-center border transition-transform hover:scale-105 ${
                      opt.index === 0
                        ? 'border-slate-400 dark:border-slate-500 bg-slate-100 dark:bg-slate-800'
                        : 'border-black/15 dark:border-white/20'
                    } ${
                      selected
                        ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900'
                        : ''
                    }`}
                    style={opt.index === 0 ? undefined : { backgroundColor: opt.swatchHex }}
                  >
                    {opt.index === 0 && (
                      <Ban className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                    )}
                    {selected && (
                      <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs">
                        <Check className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Background Row */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                Background
                <span className="ml-2 font-normal text-slate-500 dark:text-slate-400">
                  {backgroundId === 'custom'
                    ? 'Custom photo'
                    : NOTE_BACKGROUNDS.find((b) => b.id === backgroundId)?.name ?? 'None'}
                </span>
              </h3>
              {customBackgroundUrl && (
                <button
                  type="button"
                  onClick={() => {
                    setCustomBackgroundUrl(undefined);
                    if (backgroundId === 'custom') setBackgroundId('none');
                  }}
                  className="text-xs font-medium text-rose-600 dark:text-rose-400 hover:underline"
                >
                  Remove photo
                </button>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2.5 max-h-40 overflow-y-auto py-1">
              {NOTE_BACKGROUNDS.map((bg) => {
                const selected = backgroundId === bg.id;
                return (
                  <button
                    key={bg.id}
                    type="button"
                    onClick={() => setBackgroundId(bg.id)}
                    aria-label={bg.name}
                    title={bg.name}
                    className={`relative w-11 h-11 rounded-full shrink-0 overflow-hidden flex items-center justify-center border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 transition-transform hover:scale-105 ${
                      selected
                        ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900'
                        : ''
                    }`}
                  >
                    {bg.id === 'none' ? (
                      <ImageOff className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                    ) : (
                      <NoteBackgroundArt backgroundId={bg.id} variant="swatch" />
                    )}
                    {selected && (
                      <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs z-10">
                        <Check className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </button>
                );
              })}

              {/* Saved Custom Photo Swatch */}
              {customBackgroundUrl && (
                <button
                  type="button"
                  onClick={() => setBackgroundId('custom')}
                  aria-label="Custom background photo"
                  title="Custom photo"
                  className={`relative w-11 h-11 rounded-full shrink-0 overflow-hidden flex items-center justify-center border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 transition-transform hover:scale-105 ${
                    backgroundId === 'custom'
                      ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900'
                      : ''
                  }`}
                >
                  <NoteBackgroundArt
                    backgroundId="custom"
                    customBackgroundUrl={customBackgroundUrl}
                    variant="swatch"
                  />
                  {backgroundId === 'custom' && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs z-10">
                      <Check className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              )}

              {/* Upload Your Own Background Button */}
              <button
                type="button"
                onClick={() => customBgInputRef.current?.click()}
                aria-label="Choose custom background image"
                title="Choose your own background image"
                className="relative w-11 h-11 rounded-full shrink-0 flex items-center justify-center border-2 border-dashed border-indigo-400 dark:border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-transform hover:scale-105"
              >
                <ImagePlus className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {activeSheet === 'more' && (
        <div
          className="animate-sheet-up relative z-30 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl rounded-t-2xl px-2 py-2"
          role="menu"
          aria-label="More note options"
        >
          <button
            type="button"
            onClick={handleToggleChecklistMode}
            className="w-full flex items-center justify-between gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <span className="flex items-center gap-4">
              <CheckSquare className="w-5 h-5 text-slate-600 dark:text-slate-300" />
              <span>{isChecklist ? 'Remove tick boxes' : 'Tick boxes'}</span>
            </span>
            {isChecklist && (
              <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                Turn off
              </span>
            )}
          </button>
          {!isChecklist && (
            <button
              type="button"
              onClick={() => {
                setPreviewMode((p) => !p);
                setActiveSheet('none');
              }}
              className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {previewMode ? (
                <>
                  <PenLine className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  <span>Edit note</span>
                </>
              ) : (
                <>
                  <Eye className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  <span>Preview note</span>
                </>
              )}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setActiveSheet('none');
              if (draftId > 0) {
                onDuplicateNote(draftId);
                showToast('Copied note');
              } else {
                const saved = onSaveNote({
                  id: 0,
                  title,
                  content,
                  richContent,
                  fontSize,
                  totalCalculation: total,
                  colorTag,
                  backgroundId,
                  customBackgroundUrl,
                  isPinned,
                  isArchived,
                  isChecklist,
                  checklistItems,
                  attachments,
                  excludedCalcKeys,
                });
                lastSavedKeyRef.current = JSON.stringify({
                  id: saved.id,
                  title: saved.title,
                  content: saved.content,
                  richContent: saved.richContent ?? '',
                  fontSize: sanitizeFontSize(saved.fontSize),
                  colorTag: saved.colorTag,
                  backgroundId: sanitizeBackground(saved.backgroundId),
                  customBackgroundUrl:
                    sanitizeCustomBackgroundUrl(saved.customBackgroundUrl) ?? null,
                  isPinned: saved.isPinned,
                  isArchived: Boolean(saved.isArchived),
                  isChecklist: Boolean(saved.isChecklist),
                  checklistItems: saved.checklistItems ?? [],
                  attachments: saved.attachments ?? [],
                  excludedCalcKeys: sanitizeExcludedCalcKeys(saved.excludedCalcKeys),
                  total: saved.totalCalculation,
                });
                setDraftId(saved.id);
                setUpdatedAt(saved.updatedAt);
                onDuplicateNote(saved.id);
                showToast('Copied note');
              }
            }}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <CopyPlus className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            <span>Make a copy</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveSheet('none');
              isDiscardedRef.current = true;
              if (saveTimerRef.current !== null) {
                window.clearTimeout(saveTimerRef.current);
                saveTimerRef.current = null;
              }
              onMoveToTrash(draftId);
            }}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
          >
            <Trash2 className="w-5 h-5" />
            <span>Delete</span>
          </button>
        </div>
      )}

      {/* Bottom Toolbar: Formatting Bar + Action Row */}
      <footer className="relative z-30 border-t border-black/10 dark:border-white/10 bg-white/90 dark:bg-slate-900/95 backdrop-blur-md">
        {formatBarOpen && !isChecklist && !previewMode && (
          <div
            role="toolbar"
            aria-label="Text formatting"
            className="animate-sheet-up flex flex-col md:flex-row md:items-center md:justify-between gap-2 px-3 sm:px-5 py-2 border-b border-black/8 dark:border-white/10"
          >
            {/* Horizontal Font Size Slider + Default Reset */}
            <div className="flex items-center gap-2.5 flex-1 min-w-0">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 shrink-0 select-none">
                A
              </span>
              <input
                type="range"
                min={MIN_NOTE_FONT_SIZE}
                max={MAX_NOTE_FONT_SIZE}
                step={1}
                value={sliderFontSize}
                onPointerDown={beginSliderSession}
                onPointerUp={() => endSliderSession(true)}
                onBlur={() => endSliderSession(false)}
                onChange={(e) => handleFontSizeSliderChange(Number(e.target.value))}
                aria-label="Font size"
                title={`Font size: ${sliderFontSize}px`}
                className="flex-1 min-w-[110px] md:max-w-[200px] h-2 rounded-lg appearance-none cursor-pointer bg-slate-200 dark:bg-slate-700 accent-indigo-600 dark:accent-indigo-400"
              />
              <span className="text-sm font-semibold text-slate-600 dark:text-slate-300 shrink-0 select-none">
                A
              </span>
              <span className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300 w-9 text-right shrink-0">
                {sliderFontSize}px
              </span>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleResetDefaultFontSize}
                aria-label="Default font size"
                title={`Reset to default font size (${DEFAULT_NOTE_FONT_SIZE}px)`}
                className={`min-h-[36px] min-w-[38px] px-2.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
                  sliderFontSize === DEFAULT_NOTE_FONT_SIZE &&
                  fontSize === DEFAULT_NOTE_FONT_SIZE
                    ? 'bg-indigo-600 text-white'
                    : 'bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15'
                }`}
              >
                Aa
              </button>
            </div>

            <span
              className="hidden md:block h-5 w-px bg-slate-300 dark:bg-slate-700 mx-1 shrink-0"
              aria-hidden="true"
            />

            {/* Style Buttons: Bold, Italic, Underline, Strikethrough, Clear Formatting */}
            <div className="flex items-center justify-between md:justify-end gap-1">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => applyRichCommand('bold')}
                  aria-label="Bold"
                  aria-pressed={activeFormats.bold}
                  title="Bold (Ctrl+B)"
                  className={`min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg transition-colors ${
                    activeFormats.bold
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10'
                  }`}
                >
                  <Bold className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => applyRichCommand('italic')}
                  aria-label="Italic"
                  aria-pressed={activeFormats.italic}
                  title="Italic (Ctrl+I)"
                  className={`min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg transition-colors ${
                    activeFormats.italic
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10'
                  }`}
                >
                  <Italic className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => applyRichCommand('underline')}
                  aria-label="Underline"
                  aria-pressed={activeFormats.underline}
                  title="Underline (Ctrl+U)"
                  className={`min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg transition-colors ${
                    activeFormats.underline
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10'
                  }`}
                >
                  <Underline className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => applyRichCommand('strikeThrough')}
                  aria-label="Strikethrough"
                  aria-pressed={activeFormats.strike}
                  title="Strikethrough (Ctrl+Shift+X)"
                  className={`min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg transition-colors ${
                    activeFormats.strike
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10'
                  }`}
                >
                  <Strikethrough className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleClearFormatting}
                  aria-label="Clear formatting"
                  title="Clear formatting"
                  className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
                >
                  <RemoveFormatting className="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                onClick={() => setFormatBarOpen(false)}
                aria-label="Hide formatting bar"
                title="Hide formatting bar"
                className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg text-slate-500 dark:text-slate-400 hover:bg-black/5 dark:hover:bg-white/10 shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Bottom Action Row: [+] [Palette] [A̲] on left, [⋮] on right */}
        <div className="flex items-center justify-between gap-2 px-3 sm:px-5 py-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                setActiveSheet((s) => (s === 'add' ? 'none' : 'add'))
              }
              aria-label="Add attachment or checklist"
              title="Add"
              className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl transition-colors ${
                activeSheet === 'add'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15'
              }`}
            >
              <PlusSquare className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveSheet((s) => (s === 'palette' ? 'none' : 'palette'))
              }
              aria-label="Colour and background"
              title="Colour and background"
              className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl transition-colors ${
                activeSheet === 'palette'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15'
              }`}
            >
              <Palette className="w-4 h-4" />
            </button>

            {!isChecklist && (
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setActiveSheet('none');
                  setPreviewMode(false);
                  setFormatBarOpen((open) => !open);
                }}
                aria-label="Toggle text formatting toolbar"
                aria-pressed={formatBarOpen && !previewMode}
                title="Formatting"
                className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl transition-colors ${
                  formatBarOpen && !previewMode
                    ? 'bg-indigo-600 text-white'
                    : 'bg-black/5 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-black/10 dark:hover:bg-white/15'
                }`}
              >
                <Baseline className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={() =>
              setActiveSheet((s) => (s === 'more' ? 'none' : 'more'))
            }
            aria-label="More options"
            title="More options"
            className={`min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl transition-colors ${
              activeSheet === 'more'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-700 dark:text-slate-200 hover:bg-black/5 dark:hover:bg-white/10'
            }`}
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </footer>

      {/* Hidden File Inputs for Take Photo & Add Image */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFilesSelected}
        className="hidden"
      />
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFilesSelected}
        className="hidden"
      />
      <input
        ref={customBgInputRef}
        type="file"
        accept="image/*"
        onChange={handleCustomBackgroundSelected}
        className="hidden"
      />

      {/* Modals */}
      {drawingModalOpen && (
        <DrawingCanvasModal
          onSave={(dataUrl) => {
            setAttachments((prev) => [
              ...prev,
              {
                id: makeId('draw'),
                type: 'drawing',
                dataUrl,
                name: 'Drawing',
                createdAt: Date.now(),
              },
            ]);
            setDrawingModalOpen(false);
          }}
          onClose={() => setDrawingModalOpen(false)}
        />
      )}

      {audioModalOpen && (
        <AudioRecorderModal
          onSave={(dataUrl, durationSec) => {
            setAttachments((prev) => [
              ...prev,
              {
                id: makeId('aud'),
                type: 'audio',
                dataUrl,
                durationSec,
                createdAt: Date.now(),
              },
            ]);
            setAudioModalOpen(false);
          }}
          onClose={() => setAudioModalOpen(false)}
        />
      )}

      {calcModalOpen && (
        <CalculationsModal
          noteTitle={title}
          matches={allMatches}
          matchKeys={matchKeys}
          excludedKeys={excludedCalcKeys}
          total={total}
          onToggleExclude={(key) =>
            setExcludedCalcKeys((prev) =>
              prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
            )
          }
          onReplace={handleApplyExpression}
          onClose={() => setCalcModalOpen(false)}
        />
      )}

      {lightboxUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4"
          onClick={() => setLightboxUrl(null)}
        >
          <img
            src={lightboxUrl}
            alt="Full preview"
            className="max-w-full max-h-[88vh] rounded-xl shadow-2xl bg-white"
          />
        </div>
      )}

      {statusToast && (
        <div
          role="status"
          className="fixed bottom-16 left-1/2 -translate-x-1/2 z-50 rounded-xl bg-slate-900 text-white px-4 py-2 text-xs font-medium shadow-lg"
        >
          {statusToast}
        </div>
      )}
    </div>
  );
}
