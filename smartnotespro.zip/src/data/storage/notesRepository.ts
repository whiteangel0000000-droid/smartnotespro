import {
  isNoteBlank,
  Note,
  NoteBackgroundId,
  NotePriority,
  sanitizeBackground,
  sanitizeColor,
  sanitizeCustomBackgroundUrl,
  sanitizeExcludedCalcKeys,
  sanitizeFontSize,
  sanitizeLabels,
  sanitizePriority,
  sanitizeReminderAt,
  sanitizeStickyCurve,
  sanitizeStickyType,
  StickyCurveStyle,
  StickyNoteType,
} from '../../domain/model/note';
import {
  ExpressionMatch,
  findExpressions,
  getMatchKeys,
  totalOfMatches,
} from '../../utils/mathEvaluator';
import { SortOrder } from '../preferences/settings';

const NOTES_STORAGE_KEY = 'smartnotespro.notes.v1';
const NEXT_ID_STORAGE_KEY = 'smartnotespro.next_id.v1';
const INIT_FLAG_KEY = 'smartnotespro.initialized.v1';

export const TRASH_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;

export function computeNoteTotal(
  note: Pick<Note, 'content' | 'isChecklist' | 'checklistItems' | 'excludedCalcKeys'>
): number {
  const excludedSet = new Set(sanitizeExcludedCalcKeys(note.excludedCalcKeys));
  if (note.isChecklist && note.checklistItems) {
    const entries: Array<{ itemId: string; match: ExpressionMatch }> = [];
    for (const item of note.checklistItems) {
      for (const m of findExpressions(item.text)) {
        entries.push({ itemId: item.id, match: m });
      }
    }
    const matches = entries.map((e) => e.match);
    const keys = getMatchKeys(
      matches,
      entries.map((e) => e.itemId)
    );
    return totalOfMatches(matches.filter((_, idx) => !excludedSet.has(keys[idx])));
  }
  const matches = findExpressions(note.content);
  const keys = getMatchKeys(matches);
  return totalOfMatches(matches.filter((_, idx) => !excludedSet.has(keys[idx])));
}

function buildStarterNotes(now: number): Note[] {
  const starters: Array<Omit<Note, 'id' | 'totalCalculation'>> = [
    {
      title: 'Monthly Budget & Groceries',
      content:
        'Rent & Utilities: 1450+185\nWeekly Groceries: 84.50+62.30\nCoffee & Pantry: 4*12.50\nDiscount Coupon: 200-15%\n\n**Tip:** Tap any calculation chip below to print the full equation (e.g. 2+2 = 4).',
      colorTag: 6,
      backgroundId: 'none',
      isPinned: true,
      isArchived: false,
      isChecklist: false,
      checklistItems: [],
      attachments: [],
      createdAt: now - 3_600_000 * 6,
      updatedAt: now - 3_600_000 * 2,
      reminderAt: null,
      isDeleted: false,
      deletedAt: null,
    },
    {
      title: 'Shopping Checklist',
      content: '',
      colorTag: 4,
      backgroundId: 'culinary',
      isPinned: false,
      isArchived: false,
      isChecklist: true,
      checklistItems: [
        { id: 'c1', text: 'Milk 2*3.5', checked: false },
        { id: 'c2', text: 'Bread 4+2', checked: true },
        { id: 'c3', text: 'Coffee beans 18-20%', checked: false },
      ],
      attachments: [],
      createdAt: now - 86_400_000,
      updatedAt: now - 3_600_000 * 8,
      reminderAt: now + 3_600_000 * 3,
      isStickyWidget: true,
      stickyCurve: 'peel',
      stickyType: 'checklist',
      priority: 'focus',
      isDeleted: false,
      deletedAt: null,
    },
    {
      title: 'Weekend Trip Cost Split',
      content:
        'Cabin booking: 3*140\nFuel & tolls: 65+18.5\nDinner split (3 people): (126+24)/3\nGear rental: 2x45\n\n*Everything updates automatically as you type.*',
      colorTag: 5,
      backgroundId: 'beach',
      isPinned: false,
      isArchived: false,
      isChecklist: false,
      checklistItems: [],
      attachments: [],
      createdAt: now - 86_400_000 * 2,
      updatedAt: now - 3_600_000 * 12,
      reminderAt: null,
      isDeleted: false,
      deletedAt: null,
    },
    {
      title: 'Formatting & Formula Reference',
      content:
        '# Quick Heading\nUse **bold**, *italic*, or __underline__ directly in your notes.\n\nSupported expressions:\n- Precedence & powers: 2^3^2 or (12+8)*1.5\n- Percentages: 200+10% or 500-20%\n- Multiply with x or ×: 3x24 or 1,200+450\n\nPhone numbers like 555-1234 and dates like 2026-11-22 are ignored automatically.',
      colorTag: 3,
      backgroundId: 'none',
      isPinned: false,
      isArchived: false,
      isChecklist: false,
      checklistItems: [],
      attachments: [],
      createdAt: now - 86_400_000 * 3,
      updatedAt: now - 86_400_000,
      reminderAt: null,
      isDeleted: false,
      deletedAt: null,
    },
  ];

  return starters.map((item, idx) => ({
    ...item,
    id: idx + 1,
    totalCalculation: computeNoteTotal(item),
  }));
}

function normalizeLoadedNote(raw: Note): Note {
  return {
    ...raw,
    richContent: typeof raw.richContent === 'string' ? raw.richContent : undefined,
    fontSize: sanitizeFontSize(raw.fontSize),
    colorTag: sanitizeColor(raw.colorTag ?? 0),
    backgroundId: sanitizeBackground(raw.backgroundId),
    customBackgroundUrl: sanitizeCustomBackgroundUrl(raw.customBackgroundUrl),
    labels: sanitizeLabels(raw.labels),
    reminderAt: sanitizeReminderAt(raw.reminderAt),
    isArchived: Boolean(raw.isArchived),
    isChecklist: Boolean(raw.isChecklist),
    checklistItems: Array.isArray(raw.checklistItems) ? raw.checklistItems : [],
    attachments: Array.isArray(raw.attachments) ? raw.attachments : [],
    excludedCalcKeys: sanitizeExcludedCalcKeys(raw.excludedCalcKeys),
    isStickyWidget: Boolean(raw.isStickyWidget),
    stickyCurve: sanitizeStickyCurve(raw.stickyCurve),
    stickyType: sanitizeStickyType(raw.stickyType),
    priority: sanitizePriority(raw.priority),
  };
}

function readRawNotes(): Note[] {
  try {
    const initialized = localStorage.getItem(INIT_FLAG_KEY);
    const raw = localStorage.getItem(NOTES_STORAGE_KEY);
    if (!initialized && !raw) {
      const now = Date.now();
      const starters = buildStarterNotes(now);
      writeRawNotes(starters);
      localStorage.setItem(NEXT_ID_STORAGE_KEY, String(starters.length + 1));
      localStorage.setItem(INIT_FLAG_KEY, '1');
      return starters;
    }
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((n: Note) => normalizeLoadedNote(n));
  } catch {
    return [];
  }
}

function writeRawNotes(notes: Note[]): void {
  try {
    localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes));
    localStorage.setItem(INIT_FLAG_KEY, '1');
  } catch {
    // Ignore storage quota / private mode failures
  }
}

function allocateId(existing: Note[]): number {
  const maxId = existing.reduce((max, n) => Math.max(max, n.id), 0);
  try {
    const storedNext = Number(localStorage.getItem(NEXT_ID_STORAGE_KEY) || '1');
    const next = Math.max(maxId + 1, Number.isFinite(storedNext) ? storedNext : 1);
    localStorage.setItem(NEXT_ID_STORAGE_KEY, String(next + 1));
    return next;
  } catch {
    return maxId + 1;
  }
}

export function purgeExpiredTrash(notes: Note[], now = Date.now()): Note[] {
  const cutoff = now - TRASH_RETENTION_MS;
  const filtered = notes.filter(
    (n) => !(n.isDeleted && n.deletedAt !== null && n.deletedAt < cutoff)
  );
  if (filtered.length !== notes.length) {
    writeRawNotes(filtered);
  }
  return filtered;
}

export function loadAllNotesWithPurge(): Note[] {
  return purgeExpiredTrash(readRawNotes());
}

export function saveNoteRecord(note: Note): { notes: Note[]; saved: Note } {
  const now = Date.now();
  const current = readRawNotes();
  const existing = note.id > 0 ? current.find((n) => n.id === note.id) : undefined;

  if (!existing) {
    const created: Note = {
      ...normalizeLoadedNote(note),
      id: allocateId(current),
      createdAt: now,
      updatedAt: now,
      isDeleted: false,
      deletedAt: null,
    };
    const next = [created, ...current];
    writeRawNotes(next);
    return { notes: next, saved: created };
  }

  const updated: Note = {
    ...normalizeLoadedNote(note),
    createdAt: existing.createdAt,
    updatedAt: now,
  };
  const next = current.map((n) => (n.id === updated.id ? updated : n));
  writeRawNotes(next);
  return { notes: next, saved: updated };
}

export function duplicateNoteRecord(id: number): { notes: Note[]; copy: Note | null } {
  const now = Date.now();
  const current = readRawNotes();
  const source = current.find((n) => n.id === id);
  if (!source) return { notes: current, copy: null };
  const copy: Note = {
    ...normalizeLoadedNote(source),
    id: allocateId(current),
    title: source.title ? `${source.title} (Copy)` : 'Copy',
    isPinned: false,
    createdAt: now,
    updatedAt: now,
    isDeleted: false,
    deletedAt: null,
  };
  const next = [copy, ...current];
  writeRawNotes(next);
  return { notes: next, copy };
}

export function setNotePinnedRecord(id: number, pinned: boolean): Note[] {
  const current = readRawNotes();
  const next = current.map((n) => (n.id === id ? { ...n, isPinned: pinned } : n));
  writeRawNotes(next);
  return next;
}

export function setNotesPinnedRecord(ids: readonly number[], pinned: boolean): Note[] {
  const idSet = new Set(ids);
  const current = readRawNotes();
  const next = current.map((n) => (idSet.has(n.id) ? { ...n, isPinned: pinned } : n));
  writeRawNotes(next);
  return next;
}

export function setNoteReminderRecord(id: number, reminderAt: number | null): Note[] {
  const current = readRawNotes();
  const next = current.map((n) => (n.id === id ? { ...n, reminderAt } : n));
  writeRawNotes(next);
  return next;
}

export function setNotePriorityRecord(id: number, priority: NotePriority): Note[] {
  const safePriority = sanitizePriority(priority);
  const current = readRawNotes();
  const next = current.map((n) => (n.id === id ? { ...n, priority: safePriority } : n));
  writeRawNotes(next);
  return next;
}

export function setNoteStickyWidgetRecord(
  id: number,
  config: {
    isStickyWidget: boolean;
    colorTag?: number;
    stickyCurve?: StickyCurveStyle;
    stickyType?: StickyNoteType;
    reminderAt?: number | null;
    priority?: NotePriority;
  }
): Note[] {
  const current = readRawNotes();
  const next = current.map((n) => {
    if (n.id !== id) return n;
    return {
      ...n,
      isStickyWidget: config.isStickyWidget,
      ...(config.colorTag !== undefined ? { colorTag: sanitizeColor(config.colorTag) } : {}),
      ...(config.stickyCurve !== undefined
        ? { stickyCurve: sanitizeStickyCurve(config.stickyCurve) }
        : {}),
      ...(config.stickyType !== undefined
        ? {
            stickyType: sanitizeStickyType(config.stickyType),
            isChecklist: config.stickyType === 'checklist' ? true : n.isChecklist,
          }
        : {}),
      ...(config.reminderAt !== undefined ? { reminderAt: config.reminderAt } : {}),
      ...(config.priority !== undefined
        ? { priority: sanitizePriority(config.priority) }
        : {}),
    };
  });
  writeRawNotes(next);
  return next;
}

export function toggleChecklistItemRecord(noteId: number, itemId: string): Note[] {
  const now = Date.now();
  const current = readRawNotes();
  const next = current.map((n) => {
    if (n.id !== noteId) return n;
    const items = (n.checklistItems ?? []).map((item) =>
      item.id === itemId ? { ...item, checked: !item.checked } : item
    );
    return { ...n, checklistItems: items, updatedAt: now };
  });
  writeRawNotes(next);
  return next;
}

export function appendChecklistItemRecord(noteId: number, text: string): Note[] {
  const trimmed = text.trim();
  if (!trimmed) return readRawNotes();
  const now = Date.now();
  const current = readRawNotes();
  const next = current.map((n) => {
    if (n.id !== noteId) return n;
    const items = [
      ...(n.checklistItems ?? []),
      { id: `chk-${now}-${Math.random().toString(36).slice(2, 6)}`, text: trimmed, checked: false },
    ];
    const updated: Note = {
      ...n,
      isChecklist: true,
      checklistItems: items,
      updatedAt: now,
    };
    return { ...updated, totalCalculation: computeNoteTotal(updated) };
  });
  writeRawNotes(next);
  return next;
}

export function updateStickyTextRecord(noteId: number, text: string): Note[] {
  const now = Date.now();
  const current = readRawNotes();
  const next = current.map((n) => {
    if (n.id !== noteId) return n;
    const updated: Note = {
      ...n,
      content: text,
      richContent: undefined,
      updatedAt: now,
    };
    return { ...updated, totalCalculation: computeNoteTotal(updated) };
  });
  writeRawNotes(next);
  return next;
}

export function setNotesColorRecord(ids: readonly number[], colorTag: number): Note[] {
  const idSet = new Set(ids);
  const safeColor = sanitizeColor(colorTag);
  const current = readRawNotes();
  const next = current.map((n) => (idSet.has(n.id) ? { ...n, colorTag: safeColor } : n));
  writeRawNotes(next);
  return next;
}

export function setNotesBackgroundRecord(
  ids: readonly number[],
  backgroundId: NoteBackgroundId,
  customBackgroundUrl?: string
): Note[] {
  const idSet = new Set(ids);
  const safeBg = sanitizeBackground(backgroundId);
  const current = readRawNotes();
  const next = current.map((n) =>
    idSet.has(n.id)
      ? {
          ...n,
          backgroundId: safeBg,
          ...(customBackgroundUrl !== undefined ? { customBackgroundUrl } : {}),
        }
      : n
  );
  writeRawNotes(next);
  return next;
}

export function setNotesLabelRecord(
  ids: readonly number[],
  label: string,
  assign: boolean
): Note[] {
  const trimmed = label.trim();
  if (!trimmed) return readRawNotes();
  const idSet = new Set(ids);
  const current = readRawNotes();
  const next = current.map((n) => {
    if (!idSet.has(n.id)) return n;
    const existing = sanitizeLabels(n.labels);
    const key = trimmed.toLowerCase();
    const updated = assign
      ? existing.some((l) => l.toLowerCase() === key)
        ? existing
        : [...existing, trimmed]
      : existing.filter((l) => l.toLowerCase() !== key);
    return { ...n, labels: updated };
  });
  writeRawNotes(next);
  return next;
}

export function renameNotesLabelRecord(oldLabel: string, newLabel: string): Note[] {
  const oldTrimmed = oldLabel.trim();
  const newTrimmed = newLabel.trim();
  if (!oldTrimmed || !newTrimmed) return readRawNotes();
  const oldKey = oldTrimmed.toLowerCase();
  const current = readRawNotes();
  let changed = false;
  const next = current.map((n) => {
    const existing = sanitizeLabels(n.labels);
    if (!existing.some((l) => l.toLowerCase() === oldKey)) return n;
    changed = true;
    const replaced = existing.map((l) =>
      l.toLowerCase() === oldKey ? newTrimmed : l
    );
    return { ...n, labels: sanitizeLabels(replaced) };
  });
  if (changed) writeRawNotes(next);
  return next;
}

export function deleteNotesLabelRecord(label: string): Note[] {
  const trimmed = label.trim();
  if (!trimmed) return readRawNotes();
  const key = trimmed.toLowerCase();
  const current = readRawNotes();
  let changed = false;
  const next = current.map((n) => {
    const existing = sanitizeLabels(n.labels);
    const filtered = existing.filter((l) => l.toLowerCase() !== key);
    if (filtered.length === existing.length) return n;
    changed = true;
    return { ...n, labels: filtered };
  });
  if (changed) writeRawNotes(next);
  return next;
}

export function setNoteArchivedRecord(id: number, archived: boolean): Note[] {
  return setNotesArchivedRecord([id], archived);
}

export function setNotesArchivedRecord(ids: readonly number[], archived: boolean): Note[] {
  const idSet = new Set(ids);
  const current = readRawNotes();
  const next = current.map((n) =>
    idSet.has(n.id)
      ? { ...n, isArchived: archived, isPinned: archived ? false : n.isPinned }
      : n
  );
  writeRawNotes(next);
  return next;
}

export function moveNoteToTrashRecord(id: number): Note[] {
  return moveNotesToTrashRecord([id]);
}

export function moveNotesToTrashRecord(ids: readonly number[]): Note[] {
  const idSet = new Set(ids);
  const now = Date.now();
  const current = readRawNotes();
  const next = current.map((n) =>
    idSet.has(n.id) ? { ...n, isDeleted: true, deletedAt: now, isPinned: false } : n
  );
  writeRawNotes(next);
  return next;
}

export function duplicateNotesRecord(ids: readonly number[]): Note[] {
  const now = Date.now();
  const current = readRawNotes();
  let running = [...current];
  for (const id of ids) {
    const source = running.find((n) => n.id === id);
    if (!source) continue;
    const copy: Note = {
      ...normalizeLoadedNote(source),
      id: allocateId(running),
      title: source.title ? `${source.title} (Copy)` : 'Copy',
      isPinned: false,
      createdAt: now,
      updatedAt: now,
      isDeleted: false,
      deletedAt: null,
    };
    running = [copy, ...running];
  }
  writeRawNotes(running);
  return running;
}

export function restoreNoteFromTrashRecord(id: number): Note[] {
  return restoreNotesFromTrashRecord([id]);
}

export function restoreNotesFromTrashRecord(ids: readonly number[]): Note[] {
  const idSet = new Set(ids);
  const current = readRawNotes();
  const next = current.map((n) =>
    idSet.has(n.id) ? { ...n, isDeleted: false, deletedAt: null } : n
  );
  writeRawNotes(next);
  return next;
}

export function deleteNotePermanentlyRecord(id: number): Note[] {
  const current = readRawNotes();
  const next = current.filter((n) => n.id !== id);
  writeRawNotes(next);
  return next;
}

export function emptyTrashRecord(): Note[] {
  const current = readRawNotes();
  const next = current.filter((n) => !n.isDeleted);
  writeRawNotes(next);
  return next;
}

export function importNotesRecords(imported: Note[]): { notes: Note[]; addedCount: number } {
  const now = Date.now();
  const current = readRawNotes();
  const valid = imported.filter((n) => !isNoteBlank(n));
  if (valid.length === 0) return { notes: current, addedCount: 0 };

  const newRows: Note[] = [];
  let running = [...current];
  for (const item of valid) {
    const normalized = normalizeLoadedNote(item);
    const row: Note = {
      ...normalized,
      id: allocateId(running),
      totalCalculation: computeNoteTotal(normalized),
      createdAt: item.createdAt > 0 ? item.createdAt : now,
      updatedAt: item.updatedAt > 0 ? item.updatedAt : now,
      isDeleted: false,
      deletedAt: null,
    };
    newRows.push(row);
    running = [row, ...running];
  }
  writeRawNotes(running);
  return { notes: running, addedCount: newRows.length };
}

export function deleteAllNotesRecord(): Note[] {
  writeRawNotes([]);
  return [];
}

export function sortNotes(notes: readonly Note[], order: SortOrder): Note[] {
  const copy = [...notes];
  copy.sort((a, b) => {
    if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
    switch (order) {
      case 'modified':
        return b.updatedAt - a.updatedAt;
      case 'created':
        return b.createdAt - a.createdAt;
      case 'az': {
        const aBlank = a.title.trim().length === 0;
        const bBlank = b.title.trim().length === 0;
        if (aBlank !== bBlank) return aBlank ? 1 : -1;
        const cmp = a.title.localeCompare(b.title, undefined, { sensitivity: 'base' });
        return cmp !== 0 ? cmp : b.updatedAt - a.updatedAt;
      }
      case 'highest_total': {
        if (b.totalCalculation !== a.totalCalculation) {
          return b.totalCalculation - a.totalCalculation;
        }
        return b.updatedAt - a.updatedAt;
      }
    }
  });
  return copy;
}
