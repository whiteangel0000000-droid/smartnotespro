import { useEffect, useRef, useState } from 'react';

interface TooltipState {
  id: number;
  label: string;
  x: number;
  y: number;
  placeBelow: boolean;
  visible: boolean;
}

const LONG_PRESS_MS = 380;
const MOVE_THRESHOLD_PX = 8;
const RELEASE_LINGER_MS = 850;

function extractOptionLabel(el: HTMLElement): string | null {
  const raw =
    el.getAttribute('data-tooltip') ||
    el.getAttribute('aria-label') ||
    el.getAttribute('title') ||
    '';
  const cleaned = raw.replace(/\s*\((?:Ctrl|Cmd)[^)]+\)/gi, '').trim();
  if (cleaned.length > 0 && cleaned.length <= 60) {
    return cleaned;
  }
  const text = (el.textContent ?? '').replace(/\s+/g, ' ').trim();
  if (text.length > 0 && text.length <= 36) {
    return text;
  }
  return null;
}

function findTooltipTarget(rawTarget: EventTarget | null): HTMLElement | null {
  if (!(rawTarget instanceof Element)) return null;
  const candidate = rawTarget.closest(
    'button, [role="menuitem"], [data-tooltip]'
  ) as HTMLElement | null;
  if (!candidate) return null;
  if (
    candidate.hasAttribute('disabled') ||
    candidate.getAttribute('aria-disabled') === 'true' ||
    candidate.getAttribute('data-no-tooltip') === 'true' ||
    candidate.getAttribute('role') === 'checkbox'
  ) {
    return null;
  }
  if (candidate.closest('[data-no-tooltip="true"]')) return null;
  return candidate;
}

export function LongPressTooltipLayer() {
  const [tooltip, setTooltip] = useState<TooltipState | null>(null);
  const hasTooltipRef = useRef(false);
  hasTooltipRef.current = tooltip !== null;

  const timerRef = useRef<number | null>(null);
  const lingerTimerRef = useRef<number | null>(null);
  const activeTargetRef = useRef<HTMLElement | null>(null);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const triggeredForTargetRef = useRef<HTMLElement | null>(null);
  const suppressUntilRef = useRef<number>(0);
  const seqRef = useRef(0);

  useEffect(() => {
    const clearPressTimer = () => {
      if (timerRef.current !== null) {
        window.clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      startPosRef.current = null;
    };

    const clearLingerTimer = () => {
      if (lingerTimerRef.current !== null) {
        window.clearTimeout(lingerTimerRef.current);
        lingerTimerRef.current = null;
      }
    };

    const hideTooltip = () => {
      clearLingerTimer();
      setTooltip((prev) => (prev ? { ...prev, visible: false } : null));
      lingerTimerRef.current = window.setTimeout(() => {
        setTooltip(null);
      }, 180);
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      clearPressTimer();
      clearLingerTimer();

      const target = findTooltipTarget(e.target);
      if (!target) {
        triggeredForTargetRef.current = null;
        activeTargetRef.current = null;
        if (hasTooltipRef.current) hideTooltip();
        return;
      }

      const label = extractOptionLabel(target);
      if (!label) return;

      activeTargetRef.current = target;
      triggeredForTargetRef.current = null;
      startPosRef.current = { x: e.clientX, y: e.clientY };

      timerRef.current = window.setTimeout(() => {
        timerRef.current = null;
        startPosRef.current = null;
        if (!target.isConnected) return;

        triggeredForTargetRef.current = target;
        suppressUntilRef.current = Date.now() + 700;

        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try {
            navigator.vibrate(8);
          } catch {
            // Ignore unsupported vibration
          }
        }

        const rect = target.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const clampedX = Math.max(
          56,
          Math.min(window.innerWidth - 56, centerX)
        );
        const placeBelow = rect.top < 56;
        const y = placeBelow ? rect.bottom + 8 : rect.top - 8;
        const nextId = ++seqRef.current;

        setTooltip({
          id: nextId,
          label,
          x: clampedX,
          y,
          placeBelow,
          visible: false,
        });

        requestAnimationFrame(() => {
          setTooltip((curr) =>
            curr && curr.id === nextId ? { ...curr, visible: true } : curr
          );
        });
      }, LONG_PRESS_MS);
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!startPosRef.current || timerRef.current === null) return;
      const dx = Math.abs(e.clientX - startPosRef.current.x);
      const dy = Math.abs(e.clientY - startPosRef.current.y);
      if (dx > MOVE_THRESHOLD_PX || dy > MOVE_THRESHOLD_PX) {
        clearPressTimer();
      }
    };

    const onPointerUpOrCancel = () => {
      clearPressTimer();
      if (triggeredForTargetRef.current) {
        suppressUntilRef.current = Date.now() + 350;
        clearLingerTimer();
        lingerTimerRef.current = window.setTimeout(() => {
          hideTooltip();
        }, RELEASE_LINGER_MS);
      }
      activeTargetRef.current = null;
    };

    const onClickCapture = (e: MouseEvent) => {
      if (
        triggeredForTargetRef.current &&
        Date.now() <= suppressUntilRef.current
      ) {
        const clickedEl =
          e.target instanceof Element
            ? e.target.closest('button, [role="menuitem"], [data-tooltip]')
            : null;
        if (clickedEl === triggeredForTargetRef.current) {
          e.preventDefault();
          e.stopPropagation();
        }
        triggeredForTargetRef.current = null;
      }
    };

    const onContextMenuCapture = (e: MouseEvent) => {
      if (activeTargetRef.current || triggeredForTargetRef.current) {
        const target = findTooltipTarget(e.target);
        if (target) {
          e.preventDefault();
        }
      }
    };

    const onScrollCapture = () => {
      clearPressTimer();
      if (triggeredForTargetRef.current || hasTooltipRef.current) {
        triggeredForTargetRef.current = null;
        hideTooltip();
      }
    };

    window.addEventListener('pointerdown', onPointerDown, true);
    window.addEventListener('pointermove', onPointerMove, true);
    window.addEventListener('pointerup', onPointerUpOrCancel, true);
    window.addEventListener('pointercancel', onPointerUpOrCancel, true);
    window.addEventListener('click', onClickCapture, true);
    window.addEventListener('contextmenu', onContextMenuCapture, true);
    window.addEventListener('scroll', onScrollCapture, true);

    return () => {
      clearPressTimer();
      clearLingerTimer();
      window.removeEventListener('pointerdown', onPointerDown, true);
      window.removeEventListener('pointermove', onPointerMove, true);
      window.removeEventListener('pointerup', onPointerUpOrCancel, true);
      window.removeEventListener('pointercancel', onPointerUpOrCancel, true);
      window.removeEventListener('click', onClickCapture, true);
      window.removeEventListener('contextmenu', onContextMenuCapture, true);
      window.removeEventListener('scroll', onScrollCapture, true);
    };
  }, []);

  if (!tooltip) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        left: `${tooltip.x}px`,
        top: `${tooltip.y}px`,
        transform: tooltip.placeBelow
          ? `translate(-50%, ${tooltip.visible ? '0px' : '-4px'}) scale(${tooltip.visible ? 1 : 0.96})`
          : `translate(-50%, calc(-100% + ${tooltip.visible ? '0px' : '4px'})) scale(${tooltip.visible ? 1 : 0.96})`,
      }}
      className={`pointer-events-none select-none fixed z-[100] max-w-[calc(100vw-24px)] px-3 py-1.5 rounded-xl bg-slate-900/90 dark:bg-slate-100/95 text-white dark:text-slate-900 backdrop-blur-md shadow-lg border border-white/10 dark:border-slate-900/10 text-[13px] font-light tracking-wide leading-tight whitespace-nowrap truncate transition-all duration-150 ease-out ${
        tooltip.visible ? 'opacity-100' : 'opacity-0'
      }`}
    >
      {tooltip.label}
    </div>
  );
}
