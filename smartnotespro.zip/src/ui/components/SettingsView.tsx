import {
  AlertTriangle,
  Brush,
  Check,
  CheckSquare,
  Download,
  FileSpreadsheet,
  FileText,
  Fingerprint,
  Image as ImageIcon,
  KeyRound,
  Lock,
  Mic,
  Monitor,
  Moon,
  ShieldCheck,
  SlidersHorizontal,
  StickyNote,
  Sun,
  Trash2,
  Type,
  Upload,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import {
  decodeNotesCsv,
  downloadNotesAsCsv,
  sortNotesForOrganizedBackup,
} from '../../data/backup/notesCsvBackup';
import {
  decodeNotesPdf,
  downloadNotesAsPdf,
} from '../../data/backup/notesPdfBackup';
import {
  AppSettings,
  ThemeMode,
} from '../../data/preferences/settings';
import {
  authenticateWithVaultBiometric,
  AutoLockDelay,
  disableVaultBiometric,
  disableVaultPin,
  enrollVaultBiometric,
  isBiometricHardwareAvailable,
  SecurityVaultState,
  updateVaultAutoLock,
  verifyVaultPin,
} from '../../data/storage/securityVault';
import {
  getNoteColorOption,
  Note,
  NOTE_COLOR_PALETTE,
  StickyNoteType,
} from '../../domain/model/note';
import { PinSetupModal } from './AppLockOverlay';

type SettingsSectionTab = 'general' | 'security' | 'widgets' | 'backup';

interface SettingsViewProps {
  settings: AppSettings;
  vaultState: SecurityVaultState;
  liveNotes: readonly Note[];
  totalNotesCount: number;
  onUpdateSettings: (next: AppSettings) => void;
  onVaultStateChange: (next: SecurityVaultState) => void;
  onLockNow: () => void;
  onImportNotes: (notes: Note[]) => number;
  onDeleteAll: () => void;
}

const SECTION_TABS: Array<{
  id: SettingsSectionTab;
  label: string;
  icon: React.ReactNode;
}> = [
  { id: 'general', label: 'General', icon: <SlidersHorizontal className="w-3.5 h-3.5" /> },
  { id: 'security', label: 'Security', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
  { id: 'widgets', label: 'Widgets', icon: <StickyNote className="w-3.5 h-3.5" /> },
  { id: 'backup', label: 'Backup', icon: <Download className="w-3.5 h-3.5" /> },
];

const THEME_OPTIONS: Array<{ value: ThemeMode; label: string; icon: React.ReactNode }> = [
  { value: 'system', label: 'System', icon: <Monitor className="w-3.5 h-3.5" /> },
  { value: 'light', label: 'Light', icon: <Sun className="w-3.5 h-3.5" /> },
  { value: 'dark', label: 'Dark', icon: <Moon className="w-3.5 h-3.5" /> },
];

const WIDGET_TYPES: Array<{ id: StickyNoteType; label: string; icon: React.ReactNode }> = [
  { id: 'checklist', label: 'Checklist', icon: <CheckSquare className="w-3.5 h-3.5" /> },
  { id: 'text', label: 'Text', icon: <Type className="w-3.5 h-3.5" /> },
  { id: 'audio', label: 'Audio', icon: <Mic className="w-3.5 h-3.5" /> },
  { id: 'handwriting', label: 'Handwriting', icon: <Brush className="w-3.5 h-3.5" /> },
  { id: 'image', label: 'Image', icon: <ImageIcon className="w-3.5 h-3.5" /> },
];

const AUTO_LOCK_DESCRIPTIONS: Record<AutoLockDelay, string> = {
  immediate: 'Locks automatically whenever you open the app or return from another tab.',
  '60': 'Locks automatically after 1 minute of inactivity.',
  '300': 'Locks automatically after 5 minutes of inactivity.',
  manual: 'Stays unlocked until you tap Lock Now.',
};

export function SettingsView({
  settings,
  vaultState,
  liveNotes,
  totalNotesCount,
  onUpdateSettings,
  onVaultStateChange,
  onLockNow,
  onImportNotes,
  onDeleteAll,
}: SettingsViewProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [activeTab, setActiveTab] = useState<SettingsSectionTab>('general');
  const [statusBanner, setStatusBanner] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [importingBusy, setImportingBusy] = useState(false);

  // Danger Zone Delete All protection modal state
  const [confirmDeleteAllOpen, setConfirmDeleteAllOpen] = useState(false);
  const [deleteVerifyPin, setDeleteVerifyPin] = useState('');
  const [deleteVerifyPhrase, setDeleteVerifyPhrase] = useState('');
  const [deleteVerifyError, setDeleteVerifyError] = useState<string | null>(null);
  const [deleteVerifyBusy, setDeleteVerifyBusy] = useState(false);

  const [pinModalMode, setPinModalMode] = useState<
    'create' | 'change' | 'disable' | 'enroll-biometric' | null
  >(null);
  const [biometricSupported, setBiometricSupported] = useState<boolean>(false);
  const [biometricTestBusy, setBiometricTestBusy] = useState(false);

  useEffect(() => {
    void isBiometricHardwareAvailable().then(setBiometricSupported);
  }, []);

  useEffect(() => {
    if (!confirmDeleteAllOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setConfirmDeleteAllOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [confirmDeleteAllOpen]);

  const backupCounts = sortNotesForOrganizedBackup(liveNotes);
  const widgetColorOpt = getNoteColorOption(settings.widget.defaultColorTag);

  const openDeleteAllModal = () => {
    setDeleteVerifyPin('');
    setDeleteVerifyPhrase('');
    setDeleteVerifyError(null);
    setDeleteVerifyBusy(false);
    setConfirmDeleteAllOpen(true);
  };

  const executeProtectedDeleteAll = async () => {
    if (deleteVerifyBusy) return;
    setDeleteVerifyError(null);

    if (vaultState.enabled) {
      const cleanPin = deleteVerifyPin.replace(/\D/g, '');
      if (cleanPin.length !== vaultState.pinLength) {
        setDeleteVerifyError(`Enter your ${vaultState.pinLength}-digit Vault PIN or use Fingerprint.`);
        return;
      }
      setDeleteVerifyBusy(true);
      try {
        const res = await verifyVaultPin(cleanPin);
        onVaultStateChange(res.state);
        if (!res.ok) {
          setDeleteVerifyError(res.error ?? 'Incorrect Vault PIN.');
          setDeleteVerifyPin('');
          return;
        }
        onDeleteAll();
        setConfirmDeleteAllOpen(false);
        setStatusBanner({
          type: 'success',
          message: 'Verified and permanently deleted all notes.',
        });
      } finally {
        setDeleteVerifyBusy(false);
      }
      return;
    }

    if (deleteVerifyPhrase.trim().toUpperCase() !== 'DELETE') {
      setDeleteVerifyError('Type DELETE to confirm permanent removal.');
      return;
    }

    onDeleteAll();
    setConfirmDeleteAllOpen(false);
    setStatusBanner({
      type: 'success',
      message: 'All notes have been permanently deleted.',
    });
  };

  const handleBiometricDeleteAll = async () => {
    if (deleteVerifyBusy || !vaultState.enabled || !vaultState.biometricEnabled) return;
    setDeleteVerifyError(null);
    setDeleteVerifyBusy(true);
    try {
      const res = await authenticateWithVaultBiometric();
      if (res.ok) {
        if (res.state) onVaultStateChange(res.state);
        onDeleteAll();
        setConfirmDeleteAllOpen(false);
        setStatusBanner({
          type: 'success',
          message: 'Fingerprint verified. All notes have been permanently deleted.',
        });
      } else {
        setDeleteVerifyError(res.error ?? 'Fingerprint verification failed. Enter PIN instead.');
      }
    } finally {
      setDeleteVerifyBusy(false);
    }
  };

  const handleTestBiometric = async () => {
    if (biometricTestBusy || !vaultState.biometricEnabled) return;
    setBiometricTestBusy(true);
    try {
      const res = await authenticateWithVaultBiometric();
      if (res.ok) {
        if (res.state) onVaultStateChange(res.state);
        setStatusBanner({
          type: 'success',
          message: 'Fingerprint verified successfully on this device.',
        });
      } else {
        setStatusBanner({
          type: 'error',
          message: res.error ?? 'Fingerprint test was cancelled.',
        });
      }
    } finally {
      setBiometricTestBusy(false);
    }
  };

  const handleExportCsv = async () => {
    try {
      await downloadNotesAsCsv(liveNotes);
      setStatusBanner({
        type: 'success',
        message: `Saved CSV backup (${backupCounts.ordered.length} ${backupCounts.ordered.length === 1 ? 'note' : 'notes'}) to device storage.`,
      });
    } catch {
      setStatusBanner({
        type: 'error',
        message: 'Could not export CSV backup on this device.',
      });
    }
  };

  const handleExportPdf = async () => {
    if (pdfBusy) return;
    setPdfBusy(true);
    try {
      await downloadNotesAsPdf(liveNotes);
      setStatusBanner({
        type: 'success',
        message: `Saved organized PDF backup (${backupCounts.ordered.length} ${backupCounts.ordered.length === 1 ? 'note' : 'notes'}) to device storage.`,
      });
    } catch {
      setStatusBanner({
        type: 'error',
        message: 'Could not generate PDF backup on this device.',
      });
    } finally {
      setPdfBusy(false);
    }
  };

  const handleImportFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    setImportingBusy(true);
    try {
      const lowerName = file.name.toLowerCase();
      const isPdf =
        lowerName.endsWith('.pdf') || file.type === 'application/pdf';
      const isCsv =
        lowerName.endsWith('.csv') ||
        file.type === 'text/csv' ||
        file.type === 'application/vnd.ms-excel';

      let decoded: Note[] | null = null;
      if (isPdf) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        decoded = decodeNotesPdf(bytes);
      } else if (isCsv) {
        const text = await file.text();
        decoded = decodeNotesCsv(text);
      } else {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const head = String.fromCharCode(...bytes.subarray(0, 5));
        if (head === '%PDF-') {
          decoded = decodeNotesPdf(bytes);
        } else {
          const text = new TextDecoder('utf-8').decode(bytes);
          decoded = decodeNotesCsv(text);
        }
      }

      if (!decoded || decoded.length === 0) {
        setStatusBanner({
          type: 'error',
          message:
            'Could not read notes from this file. Please choose a CSV or PDF backup exported from SmartNotesPro.',
        });
        return;
      }

      const added = onImportNotes(decoded);
      setStatusBanner({
        type: 'success',
        message: `Imported ${added} ${added === 1 ? 'note' : 'notes'} back into your workspace.`,
      });
    } catch {
      setStatusBanner({
        type: 'error',
        message: 'Failed to read the selected backup file.',
      });
    } finally {
      setImportingBusy(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-slate-50/70 dark:bg-slate-950">
      {/* Polished Top Navigation Bar for Manage Preferences */}
      <div className="bg-white dark:bg-slate-950 px-4 sm:px-6 pt-5 pb-3.5 border-b border-slate-200 dark:border-slate-800 shrink-0">
        <div className="max-w-3xl mx-auto space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
                Settings
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Manage Preferences
              </p>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {liveNotes.length} active {liveNotes.length === 1 ? 'note' : 'notes'}
            </div>
          </div>

          <div
            className="inline-flex flex-wrap items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
            role="tablist"
            aria-label="Manage Preferences"
          >
            {SECTION_TABS.map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                    active
                      ? 'bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-200 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        <div className="max-w-3xl mx-auto space-y-7 pb-10">
          {statusBanner && (
            <div
              role="status"
              className={`rounded-2xl border px-4 py-3 text-sm flex items-center justify-between gap-3 shadow-xs ${
                statusBanner.type === 'success'
                  ? 'border-emerald-200 dark:border-emerald-900/70 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                  : 'border-rose-200 dark:border-rose-900/70 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
              }`}
            >
              <span>{statusBanner.message}</span>
              <button
                type="button"
                onClick={() => setStatusBanner(null)}
                className="text-xs font-semibold underline underline-offset-2 shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* ─────────── GENERAL SECTION ─────────── */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              {/* Appearance */}
              <section className="space-y-3">
                <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Appearance
                </h3>
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      Theme mode
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Match your device appearance or lock Light / Dark mode.
                    </p>
                  </div>
                  <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
                    {THEME_OPTIONS.map((option) => {
                      const active = settings.themeMode === option.value;
                      return (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({ ...settings, themeMode: option.value })
                          }
                          className={`inline-flex items-center gap-1.5 min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                            active
                              ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                          }`}
                        >
                          {option.icon}
                          <span>{option.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </section>

              {/* Editor & Calculator */}
              <section className="space-y-3">
                <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Editor &amp; Calculator
                </h3>
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      Auto-calculate expressions
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Detect math expressions as you type and auto-update applied results.
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-label="Auto-calculate expressions"
                    aria-checked={settings.autoCalc}
                    onClick={() =>
                      onUpdateSettings({ ...settings, autoCalc: !settings.autoCalc })
                    }
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                      settings.autoCalc
                        ? 'bg-indigo-600 dark:bg-indigo-500'
                        : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-xs transition duration-150 ${
                        settings.autoCalc ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </section>

              {/* Protected Danger Zone */}
              <section className="space-y-3">
                <h3 className="font-display text-sm font-semibold text-rose-600 dark:text-rose-400">
                  Danger Zone
                </h3>
                <div className="rounded-2xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <span>Delete all notes</span>
                      {vaultState.enabled && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 dark:text-amber-300">
                          <Lock className="w-3 h-3" />
                          <span>
                            {vaultState.biometricEnabled
                              ? 'PIN / Fingerprint Protected'
                              : 'PIN Protected'}
                          </span>
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 tabular-nums">
                      Permanently clears all {totalNotesCount} stored notes, including Trash.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={totalNotesCount === 0}
                    onClick={openDeleteAllModal}
                    className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-xl border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-950 hover:bg-rose-50 dark:hover:bg-rose-950/50 disabled:opacity-45 disabled:pointer-events-none text-xs font-semibold text-rose-700 dark:text-rose-300 whitespace-nowrap shrink-0 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete All</span>
                  </button>
                </div>
              </section>
            </div>
          )}

          {/* ─────────── SECURITY SECTION ─────────── */}
          {activeTab === 'security' && (
            <section className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Security Vault</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Protect notes, Danger Zone actions, and lock timing with PIN &amp; Fingerprint.
                  </p>
                </div>
                {vaultState.enabled && (
                  <button
                    type="button"
                    onClick={onLockNow}
                    className="inline-flex items-center gap-1.5 min-h-[38px] px-4 rounded-xl bg-slate-900 dark:bg-amber-200/15 text-white dark:text-amber-200 border border-transparent dark:border-amber-200/30 text-xs font-semibold hover:opacity-90 transition-opacity whitespace-nowrap shrink-0 shadow-xs"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Lock Now</span>
                  </button>
                )}
              </div>

              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900/70 shadow-xs overflow-hidden">
                <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      PIN App Lock
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {vaultState.enabled
                        ? `Active · ${vaultState.pinLength}-digit salted PBKDF2 protection`
                        : 'Set a 4 or 6-digit PIN to lock the app and protect Delete All.'}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {vaultState.enabled ? (
                      <>
                        <button
                          type="button"
                          onClick={() => setPinModalMode('change')}
                          className="inline-flex items-center gap-1.5 min-h-[36px] px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                          <span>Change PIN</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setPinModalMode('disable')}
                          className="inline-flex items-center gap-1.5 min-h-[36px] px-3.5 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/60 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        >
                          <span>Disable</span>
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPinModalMode('create')}
                        className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white shadow-xs"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>Set Up PIN</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Fingerprint className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      <span>Fingerprint / Biometric Unlock</span>
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {!vaultState.enabled
                        ? 'Set a PIN first to enroll device fingerprint or Touch ID.'
                        : vaultState.biometricEnabled
                          ? 'Active · Unlock vault & confirm Danger Zone actions with fingerprint.'
                          : biometricSupported
                            ? 'Ready · Enroll your device fingerprint, Face ID, or Windows Hello.'
                            : 'Tap toggle to verify device biometric / passkey capability (PIN always stays active).'}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 self-start sm:self-auto shrink-0">
                    {vaultState.enabled && vaultState.biometricEnabled && (
                      <button
                        type="button"
                        disabled={biometricTestBusy}
                        onClick={handleTestBiometric}
                        className="inline-flex items-center gap-1.5 min-h-[34px] px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/70 dark:bg-indigo-950/50 text-xs font-semibold text-indigo-700 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/60"
                      >
                        <Fingerprint className="w-3.5 h-3.5" />
                        <span>{biometricTestBusy ? 'Scanning...' : 'Test'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      role="switch"
                      aria-label="Toggle fingerprint unlock"
                      aria-checked={vaultState.biometricEnabled}
                      disabled={!vaultState.enabled}
                      onClick={() => {
                        if (!vaultState.enabled) return;
                        if (vaultState.biometricEnabled) {
                          const next = disableVaultBiometric();
                          onVaultStateChange(next);
                          setStatusBanner({
                            type: 'success',
                            message: 'Fingerprint unlock disabled. PIN lock remains active.',
                          });
                        } else {
                          setPinModalMode('enroll-biometric');
                        }
                      }}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed ${
                        vaultState.biometricEnabled
                          ? 'bg-indigo-600 dark:bg-indigo-500'
                          : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-xs transition duration-150 ${
                          vaultState.biometricEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {vaultState.enabled && (
                  <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        Auto-lock timing
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        {AUTO_LOCK_DESCRIPTIONS[vaultState.autoLock]}
                      </p>
                    </div>
                    <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
                      {(
                        [
                          { value: 'immediate', label: 'On open' },
                          { value: '60', label: '1 min' },
                          { value: '300', label: '5 min' },
                          { value: 'manual', label: 'Manual' },
                        ] as Array<{ value: AutoLockDelay; label: string }>
                      ).map((opt) => (
                        <button
                          key={opt.value}
                          type="button"
                          onClick={() => {
                            const next = updateVaultAutoLock(opt.value);
                            onVaultStateChange(next);
                            setStatusBanner({
                              type: 'success',
                              message:
                                opt.value === 'manual'
                                  ? 'Lock mode set to Manual. App stays unlocked until you press Lock Now.'
                                  : `Auto-lock timing updated to "${opt.label}".`,
                            });
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                            vaultState.autoLock === opt.value
                              ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* ─────────── WIDGETS SECTION (Classy & Realistic Notes, No Curves) ─────────── */}
          {activeTab === 'widgets' && (
            <section className="space-y-4">
              <div>
                <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <StickyNote className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Widget Configuration</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Configure realistic widget defaults for notes.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900/70 shadow-xs overflow-hidden">
                {/* Default Widget Note Type */}
                <div className="p-5 space-y-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Default note type
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {WIDGET_TYPES.map((t) => {
                      const active = settings.widget.defaultNoteType === t.id;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({
                              ...settings,
                              widget: { ...settings.widget, defaultNoteType: t.id },
                            })
                          }
                          className={`inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-xl border text-xs font-semibold whitespace-nowrap transition-colors ${
                            active
                              ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-200'
                              : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          {t.icon}
                          <span>{t.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Default Paper Colour */}
                <div className="p-5 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Note colour
                    </p>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {widgetColorOpt.name}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    {NOTE_COLOR_PALETTE.map((col) => {
                      const active = settings.widget.defaultColorTag === col.index;
                      return (
                        <button
                          key={col.index}
                          type="button"
                          title={col.name}
                          aria-label={col.name}
                          onClick={() =>
                            onUpdateSettings({
                              ...settings,
                              widget: { ...settings.widget, defaultColorTag: col.index },
                            })
                          }
                          className={`w-7 h-7 rounded-full border transition-transform ${
                            active
                              ? 'ring-2 ring-indigo-600 ring-offset-2 dark:ring-offset-slate-900 scale-110'
                              : 'border-slate-300 dark:border-slate-600 hover:scale-105'
                          }`}
                          style={{
                            backgroundColor:
                              col.swatchHex === 'transparent' ? '#FFFFFF' : col.swatchHex,
                          }}
                        />
                      );
                    })}
                  </div>
                </div>

                {/* Show Reminder & Calculation Total */}
                <div className="p-5 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Show reminder &amp; calculation total
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-label="Show reminder and calculation total"
                    aria-checked={settings.widget.showReminderAndTotal}
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        widget: {
                          ...settings.widget,
                          showReminderAndTotal: !settings.widget.showReminderAndTotal,
                        },
                      })
                    }
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-150 ${
                      settings.widget.showReminderAndTotal
                        ? 'bg-indigo-600 dark:bg-indigo-500'
                        : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-xs transition duration-150 ${
                        settings.widget.showReminderAndTotal
                          ? 'translate-x-5'
                          : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Classy, Realistic Paper Note Preview */}
                <div className="p-6 bg-slate-100/70 dark:bg-slate-950/70">
                  <div className="max-w-sm mx-auto">
                    <div
                      className={`relative rounded-lg border shadow-[0_8px_20px_-6px_rgba(15,23,42,0.16),0_2px_6px_-1px_rgba(15,23,42,0.08)] overflow-hidden ${widgetColorOpt.lightCardClass} ${widgetColorOpt.darkCardClass}`}
                    >
                      {/* Realistic Stationery Top Paper Header */}
                      <div className="px-4 py-3 border-b border-black/[0.07] dark:border-white/[0.08] flex items-center justify-between gap-2">
                        <span className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                          Daily Notes
                        </span>
                        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 capitalize">
                          {settings.widget.defaultNoteType}
                        </span>
                      </div>

                      {/* Subtle Paper Body */}
                      <div className="px-4 py-3.5 space-y-2.5 text-xs text-slate-700 dark:text-slate-200">
                        {settings.widget.defaultNoteType === 'checklist' ? (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2.5">
                              <span className="w-3.5 h-3.5 rounded-[3px] bg-indigo-600 text-white flex items-center justify-center shrink-0">
                                <Check className="w-2.5 h-2.5" />
                              </span>
                              <span className="line-through text-slate-400 dark:text-slate-500">
                                Review monthly budget
                              </span>
                            </div>
                            <div className="flex items-center gap-2.5">
                              <span className="w-3.5 h-3.5 rounded-[3px] border border-slate-400 dark:border-slate-500 shrink-0" />
                              <span>Groceries · 1,200 - 10%</span>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-1.5 leading-relaxed">
                            <p className="text-slate-800 dark:text-slate-100">
                              Meeting follow-up &amp; invoice summary
                            </p>
                            <p className="text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                              1,200 - 10% = 1,080
                            </p>
                          </div>
                        )}

                        {settings.widget.showReminderAndTotal && (
                          <div className="pt-2.5 mt-2 border-t border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                            <span>Today · 6:00 PM</span>
                            <span className="font-semibold text-slate-800 dark:text-slate-200">
                              Total: 1,080
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* ─────────── BACKUP SECTION (CSV & PDF ONLY) ─────────── */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    Local Device Storage Backup
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                    {backupCounts.ordered.length} organized notes ready ({backupCounts.pinned.length}{' '}
                    Pinned · {backupCounts.active.length} Active · {backupCounts.archived.length}{' '}
                    Archived)
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex flex-col justify-between gap-5">
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                        <FileSpreadsheet className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                          CSV Backup
                        </h3>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          Structured spreadsheet (.csv)
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Saves every note in neat columns sorted by Section (Pinned, Active,
                      Archived), Title, Type, Priority, Labels, Dates, Reminder, Calculation
                      Total, Checklist Progress, and Full Details.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleExportCsv}
                    className="w-full inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white transition-colors shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Save CSV Backup</span>
                  </button>
                </section>

                <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex flex-col justify-between gap-5">
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                          PDF Backup
                        </h3>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          Formatted A4 document (.pdf)
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Generates a clean, multi-page A4 document grouped separately into Pinned,
                      Active, and Archived sections with full note details, checkboxes, totals,
                      and embedded image previews.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={pdfBusy}
                    onClick={handleExportPdf}
                    className="w-full inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-xs font-semibold text-white transition-colors shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>{pdfBusy ? 'Generating PDF...' : 'Save PDF Backup'}</span>
                  </button>
                </section>
              </div>

              <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 shadow-xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                    Restore from Device Storage
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Select any previously saved SmartNotesPro <strong>.csv</strong> or{' '}
                    <strong>.pdf</strong> backup file to import your notes back into the app.
                  </p>
                </div>

                <button
                  type="button"
                  disabled={importingBusy}
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-100 whitespace-nowrap shrink-0 transition-colors"
                >
                  <Upload className="w-4 h-4" />
                  <span>{importingBusy ? 'Importing...' : 'Import CSV / PDF'}</span>
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.pdf,text/csv,application/pdf"
                  onChange={handleImportFileChange}
                  className="hidden"
                />
              </section>
            </div>
          )}
        </div>
      </div>

      {/* PIN / Fingerprint Protected Delete All Dialog */}
      {confirmDeleteAllOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-all-title"
          onClick={() => setConfirmDeleteAllOpen(false)}
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void executeProtectedDeleteAll();
            }}
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3
                  id="delete-all-title"
                  className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
                >
                  Delete every note permanently?
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {vaultState.enabled
                    ? `Verify your ${vaultState.pinLength}-digit Vault PIN${vaultState.biometricEnabled ? ' or Fingerprint' : ''} to permanently erase all notes.`
                    : 'This removes all active and trashed notes from local storage. Save a CSV or PDF backup first if you might need them later.'}
                </p>
              </div>
            </div>

            {vaultState.enabled ? (
              <div className="space-y-3 pt-1">
                {vaultState.biometricEnabled && (
                  <button
                    type="button"
                    disabled={deleteVerifyBusy}
                    onClick={handleBiometricDeleteAll}
                    className="w-full inline-flex items-center justify-center gap-2 min-h-[42px] px-4 rounded-xl border border-amber-300 dark:border-amber-500/40 bg-amber-50 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-950/50 text-xs font-semibold text-amber-900 dark:text-amber-200 transition-colors"
                  >
                    <Fingerprint className="w-4 h-4" />
                    <span>
                      {deleteVerifyBusy
                        ? 'Verifying fingerprint...'
                        : 'Verify with Fingerprint to Delete All'}
                    </span>
                  </button>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                    Or enter {vaultState.pinLength}-digit Vault PIN
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={vaultState.pinLength}
                    value={deleteVerifyPin}
                    onChange={(e) => {
                      setDeleteVerifyPin(e.target.value.replace(/\D/g, ''));
                      setDeleteVerifyError(null);
                    }}
                    autoFocus={!vaultState.biometricEnabled}
                    placeholder={`Enter ${vaultState.pinLength}-digit PIN`}
                    className="w-full text-center tracking-[0.4em] font-mono text-lg rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-4 py-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-2.5 pt-1">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                    Type <strong>DELETE</strong> to confirm
                  </label>
                  <input
                    type="text"
                    value={deleteVerifyPhrase}
                    onChange={(e) => {
                      setDeleteVerifyPhrase(e.target.value);
                      setDeleteVerifyError(null);
                    }}
                    placeholder="DELETE"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setConfirmDeleteAllOpen(false);
                    setActiveTab('security');
                    setPinModalMode('create');
                  }}
                  className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
                >
                  <Lock className="w-3 h-3" />
                  <span>Protect Danger Zone with Vault PIN / Fingerprint first</span>
                </button>
              </div>
            )}

            {deleteVerifyError && (
              <p className="text-xs text-rose-600 dark:text-rose-400">
                {deleteVerifyError}
              </p>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteAllOpen(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={deleteVerifyBusy}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-xs font-semibold text-white transition-colors"
              >
                {vaultState.enabled ? 'Verify & Delete All' : 'Delete Everything'}
              </button>
            </div>
          </form>
        </div>
      )}

      {pinModalMode && (
        <PinSetupModal
          mode={pinModalMode}
          currentPinLength={vaultState.pinLength}
          onSuccess={(nextState, infoMsg) => {
            onVaultStateChange(nextState);
            setPinModalMode(null);
            if (infoMsg) {
              setStatusBanner({ type: 'success', message: infoMsg });
            }
          }}
          onVerifyOnly={
            pinModalMode === 'disable'
              ? async (verifiedPin) => {
                  const res = await disableVaultPin(verifiedPin);
                  if (res.ok) {
                    onVaultStateChange(res.state);
                    setPinModalMode(null);
                    setStatusBanner({
                      type: 'success',
                      message: 'Vault PIN protection disabled.',
                    });
                  }
                }
              : pinModalMode === 'enroll-biometric'
                ? async (verifiedPin) => {
                    const res = await enrollVaultBiometric(verifiedPin);
                    onVaultStateChange(res.state);
                    setPinModalMode(null);
                    setStatusBanner({
                      type: res.ok ? 'success' : 'error',
                      message: res.message,
                    });
                  }
                : undefined
          }
          onClose={() => setPinModalMode(null)}
        />
      )}
    </div>
  );
}
