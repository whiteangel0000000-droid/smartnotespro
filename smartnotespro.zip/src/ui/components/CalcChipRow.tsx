import { Check } from 'lucide-react';
import {
  ExpressionMatch,
  formatEquation,
  formatPercentDelta,
  formatResult,
} from '../../domain/calculator/expressionDetector';

interface CalcChipRowProps {
  matches: readonly ExpressionMatch[];
  onChipClick: (match: ExpressionMatch) => void;
}

export function CalcChipRow({ matches, onChipClick }: CalcChipRowProps) {
  const pendingMatches = matches.filter(
    (m) => !m.isApplied && m.printedEndIndexInclusive === undefined
  );
  if (pendingMatches.length === 0) return null;

  return (
    <div
      className="border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/80 px-4 py-2"
      aria-label="Detected calculations"
    >
      <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
        <span className="text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap shrink-0 mr-1">
          Calculations:
        </span>
        {pendingMatches.map((match) => {
          const deltaText = formatPercentDelta(match);
          const isNegative = (match.percentDelta ?? 0) < 0;
          return (
            <button
              key={match.startIndex}
              type="button"
              onClick={() => onChipClick(match)}
              title={`Print "${formatEquation(match)}"`}
              className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/70 border border-indigo-200 dark:border-indigo-800 text-xs font-mono tabular-nums text-indigo-900 dark:text-indigo-100 whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
            >
              <span className="inline-flex items-baseline gap-1.5">
                <span>
                  {match.expression.trim()} = {formatResult(match.result)}
                </span>
                {deltaText && (
                  <span
                    className={`text-[10px] font-semibold leading-none tabular-nums ${
                      isNegative
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {deltaText}
                  </span>
                )}
              </span>
              <Check className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
