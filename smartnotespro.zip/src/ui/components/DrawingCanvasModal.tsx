import { Check, Eraser, Pen, RotateCcw, Trash2, X } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';

interface DrawingCanvasModalProps {
  onSave: (dataUrl: string) => void;
  onClose: () => void;
}

const PEN_COLORS = [
  '#1E293B',
  '#EF4444',
  '#F59E0B',
  '#10B981',
  '#3B82F6',
  '#8B5CF6',
  '#FFFFFF',
];

const STROKE_WIDTHS = [3, 6, 12];

export function DrawingCanvasModal({ onSave, onClose }: DrawingCanvasModalProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const historyRef = useRef<ImageData[]>([]);
  const drawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  const [penColor, setPenColor] = useState('#1E293B');
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [eraser, setEraser] = useState(false);
  const [hasStrokes, setHasStrokes] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    historyRef.current = [ctx.getImageData(0, 0, canvas.width, canvas.height)];
  }, []);

  const getPoint = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    canvas.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    const pt = getPoint(e);
    lastPointRef.current = pt;

    ctx.beginPath();
    ctx.arc(pt.x, pt.y, (eraser ? strokeWidth * 2 : strokeWidth) / 2, 0, Math.PI * 2);
    ctx.fillStyle = eraser ? '#FFFFFF' : penColor;
    ctx.fill();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    const prev = lastPointRef.current;
    if (!canvas || !ctx || !prev) return;

    const pt = getPoint(e);
    ctx.beginPath();
    ctx.moveTo(prev.x, prev.y);
    ctx.lineTo(pt.x, pt.y);
    ctx.strokeStyle = eraser ? '#FFFFFF' : penColor;
    ctx.lineWidth = eraser ? strokeWidth * 2.2 : strokeWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();

    lastPointRef.current = pt;
  };

  const handlePointerUp = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    lastPointRef.current = null;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    historyRef.current.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
    if (historyRef.current.length > 25) {
      historyRef.current.shift();
    }
    setHasStrokes(true);
  };

  const handleUndo = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || historyRef.current.length <= 1) return;
    historyRef.current.pop();
    const prev = historyRef.current[historyRef.current.length - 1];
    ctx.putImageData(prev, 0, 0);
    setHasStrokes(historyRef.current.length > 1);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    historyRef.current.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
    setHasStrokes(false);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    onSave(canvas.toDataURL('image/png'));
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Drawing pad"
    >
      <div className="w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden flex flex-col">
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              aria-label="Close drawing pad"
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              Drawing
            </h2>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleUndo}
              disabled={!hasStrokes}
              aria-label="Undo stroke"
              className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-35"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleClear}
              aria-label="Clear canvas"
              className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 min-h-[38px] px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white whitespace-nowrap"
            >
              <Check className="w-4 h-4" />
              <span>Save</span>
            </button>
          </div>
        </div>

        <div className="bg-slate-100 dark:bg-slate-950 p-3 sm:p-4 flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={800}
            height={520}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="w-full max-h-[60vh] aspect-[800/520] rounded-xl border border-slate-200 dark:border-slate-800 bg-white touch-none cursor-crosshair shadow-xs"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setEraser(false)}
              aria-label="Pen tool"
              className={`min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg ${
                !eraser
                  ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Pen className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setEraser(true)}
              aria-label="Eraser tool"
              className={`min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg ${
                eraser
                  ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Eraser className="w-4 h-4" />
            </button>

            <span className="h-5 w-px bg-slate-200 dark:bg-slate-800 mx-1" />

            {PEN_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => {
                  setPenColor(c);
                  setEraser(false);
                }}
                aria-label={`Color ${c}`}
                className={`w-6 h-6 rounded-full border border-slate-300 dark:border-slate-600 transition-transform ${
                  !eraser && penColor === c ? 'scale-115 ring-2 ring-indigo-500 ring-offset-1' : ''
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {STROKE_WIDTHS.map((w) => (
              <button
                key={w}
                type="button"
                onClick={() => setStrokeWidth(w)}
                aria-label={`Brush size ${w}`}
                className={`min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg border ${
                  strokeWidth === w
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/60'
                    : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                <span
                  className="rounded-full bg-slate-800 dark:bg-slate-200"
                  style={{ width: w + 4, height: w + 4 }}
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
