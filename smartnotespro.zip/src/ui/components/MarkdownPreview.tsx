import React from 'react';
import { DEFAULT_NOTE_FONT_SIZE, sanitizeFontSize } from '../../domain/model/note';
import {
  ExpressionMatch,
  formatPercentDelta,
  formatResult,
} from '../../utils/mathEvaluator';
import { sanitizeRichHtml } from '../../utils/richText';

interface MarkdownPreviewProps {
  text: string;
  richContent?: string;
  fontSize?: number;
  matches: readonly ExpressionMatch[];
  onApplyMatch: (match: ExpressionMatch) => void;
}

const TOKEN_REGEX =
  /(\*\*(?=\S)(.+?)(?<=\S)\*\*|__(?=\S)(.+?)(?<=\S)__|~~(?=\S)(.+?)(?<=\S)~~|(?<![*\w])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![*\w]))/g;

function renderStyledSegment(
  segment: string,
  keyPrefix: string
): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  let lastIndex = 0;
  TOKEN_REGEX.lastIndex = 0;

  let match: RegExpExecArray | null;
  while ((match = TOKEN_REGEX.exec(segment)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(segment.slice(lastIndex, match.index));
    }
    if (match[2] !== undefined) {
      nodes.push(
        <strong
          key={`${keyPrefix}-b-${match.index}`}
          className="font-semibold text-slate-900 dark:text-slate-50"
        >
          {match[2]}
        </strong>
      );
    } else if (match[3] !== undefined) {
      nodes.push(
        <span
          key={`${keyPrefix}-u-${match.index}`}
          className="underline decoration-slate-400 dark:decoration-slate-500 underline-offset-4"
        >
          {match[3]}
        </span>
      );
    } else if (match[4] !== undefined) {
      nodes.push(
        <s
          key={`${keyPrefix}-s-${match.index}`}
          className="line-through opacity-80"
        >
          {match[4]}
        </s>
      );
    } else if (match[5] !== undefined) {
      nodes.push(
        <em
          key={`${keyPrefix}-i-${match.index}`}
          className="italic text-slate-800 dark:text-slate-200"
        >
          {match[5]}
        </em>
      );
    }
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < segment.length) {
    nodes.push(segment.slice(lastIndex));
  }
  return nodes;
}

function renderRichHtmlNodes(
  richHtml: string,
  baseFontSize: number
): React.ReactNode[] {
  if (typeof document === 'undefined') return [];
  const container = document.createElement('div');
  container.innerHTML = sanitizeRichHtml(richHtml);

  let keyCounter = 0;
  const toReact = (node: Node): React.ReactNode => {
    const key = `rn-${keyCounter++}`;
    if (node.nodeType === Node.TEXT_NODE) {
      return node.nodeValue ?? '';
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return null;
    const el = node as HTMLElement;
    const tag = el.tagName.toUpperCase();
    const children = Array.from(el.childNodes).map(toReact);

    if (tag === 'BR') return <br key={key} />;
    if (tag === 'B' || tag === 'STRONG') {
      return (
        <strong key={key} className="font-bold">
          {children}
        </strong>
      );
    }
    if (tag === 'I' || tag === 'EM') {
      return (
        <em key={key} className="italic">
          {children}
        </em>
      );
    }
    if (tag === 'U') {
      return (
        <u key={key} className="underline decoration-from-font underline-offset-4 align-baseline">
          {children}
        </u>
      );
    }
    if (tag === 'S' || tag === 'STRIKE' || tag === 'DEL') {
      return (
        <s key={key} className="line-through decoration-from-font align-baseline">
          {children}
        </s>
      );
    }
    if (tag === 'SPAN') {
      const fsMatch = el.style?.fontSize?.match(/^(\d+(?:\.\d+)?)px$/i);
      const style = fsMatch
        ? { fontSize: `${sanitizeFontSize(Number(fsMatch[1]))}px` }
        : undefined;
      return (
        <span key={key} style={style}>
          {children}
        </span>
      );
    }
    if (tag === 'DIV' || tag === 'P') {
      return (
        <div key={key} className="min-h-[1.55em] leading-[1.55]">
          {children.length > 0 ? children : <br />}
        </div>
      );
    }
    return <React.Fragment key={key}>{children}</React.Fragment>;
  };

  return [
    <div
      key="rich-root"
      style={{ fontSize: `${sanitizeFontSize(baseFontSize)}px` }}
      className="text-left leading-[1.55] text-slate-800 dark:text-slate-200 break-words [&_span]:leading-[1.35] [&_span]:align-baseline"
    >
      {Array.from(container.childNodes).map(toReact)}
    </div>,
  ];
}

export function MarkdownPreview({
  text,
  richContent,
  fontSize = DEFAULT_NOTE_FONT_SIZE,
  matches,
  onApplyMatch,
}: MarkdownPreviewProps) {
  if (!text.trim()) {
    return (
      <p className="text-sm text-slate-400 dark:text-slate-500 italic">
        Nothing to preview yet.
      </p>
    );
  }

  if (richContent && richContent.trim()) {
    return (
      <div className="space-y-3">
        {renderRichHtmlNodes(richContent, fontSize)}
      </div>
    );
  }

  const lines = text.split('\n');
  let charOffset = 0;

  return (
    <div
      style={{ fontSize: `${sanitizeFontSize(fontSize)}px` }}
      className="space-y-1.5 leading-relaxed text-slate-800 dark:text-slate-200"
    >
      {lines.map((rawLine, lineIdx) => {
        const lineStart = charOffset;
        const lineEnd = lineStart + rawLine.length;
        charOffset = lineEnd + 1;

        let headingLevel: 0 | 1 | 2 = 0;
        let prefixLen = 0;
        if (rawLine.startsWith('## ')) {
          headingLevel = 2;
          prefixLen = 3;
        } else if (rawLine.startsWith('# ')) {
          headingLevel = 1;
          prefixLen = 2;
        }

        const contentStart = lineStart + prefixLen;
        const lineMatches = matches.filter(
          (m) => m.startIndex >= contentStart && m.endIndexInclusive < lineEnd
        );

        const lineNodes: React.ReactNode[] = [];
        let cursor = contentStart;

        lineMatches.forEach((m, idx) => {
          if (m.startIndex > cursor) {
            lineNodes.push(
              ...renderStyledSegment(
                text.slice(cursor, m.startIndex),
                `l${lineIdx}-seg-${idx}`
              )
            );
          }
          const rawExpr = text.slice(m.startIndex, m.endIndexInclusive + 1);
          const formatted = formatResult(m.result);
          const deltaText = formatPercentDelta(m);
          const isNegativeDelta = (m.percentDelta ?? 0) < 0;
          const deltaNode = deltaText ? (
            <span
              className={`text-[0.72em] font-semibold leading-none tabular-nums ${
                isNegativeDelta
                  ? 'text-rose-600 dark:text-rose-400'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {deltaText}
            </span>
          ) : null;
          if (m.isApplied) {
            lineNodes.push(
              <span
                key={`l${lineIdx}-math-${m.startIndex}`}
                className="inline-flex items-baseline gap-1 px-1.5 py-0.5 mx-0.5 rounded bg-slate-200/60 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 font-mono text-[0.92em] tabular-nums"
              >
                <span>{rawExpr}</span>
                <span className="text-indigo-600 dark:text-indigo-400 font-semibold">
                  = {formatted}
                </span>
                {deltaNode}
              </span>
            );
          } else {
            lineNodes.push(
              <button
                key={`l${lineIdx}-math-${m.startIndex}`}
                type="button"
                onClick={() => onApplyMatch(m)}
                title={`Click to print "${rawExpr} = ${formatted}"`}
                className="inline-flex items-baseline gap-1 px-1.5 py-0.5 mx-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/70 text-indigo-800 dark:text-indigo-200 font-mono text-[0.92em] tabular-nums transition-colors"
              >
                <span>{rawExpr}</span>
                <span className="text-indigo-500 dark:text-indigo-400 font-medium">
                  = {formatted}
                </span>
                {deltaNode}
              </button>
            );
          }
          cursor = (m.printedEndIndexInclusive ?? m.endIndexInclusive) + 1;
        });

        if (cursor < lineEnd) {
          lineNodes.push(
            ...renderStyledSegment(text.slice(cursor, lineEnd), `l${lineIdx}-tail`)
          );
        }

        if (lineNodes.length === 0) {
          return <div key={lineIdx} className="h-3" />;
        }

        if (headingLevel === 1) {
          return (
            <h1
              key={lineIdx}
              className="font-display text-2xl font-bold text-slate-900 dark:text-slate-50 pt-1"
            >
              {lineNodes}
            </h1>
          );
        }
        if (headingLevel === 2) {
          return (
            <h2
              key={lineIdx}
              className="font-display text-xl font-semibold text-slate-900 dark:text-slate-100 pt-0.5"
            >
              {lineNodes}
            </h2>
          );
        }
        return (
          <p key={lineIdx} className="whitespace-pre-wrap break-words">
            {lineNodes}
          </p>
        );
      })}
    </div>
  );
}
