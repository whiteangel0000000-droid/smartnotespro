import { Check, Copy, FileDown, ImageDown, X } from 'lucide-react';
import { useState } from 'react';
import {
  ExpressionMatch,
  formatPercentDelta,
  formatResult,
} from '../../domain/calculator/expressionDetector';
import {
  downloadCalculationsAsJpg,
  downloadCalculationsAsPdf,
} from '../../utils/calculationsExport';

interface CalculationsModalProps {
  noteTitle: string;
  matches: readonly ExpressionMatch[];
  matchKeys: readonly string[];
  excludedKeys: readonly string[];
  total: number;
  onToggleExclude: (key: string) => void;
  onReplace: (match: ExpressionMatch) => void;
  onClose: () => void;
}

export function CalculationsModal({
  noteTitle,
  matches,
  matchKeys,
  excludedKeys,
  total,
  onToggleExclude,
  onReplace,
  onClose,
}: CalculationsModalProps) {
  const [copiedTotal, setCopiedTotal] = useState(false);
  const [downloading, setDownloading] = useState<'pdf' | 'jpg' | null>(null);

  const excludedSet = new Set(excludedKeys);
  const includedMatches = matches.filter((_, idx) => !excludedSet.has(matchKeys[idx]));
  const hasExclusions = includedMatches.length < matches.length;

  const handleCopyTotal = async () => {
    try {
      await navigator.clipboard.writeText(formatResult(total));
      setCopiedTotal(true);
      window.setTimeout(() => setCopiedTotal(false), 1800);
    } catch {
      // Ignore clipboard rejection
    }
  };

  const handleDownloadPdf = async () => {
    if (includedMatches.length === 0) return;
    try {
      setDownloading('pdf');
      await downloadCalculationsAsPdf({
        noteTitle,
        matches: includedMatches,
        total,
      });
    } finally {
      setDownloading(null);
    }
  };

  const handleDownloadJpg = async () => {
    if (includedMatches.length === 0) return;
    try {
      setDownloading('jpg');
      await downloadCalculationsAsJpg({
        noteTitle,
        matches: includedMatches,
        total,
      });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="calc-dialog-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2
              id="calc-dialog-title"
              className="font-display text-base font-semibold text-slate-900 dark:text-slate-100"
            >
              Calculations in this note
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
              {hasExclusions
                ? `${includedMatches.length} of ${matches.length} included in total`
                : `${matches.length} ${matches.length === 1 ? 'expression' : 'expressions'} detected`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close calculations dialog"
            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {matches.map((match, idx) => {
            const key = matchKeys[idx] ?? `${idx}:${match.expression}`;
            const isExcluded = excludedSet.has(key);
            const deltaText = formatPercentDelta(match);
            const isNegative = (match.percentDelta ?? 0) < 0;
            return (
              <div
                key={key}
                className={`flex items-center justify-between gap-3 px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                  isExcluded ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={!isExcluded}
                    aria-label={
                      isExcluded
                        ? `Include ${match.expression.trim()} in total`
                        : `Exclude ${match.expression.trim()} from total`
                    }
                    title={
                      isExcluded
                        ? 'Include in total'
                        : 'Exclude from total'
                    }
                    onClick={() => onToggleExclude(key)}
                    className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                      !isExcluded
                        ? 'bg-indigo-600 border-indigo-600 text-white'
                        : 'border-slate-400 dark:border-slate-500 bg-transparent hover:border-indigo-500'
                    }`}
                  >
                    {!isExcluded && <Check className="w-3.5 h-3.5" />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className="font-mono text-sm text-slate-700 dark:text-slate-300 truncate">
                      {match.expression.trim()}
                    </p>
                    {isExcluded && (
                      <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                        Excluded from total
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2.5 shrink-0">
                  <div className="flex items-baseline gap-1.5 leading-tight">
                    <span className="font-mono text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                      = {formatResult(match.result)}
                    </span>
                    {deltaText && (
                      <span
                        className={`font-mono text-[10px] font-semibold tabular-nums ${
                          isNegative
                            ? 'text-rose-600 dark:text-rose-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {deltaText}
                      </span>
                    )}
                  </div>
                  {!match.isApplied &&
                    match.printedEndIndexInclusive === undefined &&
                    !isExcluded && (
                      <button
                        type="button"
                        onClick={() => onReplace(match)}
                        title={`Insert "${match.expression.trim()} = ${formatResult(match.result)}"`}
                        aria-label="Insert calculation result in note"
                        className="min-h-[32px] min-w-[32px] px-2.5 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/70 text-xs font-medium text-indigo-700 dark:text-indigo-300 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                      >
                        =
                      </button>
                    )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="font-mono text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              Total: {formatResult(total)}
            </div>
            <button
              type="button"
              onClick={handleCopyTotal}
              className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
            >
              {copiedTotal ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy total</span>
                </>
              )}
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={downloading !== null || includedMatches.length === 0}
                onClick={handleDownloadPdf}
                className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-xs font-medium text-white whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>{downloading === 'pdf' ? 'Saving PDF...' : 'Download PDF'}</span>
              </button>
              <button
                type="button"
                disabled={downloading !== null || includedMatches.length === 0}
                onClick={handleDownloadJpg}
                className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              >
                <ImageDown className="w-3.5 h-3.5" />
                <span>{downloading === 'jpg' ? 'Saving JPG...' : 'Download JPG'}</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] px-4 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
