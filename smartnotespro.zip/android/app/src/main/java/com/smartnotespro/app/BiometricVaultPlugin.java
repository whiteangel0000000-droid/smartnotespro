package com.smartnotespro.app;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "BiometricVault")
public class BiometricVaultPlugin extends Plugin {

    private static final int ALLOWED_AUTHENTICATORS =
        BiometricManager.Authenticators.BIOMETRIC_STRONG |
        BiometricManager.Authenticators.BIOMETRIC_WEAK;

    @PluginMethod
    public void isAvailable(PluginCall call) {
        BiometricManager manager = BiometricManager.from(getContext());
        int status = manager.canAuthenticate(ALLOWED_AUTHENTICATORS);
        JSObject result = new JSObject();
        result.put("available", status == BiometricManager.BIOMETRIC_SUCCESS);
        call.resolve(result);
    }

    @PluginMethod
    public void authenticate(PluginCall call) {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            call.reject("Activity unavailable");
            return;
        }

        BiometricManager manager = BiometricManager.from(getContext());
        if (manager.canAuthenticate(ALLOWED_AUTHENTICATORS) != BiometricManager.BIOMETRIC_SUCCESS) {
            call.reject("Fingerprint or biometric unlock is not set up on this device.");
            return;
        }

        String title = call.getString("title", "Unlock SmartNotesPro");
        String subtitle = call.getString("subtitle", "Verify your fingerprint to continue");

        activity.runOnUiThread(() -> {
            Executor executor = ContextCompat.getMainExecutor(getContext());
            AtomicBoolean settled = new AtomicBoolean(false);

            BiometricPrompt prompt = new BiometricPrompt(
                activity,
                executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        if (settled.compareAndSet(false, true)) {
                            JSObject out = new JSObject();
                            out.put("verified", true);
                            call.resolve(out);
                        }
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        if (settled.compareAndSet(false, true)) {
                            call.reject(errString != null ? errString.toString() : "Authentication cancelled.");
                        }
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        // System prompt allows retry; do not settle until error/cancel or success
                    }
                }
            );

            BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(title != null ? title : "Unlock SmartNotesPro")
                .setSubtitle(subtitle != null ? subtitle : "Verify your fingerprint")
                .setAllowedAuthenticators(ALLOWED_AUTHENTICATORS)
                .setNegativeButtonText("Use PIN")
                .build();

            prompt.authenticate(promptInfo);
        });
    }
}
