export {
  autoUpdatePrintedResultsInText,
  findExpressions,
  formatEquation,
  formatPercentDelta,
  formatResult,
  getMatchKeys,
  isCaretInPrintedSuffix,
  replaceWithResult,
  totalOfMatches,
  totalOfText,
} from '../../utils/mathEvaluator';
export type { ExpressionMatch, PercentAdjustment } from '../../utils/mathEvaluator';
